import SwiftUI
import UIKit
import Foundation

// ==========================================
// 1. CLASS QUẢN LÝ LOGIC (TỰ ĐỘNG TÌM ĐƯỜNG DẪN & PATCH)
// ==========================================
class NovaMaxManager: ObservableObject {
    // Tên file cần patch trong game FF Max
    let targetFileName = "assetindexer.YJ~2FW7EkU5pRkVg51NrKyx4LXid8~3D"
    
    @Published var aimStates: [String: Bool] = [
        "Aim Head": false,
        "Aim Neck": false,
        "Aim Body": false,
        "Aim Drag": false
    ]
    
    @Published var statusMessage: String = "Sẵn sàng"
    
    // Hàm tự động tìm đường dẫn thư mục Data của FF Max (Dành cho máy có TrollStore)
    private func getFFMaxDataPath() -> String? {
        let fileManager = FileManager.default
        let appsPath = "/var/mobile/Containers/Data/Application/"
        
        do {
            let apps = try fileManager.contentsOfDirectory(atPath: appsPath)
            for appUUID in apps {
                let appPath = appsPath + appUUID
                let metadataPath = appPath + "/.com.apple.mobile_container_manager.metadata.plist"
                
                if let dict = NSDictionary(contentsOfFile: metadataPath),
                   let bundleID = dict["MCMMetadataIdentifier"] as? String,
                   bundleID == "com.dts.freefiremax" {
                    
                    if let enumerator = fileManager.enumerator(atPath: appPath) {
                        for case let path as String in enumerator {
                            if path.hasSuffix(targetFileName) {
                                return appPath + "/" + path
                            }
                        }
                    }
                }
            }
        } catch {
            print("Lỗi quét thư mục: \(error)")
        }
        return nil
    }
    
    // Hàm Gạt Bật / Tắt
    func toggleAim(aimType: String, isOn: Bool) {
        if isOn {
            applyPatch(aimType: aimType)
        } else {
            removePatch(aimType: aimType)
        }
    }
    
    private func applyPatch(aimType: String) {
        guard let gameFilePath = getFFMaxDataPath() else {
            self.statusMessage = "❌ Không tìm thấy file game FF Max!"
            self.aimStates[aimType] = false
            return
        }
        
        let fileManager = FileManager.default
        let backupFilePath = gameFilePath + ".bak"
        
        // 1. Tạo file Backup nếu chưa có
        if !fileManager.fileExists(atPath: backupFilePath) {
            try? fileManager.copyItem(atPath: gameFilePath, toPath: backupFilePath)
        }
        
        // 2. Tìm file patch tương ứng trong Bundle (Mày nhớ ném file .patch vào Xcode)
        guard let patchFilePath = Bundle.main.path(forResource: aimType, ofType: "patch") else {
            self.statusMessage = "❌ Không tìm thấy file \(aimType).patch trong app!"
            self.aimStates[aimType] = false
            return
        }
        
        // 3. Ghi đè file patch vào game
        do {
            if fileManager.fileExists(atPath: gameFilePath) {
                try fileManager.removeItem(atPath: gameFilePath)
            }
            try fileManager.copyItem(atPath: patchFilePath, toPath: gameFilePath)
            self.statusMessage = "✅ Đã bật \(aimType)"
            self.aimStates[aimType] = true
        } catch {
            self.statusMessage = "❌ Lỗi patch: \(error.localizedDescription)"
            self.aimStates[aimType] = false
        }
    }
    
    private func removePatch(aimType: String) {
        guard let gameFilePath = getFFMaxDataPath() else { return }
        let fileManager = FileManager.default
        let backupFilePath = gameFilePath + ".bak"
        
        // Khôi phục từ file Backup
        if fileManager.fileExists(atPath: backupFilePath) {
            do {
                if fileManager.fileExists(atPath: gameFilePath) {
                    try fileManager.removeItem(atPath: gameFilePath)
                }
                try fileManager.moveItem(atPath: backupFilePath, toPath: gameFilePath)
                self.statusMessage = "✅ Đã khôi phục file gốc"
                self.aimStates[aimType] = false
            } catch {
                self.statusMessage = "❌ Lỗi restore: \(error.localizedDescription)"
            }
        } else {
            self.statusMessage = "⚠️ Không tìm thấy file Backup!"
            self.aimStates[aimType] = false
        }
    }
    
    func openFFMax() {
        let url = URL(string: "freefiremax://")!
        if UIApplication.shared.canOpenURL(url) {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }
    }
}

// ==========================================
// 2. GIAO DIỆN CHÍNH (CONTENT VIEW)
// ==========================================
struct ContentView: View {
    @StateObject private var manager = NovaMaxManager()
    
    private let patchNames = ["Aim Head", "Aim Neck", "Aim Body", "Aim Drag"]
    private let columns = [GridItem(.flexible(), spacing: 14), GridItem(.flexible(), spacing: 14)]

    var body: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 24) {
                    header
                    statusView
                    patchOptions
                    launchGame
                }
                .padding(.horizontal, 18)
                .padding(.top, 12)
                .padding(.bottom, 28)
            }
            .background(NovaMaxBackground())
            .toolbar(.hidden, for: .navigationBar)
            .preferredColorScheme(.dark)
        }
    }

    private var header: some View {
        HStack(alignment: .center) {
            VStack(alignment: .leading, spacing: 5) {
                Text("NOVAMAX")
                    .font(.system(size: 34, weight: .black, design: .rounded))
                    .tracking(4)
                    .foregroundStyle(.white)
                Text("PATCH CONTROL CENTER")
                    .font(.system(size: 12, weight: .heavy, design: .rounded))
                    .tracking(3)
                    .foregroundStyle(NovaMaxPalette.red)
            }
            Spacer()
        }
        .padding(.top, 8)
    }

    private var statusView: some View {
        HStack {
            Text(manager.statusMessage)
                .font(.system(size: 12, design: .rounded))
                .foregroundStyle(.white.opacity(0.8))
            Spacer()
        }
        .padding(12)
        .background(Color.black.opacity(0.5), in: RoundedRectangle(cornerRadius: 8))
        .overlay(RoundedRectangle(cornerRadius: 8).stroke(NovaMaxPalette.red.opacity(0.3), lineWidth: 1))
    }

    private var patchOptions: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("ϟ  PATCH OPTIONS")
                .font(.system(size: 14, weight: .black, design: .rounded))
                .tracking(2)
                .foregroundStyle(NovaMaxPalette.red)

            LazyVGrid(columns: columns, spacing: 14) {
                ForEach(patchNames, id: \.self) { name in
                    VStack(alignment: .leading, spacing: 10) {
                        HStack {
                            Image(systemName: "bolt.fill")
                                .font(.system(size: 24, weight: .bold))
                                .foregroundStyle(manager.aimStates[name] == true ? NovaMaxPalette.green : NovaMaxPalette.red)
                            Spacer()
                            
                            // NÚT GẠT TỰ ĐỘNG PATCH / RESTORE
                            Toggle("", isOn: Binding(
                                get: { manager.aimStates[name] ?? false },
                                set: { newValue in
                                    manager.toggleAim(aimType: name, isOn: newValue)
                                }
                            ))
                            .labelsHidden()
                            .tint(NovaMaxPalette.green)
                        }
                        
                        Text(name)
                            .font(.system(size: 21, weight: .heavy, design: .rounded))
                            .foregroundStyle(.white)
                            .lineLimit(1)
                            .minimumScaleFactor(0.8)
                            
                        Text("NOVAMAX PACKAGE")
                            .font(.system(size: 10, weight: .black, design: .rounded))
                            .tracking(1.6)
                            .foregroundStyle(manager.aimStates[name] == true ? NovaMaxPalette.green : NovaMaxPalette.red)
                    }
                    .frame(maxWidth: .infinity, minHeight: 130, alignment: .leading)
                    .padding(16)
                    .background(Color.black.opacity(0.76), in: RoundedRectangle(cornerRadius: 25))
                    .overlay(RoundedRectangle(cornerRadius: 25).stroke((manager.aimStates[name] == true ? NovaMaxPalette.green : NovaMaxPalette.red).opacity(0.7), lineWidth: 1))
                }
            }
        }
    }

    private var launchGame: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("↗  LAUNCH GAME")
                .font(.system(size: 14, weight: .black, design: .rounded))
                .tracking(2)
                .foregroundStyle(NovaMaxPalette.red)

            Button {
                manager.openFFMax()
            } label: {
                VStack(alignment: .leading, spacing: 10) {
                    Image(systemName: "arrow.up.right.square.fill")
                        .font(.system(size: 24, weight: .bold))
                        .foregroundStyle(NovaMaxPalette.red)
                    Text("FF MAX")
                        .font(.system(size: 17, weight: .black, design: .rounded))
                        .foregroundStyle(.white)
                    Text("Free Fire Max")
                        .font(.system(size: 12, weight: .medium))
                        .foregroundStyle(.white.opacity(0.48))
                }
                .frame(maxWidth: .infinity, minHeight: 112, alignment: .leading)
                .padding(16)
                .background(Color.black.opacity(0.72), in: RoundedRectangle(cornerRadius: 24))
                .overlay(RoundedRectangle(cornerRadius: 24).stroke(NovaMaxPalette.red.opacity(0.65), lineWidth: 1))
            }
            .buttonStyle(.plain)
        }
    }
}

// ==========================================
// 3. MÀU SẮC VÀ BACKGROUND
// ==========================================
enum NovaMaxPalette {
    static let red = Color(red: 0.78, green: 0.035, blue: 0.055)
    static let green = Color(red: 0.12, green: 0.82, blue: 0.36)
}

struct NovaMaxBackground: View {
    var body: some View {
        GeometryReader { proxy in
            ZStack {
                Color.black
                Path { path in
                    let spacing: CGFloat = 62
                    stride(from: CGFloat.zero, through: proxy.size.width, by: spacing).forEach { x in
                        path.move(to: CGPoint(x: x, y: 0))
                        path.addLine(to: CGPoint(x: x, y: proxy.size.height))
                    }
                    stride(from: CGFloat.zero, through: proxy.size.height, by: spacing).forEach { y in
                        path.move(to: CGPoint(x: 0, y: y))
                        path.addLine(to: CGPoint(x: proxy.size.width, y: y))
                    }
                }
                .stroke(NovaMaxPalette.red.opacity(0.075), lineWidth: 0.7)
            }
            .ignoresSafeArea()
        }
    }
}
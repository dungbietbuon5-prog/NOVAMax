import SwiftUI
import UIKit
import AVFoundation
import Foundation

// ==========================================
// 1. LOGIC PATCH TỰ ĐỘNG (DÀNH CHO TROLLSTORE)
// ==========================================
class NovaMaxManager: ObservableObject {
    // Tên file game cần patch
    let targetFileName = "assetindexer.YJ~2FW7EkU5pRkVg51NrKyx4LXid8~3D"
    
    @Published var aimStates: [String: Bool] = [
        "Aim Head": false,
        "Aim Neck": false,
        "Aim Body": false,
        "Aim Drag": false
    ]
    
    // Tự động tìm đường dẫn FF Max
    private func getGamePath() -> String? {
        let fileManager = FileManager.default
        let appsPath = "/var/mobile/Containers/Data/Application/"
        if let apps = try? fileManager.contentsOfDirectory(atPath: appsPath) {
            for appUUID in apps {
                let appPath = appsPath + appUUID
                let metadataPath = appPath + "/.com.apple.mobile_container_manager.metadata.plist"
                if let dict = NSDictionary(contentsOfFile: metadataPath),
                   let bundleID = dict["MCMMetadataIdentifier"] as? String,
                   bundleID == "com.dts.freefiremax" { // Chỉ tìm FF Max
                    if let enumerator = fileManager.enumerator(atPath: appPath) {
                        for case let path as String in enumerator {
                            if path.hasSuffix(targetFileName) { return appPath + "/" + path }
                        }
                    }
                }
            }
        }
        return nil
    }
    
    // Logic Gạt Bật / Tắt
    func toggle(aimName: String, packageFileName: String, isOn: Bool) {
        guard let gameFilePath = getGamePath() else { return }
        let fileManager = FileManager.default
        let backupPath = gameFilePath + ".bak"
        
        if isOn {
            // PATCH
            if !fileManager.fileExists(atPath: backupPath) {
                try? fileManager.copyItem(atPath: gameFilePath, toPath: backupPath)
            }
            guard let patchPath = Bundle.main.path(forResource: packageFileName, ofType: "patch") else {
                print("Không tìm thấy file \(packageFileName).patch")
                aimStates[aimName] = false
                return
            }
            
            try? fileManager.removeItem(atPath: gameFilePath)
            try? fileManager.copyItem(atPath: patchPath, toPath: gameFilePath)
            aimStates[aimName] = true
            PatchAudioFeedback.bypassActivated()
        } else {
            // RESTORE
            if fileManager.fileExists(atPath: backupPath) {
                try? fileManager.removeItem(atPath: gameFilePath)
                try? fileManager.moveItem(atPath: backupPath, toPath: gameFilePath)
                aimStates[aimName] = false
                PatchAudioFeedback.originalRestored()
            }
        }
    }
    
    // Mở Game
    func openFFMax() {
        if let url = URL(string: "freefiremax://") {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }
    }
}

// ==========================================
// 2. GIAO DIỆN CHÍNH (CONTENT VIEW)
// ==========================================
struct ContentView: View {
    @EnvironmentObject private var appState: AppState
    @State private var showSettings = false
    @State private var showCleaner = false
    
    @StateObject private var manager = NovaMaxManager()
    @State private var patchMessage = "READY — SELECT A PATCH"

    var body: some View {
        ZStack {
            AnimatedHyperBackdrop().ignoresSafeArea()

            ScrollView(showsIndicators: false) {
                VStack(spacing: 18) {
                    brandHeader
                    devicePanel
                    patchOptions
                    gameLaunchPanel
                    footerStatus
                    developerCredits
                }
                .padding(.horizontal, 18)
                .padding(.top, 18)
                .padding(.bottom, 28)
            }
        }
        .preferredColorScheme(.dark)
        .sheet(isPresented: $showSettings) { SettingsView() }
        .sheet(isPresented: $showCleaner) { CleanerView() }
    }

    private var brandHeader: some View {
        HStack(spacing: 14) {
            VStack(alignment: .leading, spacing: 3) {
                Text("NOVAMAX")
                    .font(.system(size: 25, weight: .black, design: .rounded))
                    .tracking(3)
                    .foregroundStyle(.white)
                Text("PATCH CONTROL CENTER")
                    .font(.system(size: 10, weight: .bold, design: .rounded))
                    .tracking(1.7)
                    .foregroundStyle(AppTheme.accent)
            }
            Spacer()
            Button { showSettings = true } label: {
                Image(systemName: "gearshape.fill")
                    .font(.system(size: 20, weight: .bold))
                    .foregroundStyle(AppTheme.accent)
                    .frame(width: 48, height: 48)
                    .background(Color.black.opacity(0.38), in: Circle())
                    .overlay(Circle().stroke(AppTheme.accent.opacity(0.42), lineWidth: 1))
            }
            .buttonStyle(.plain)
        }
    }

    private var devicePanel: some View {
        VStack(spacing: 0) {
            panelTitle("DEVICE STATUS", icon: "shield.lefthalf.filled")
            statusRow(icon: "apple.logo", title: "iOS", value: AppInfo.osVersion, color: AppTheme.secondaryAccent)
            statusRow(icon: "iphone", title: "Device", value: AppInfo.displayMachineName, color: AppTheme.secondaryAccent)
            statusRow(icon: "checkmark.seal.fill", title: "Support", value: appState.isSupported ? "SUPPORTED" : "UNSUPPORTED", color: appState.isSupported ? .green : .red)
        }
        .padding(16)
        .background(Color.black.opacity(0.42), in: RoundedRectangle(cornerRadius: 24, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).stroke(AppTheme.accent.opacity(0.38), lineWidth: 1))
    }

    private var patchOptions: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                panelTitle("PATCH OPTIONS", icon: "bolt.fill")
                Spacer()
                Text("TOGGLE TO ENABLE")
                    .font(.system(size: 9, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.45))
            }

            LazyVGrid(columns: [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)], spacing: 12) {
                // CHỈ GIỮ LẠI 4 AIM, DÙNG NÚT GẠT
                patchCardToggle(name: "Aim Head", package: "AimHead", color: AppTheme.accent)
                patchCardToggle(name: "Aim Neck", package: "AimNeck", color: AppTheme.secondaryAccent)
                patchCardToggle(name: "Aim Body", package: "AimBody", color: AppTheme.accent)
                patchCardToggle(name: "Aim Drag", package: "AimDrag", color: AppTheme.secondaryAccent)
            }

            HStack(spacing: 8) {
                Circle().fill(AppTheme.accent).frame(width: 7, height: 7)
                Text(patchMessage)
                    .font(.system(size: 10, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.72))
                    .lineLimit(2)
                Spacer()
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 10)
            .background(Color.black.opacity(0.34), in: Capsule())
        }
    }

    private func patchCardToggle(name: String, package: String, color: Color) -> some View {
        VStack(alignment: .leading, spacing: 11) {
            HStack {
                Image(systemName: "bolt.fill").font(.system(size: 16, weight: .black)).foregroundStyle(color)
                Spacer()
                // NÚT GẠT TỰ ĐỘNG PATCH
                Toggle("", isOn: Binding(
                    get: { manager.aimStates[name] ?? false },
                    set: { newValue in
                        manager.toggle(aimName: name, packageFileName: package, isOn: newValue)
                        patchMessage = newValue ? "SUCCESS — PATCHED \(name)" : "SUCCESS — RESTORED \(name)"
                    }
                ))
                .labelsHidden()
                .tint(.green)
            }
            Text(name)
                .font(.system(size: 17, weight: .black, design: .rounded))
                .foregroundStyle(.white)
                .lineLimit(2)
                .minimumScaleFactor(0.78)
            Text("FREE FIRE • MAX")
                .font(.system(size: 10, weight: .black, design: .rounded))
                .tracking(1.3)
                .foregroundStyle(color)
        }
        .frame(maxWidth: .infinity, minHeight: 142, alignment: .leading)
        .padding(14)
        .background(Color.black.opacity(0.52), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke((manager.aimStates[name] == true ? Color.green : color).opacity(0.7), lineWidth: manager.aimStates[name] == true ? 1.5 : 1))
    }

    private var gameLaunchPanel: some View {
        VStack(alignment: .leading, spacing: 12) {
            panelTitle("LAUNCH GAME", icon: "arrow.up.forward.app.fill")
            HStack(spacing: 12) {
                // CHỈ GIỮ LẠI FF MAX
                launchButton(title: "FF MAX", subtitle: "Free Fire Max", color: AppTheme.accent)
            }
            Button {
                showCleaner = true
            } label: {
                Label("Clean Cache & Temp", systemImage: "trash.slash.fill")
                    .font(.system(size: 13, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity, minHeight: 52)
                    .background(Color.black.opacity(0.40), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(AppTheme.accent.opacity(0.52), lineWidth: 1))
            }
            .buttonStyle(.plain)
        }
    }

    private func launchButton(title: String, subtitle: String, color: Color) -> some View {
        Button { manager.openFFMax() } label: {
            VStack(alignment: .leading, spacing: 7) {
                Image(systemName: "arrow.up.right.square.fill")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundStyle(color)
                Text(title)
                    .font(.system(size: 13, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text(subtitle)
                    .font(.system(size: 10, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.5))
            }
            .frame(maxWidth: .infinity, minHeight: 82, alignment: .leading)
            .padding(.horizontal, 14)
            .background(Color.black.opacity(0.40), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(color.opacity(0.38), lineWidth: 1))
        }
        .buttonStyle(.plain)
    }

    private var footerStatus: some View {
        HStack(spacing: 10) {
            Circle().fill(.green).frame(width: 9, height: 9).shadow(color: .green, radius: 6)
            Text("SYSTEM READY")
                .font(.system(size: 10, weight: .black, design: .rounded))
                .tracking(1.2)
                .foregroundStyle(.white.opacity(0.72))
            Spacer()
            Text("NOVAMAX • READY")
                .font(.system(size: 9, weight: .bold, design: .rounded))
                .foregroundStyle(AppTheme.accent.opacity(0.8))
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 13)
        .background(Color.black.opacity(0.45), in: Capsule())
        .overlay(Capsule().stroke(AppTheme.accent.opacity(0.2), lineWidth: 1))
    }

    private var developerCredits: some View {
        VStack(spacing: 10) {
            Text("Developed by NOVAMAX")
                .font(.system(size: 11, weight: .bold, design: .rounded))
                .foregroundStyle(.white.opacity(0.72))
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.top, 4)
        .padding(.bottom, 8)
    }

    private func panelTitle(_ title: String, icon: String) -> some View {
        Label(title, systemImage: icon)
            .font(.system(size: 12, weight: .black, design: .rounded))
            .tracking(1.4)
            .foregroundStyle(AppTheme.accent)
    }

    private func statusRow(icon: String, title: String, value: String, color: Color) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon).font(.system(size: 17, weight: .bold)).foregroundStyle(color).frame(width: 24)
            Text(title).font(.system(size: 14, weight: .semibold, design: .rounded)).foregroundStyle(.white.opacity(0.58))
            Spacer()
            Text(value).font(.system(size: 14, weight: .black, design: .rounded)).foregroundStyle(.white)
        }
        .padding(.top, 14)
    }
}

// ==========================================
// 3. ÂM THANH VÀ BACKGROUND
// ==========================================
private enum PatchAudioFeedback {
    private static let synthesizer = AVSpeechSynthesizer()
    static func bypassActivated() { speak("Bypass ativado") }
    static func originalRestored() { speak("Bypass desativado") }
    private static func speak(_ message: String) {
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.playback, mode: .spokenAudio, options: [.duckOthers])
        try? session.setActive(true, options: [])
        synthesizer.stopSpeaking(at: .immediate)
        let utterance = AVSpeechUtterance(string: message)
        utterance.voice = AVSpeechSynthesisVoice(language: "pt-BR")
        utterance.rate = 0.43
        utterance.pitchMultiplier = 1.10
        utterance.volume = 0.90
        synthesizer.speak(utterance)
    }
}

struct AnimatedHyperBackdrop: View {
    @State private var animate = false
    var body: some View {
        GeometryReader { proxy in
            ZStack {
                AppTheme.pageBackground
                Circle()
                    .fill(AppTheme.accent.opacity(0.12))
                    .frame(width: 280, height: 280)
                    .blur(radius: 70)
                    .offset(x: animate ? 120 : -120, y: -proxy.size.height * 0.23)
                Circle()
                    .fill(AppTheme.secondaryAccent.opacity(0.08))
                    .frame(width: 260, height: 260)
                    .blur(radius: 80)
                    .offset(x: animate ? -100 : 100, y: proxy.size.height * 0.22)
                GridOverlay()
            }
            .onAppear {
                withAnimation(.easeInOut(duration: 7).repeatForever(autoreverses: true)) { animate = true }
            }
        }
    }
}

private struct GridOverlay: View {
    var body: some View {
        Canvas { context, size in
            var path = Path()
            let spacing: CGFloat = 44
            stride(from: CGFloat(0), through: size.width, by: spacing).forEach { x in
                path.move(to: CGPoint(x: x, y: 0)); path.addLine(to: CGPoint(x: x, y: size.height))
            }
            stride(from: CGFloat(0), through: size.height, by: spacing).forEach { y in
                path.move(to: CGPoint(x: 0, y: y)); path.addLine(to: CGPoint(x: size.width, y: y))
            }
            context.stroke(path, with: .color(AppTheme.accent.opacity(0.055)), lineWidth: 1)
        }
    }
}
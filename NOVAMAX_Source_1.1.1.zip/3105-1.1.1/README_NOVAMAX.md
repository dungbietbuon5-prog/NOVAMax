# NOVAMAX 1.1.1 — source package

## Build
1. Open `ThreeOneOSFive.xcodeproj` in Xcode on macOS.
2. Select the `ThreeOneOSFive` scheme.
3. Set your Apple development team and signing settings.
4. Build or Archive for your own test device.

The installed app display name and product name are set to **NOVAMAX**.
Bundle identifier: `com.novamax.ios`.

## Patch controls
The four `.3105` controls are local package-state indicators only. They do not inject code,
modify another app, or change Free Fire / Free Fire MAX. The status messages were changed
to avoid claiming that game patching occurred. Use the included patch-project tools only
for apps and test containers you own or are authorized to modify.

import SwiftUI
import UIKit

struct ContentView: View {
    @Environment(\.appLanguage) private var language
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    @EnvironmentObject private var patchDraftCoordinator: PatchDraftCoordinator
    @State private var tabNavigation: AppTabNavigationState
    @AppStorage(FeatureVisibility.cleanerStorageKey) private var cleanerEnabled = true
    @AppStorage(FeatureVisibility.wallpapersStorageKey) private var wallpapersEnabled = true

    init() {
#if targetEnvironment(simulator)
        let arguments = ProcessInfo.processInfo.arguments
        let initialTab: Int
        if arguments.contains("--simulate-files-tab") {
            initialTab = 1
        } else if arguments.contains("--simulate-patch-tab") {
            initialTab = 2
        } else if arguments.contains("--simulate-cleaner-tab") {
            initialTab = 3
        } else if arguments.contains("--simulate-wallpaper-tab") {
            initialTab = 4
        } else {
            initialTab = 0
        }
        _tabNavigation = State(initialValue: AppTabNavigationState(selectedTab: initialTab))
#else
        _tabNavigation = State(initialValue: AppTabNavigationState())
#endif
    }

    var body: some View {
        Group {
            if horizontalSizeClass == .regular {
                regularLayout
            } else {
                compactLayout
            }
        }
        .tint(AppTheme.accent)
        .imageScale(.small)
        .onChange(of: patchDraftCoordinator.request?.id) { requestID in
            if requestID != nil { tabNavigation.select(AppSection.patches.rawValue) }
        }
        .onChange(of: patchDraftCoordinator.importRequest?.id) { requestID in
            if requestID != nil { tabNavigation.select(AppSection.patches.rawValue) }
        }
        .onChange(of: cleanerEnabled) { _ in
            tabNavigation.reconcileSelection(with: featureVisibility)
        }
        .onChange(of: wallpapersEnabled) { _ in
            tabNavigation.reconcileSelection(with: featureVisibility)
        }
        .onAppear {
            tabNavigation.reconcileSelection(with: featureVisibility)
        }
    }

    private var compactLayout: some View {
        TabView(selection: tabSelection) {
            ForEach(featureVisibility.visibleSections) { section in
                sectionContent(section)
                    .tabItem {
                        CompactTabLabel(
                            title: language.text(section.titleKey),
                            systemImage: section.systemImage
                        )
                    }
                    .tag(section.rawValue)
            }
        }
    }

    private var regularLayout: some View {
        NavigationSplitView {
            List {
                ForEach(featureVisibility.visibleSections) { section in
                    Button {
                        withAnimation(.easeInOut(duration: 0.18)) {
                            tabNavigation.select(section.rawValue)
                        }
                    } label: {
                        Label(language.text(section.titleKey), systemImage: section.systemImage)
                            .fontWeight(section.rawValue == tabNavigation.selectedTab ? .semibold : .regular)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .listRowBackground(
                        section.rawValue == tabNavigation.selectedTab
                            ? AppTheme.accent.opacity(0.14)
                            : Color.clear
                    )
                    .accessibilityAddTraits(
                        section.rawValue == tabNavigation.selectedTab ? .isSelected : []
                    )
                }
            }
            .navigationTitle("3105")
            .navigationSplitViewColumnWidth(min: 210, ideal: 240, max: 300)
        } detail: {
            sectionContent(selectedVisibleSection)
                .id(selectedVisibleSection.rawValue)
        }
        .navigationSplitViewStyle(.balanced)
    }

    @ViewBuilder
    private func sectionContent(_ section: AppSection) -> some View {
        switch section {
        case .home:
            DashboardView(
                cleanerEnabled: $cleanerEnabled,
                wallpapersEnabled: $wallpapersEnabled,
                wallpapersSupported: wallpapersSupported
            )
        case .files:
            AppDataBrowserView(
                tabSession: filesTabSession
            )
        case .patches:
            PatchProjectsView()
        case .cleaner:
            CleanerView()
        case .wallpapers:
            WallpaperLabView()
        }
    }

    private var tabSelection: Binding<Int> {
        Binding(
            get: { tabNavigation.selectedTab },
            set: { tabNavigation.select($0) }
        )
    }

    private var filesTabSession: Binding<FilesTabSession> {
        Binding(
            get: { tabNavigation.filesTabs },
            set: { tabNavigation.setFilesTabs($0) }
        )
    }

    private var featureVisibility: FeatureVisibility {
        FeatureVisibility(
            cleanerEnabled: cleanerEnabled,
            wallpapersEnabled: wallpapersEnabled,
            wallpapersSupported: wallpapersSupported
        )
    }

    private var wallpapersSupported: Bool {
        WallpaperFeatureSupportPolicy.isSupported(major: AppInfo.versionTuple.major)
    }

    private var selectedVisibleSection: AppSection {
        guard let section = AppSection(rawValue: tabNavigation.selectedTab),
              featureVisibility.isVisible(section) else {
            return .home
        }
        return section
    }
}

private struct CompactTabLabel: View {
    let title: String
    let systemImage: String

    @ViewBuilder
    var body: some View {
        if let image = UIImage(
            systemName: systemImage,
            withConfiguration: UIImage.SymbolConfiguration(pointSize: 17, weight: .medium)
        )?.withRenderingMode(.alwaysTemplate) {
            Image(uiImage: image)
        } else {
            Image(systemName: systemImage)
                .font(.system(size: 17, weight: .medium))
        }
        Text(title)
    }
}

private extension AppSection {
    var titleKey: String {
        switch self {
        case .home: return "tab.home"
        case .files: return "tab.files"
        case .patches: return "tab.patches"
        case .cleaner: return "tab.cleaner"
        case .wallpapers: return "tab.wallpapers"
        }
    }

    var systemImage: String {
        switch self {
        case .home: return "house.fill"
        case .files: return "folder.fill"
        case .patches: return "shippingbox.fill"
        case .cleaner: return "sparkles"
        case .wallpapers: return "photo.on.rectangle.angled"
        }
    }
}

private struct DashboardView: View {
    @Environment(\.appLanguage) private var language
    @EnvironmentObject private var appState: AppState
    @State private var showSettings = false
    @State private var showLogs = false
    @State private var showPatchLibrary = false
    @State private var showCleaner = false
    @Binding var cleanerEnabled: Bool
    @Binding var wallpapersEnabled: Bool
    let wallpapersSupported: Bool

    private let patchNames = ["Aim Drag", "Aim Neck", "Aim Body", "Aim Bot"]
    private let columns = [GridItem(.flexible(), spacing: 14), GridItem(.flexible(), spacing: 14)]

    var body: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 24) {
                    header
                    deviceStatus
                    patchOptions
                    launchGame
                    cleanButton
                    systemStatus
                    footer
                }
                .padding(.horizontal, 18)
                .padding(.top, 12)
                .padding(.bottom, 28)
            }
            .background(OGIOSBackground())
            .toolbar(.hidden, for: .navigationBar)
            .preferredColorScheme(.dark)
            .sheet(isPresented: $showSettings) { SettingsView() }
            .sheet(isPresented: $showLogs) { LogView() }
            .sheet(isPresented: $showPatchLibrary) { PatchProjectsView() }
            .sheet(isPresented: $showCleaner) { CleanerView() }
        }
    }

    private var header: some View {
        HStack(alignment: .center) {
            VStack(alignment: .leading, spacing: 5) {
                Text("OGIOS")
                    .font(.system(size: 34, weight: .black, design: .rounded))
                    .tracking(6)
                    .foregroundStyle(.white)
                Text("PATCH CONTROL CENTER")
                    .font(.system(size: 12, weight: .heavy, design: .rounded))
                    .tracking(3)
                    .foregroundStyle(OGIOSPalette.red)
            }
            Spacer()
            Button { showSettings = true } label: {
                Image(systemName: "gearshape.fill")
                    .font(.system(size: 22, weight: .semibold))
                    .foregroundStyle(OGIOSPalette.red)
                    .frame(width: 58, height: 58)
                    .background(Color.black.opacity(0.65), in: Circle())
                    .overlay(Circle().stroke(OGIOSPalette.red.opacity(0.45), lineWidth: 1))
            }
            .accessibilityLabel("Settings")
        }
        .padding(.top, 8)
    }

    private var deviceStatus: some View {
        VStack(spacing: 18) {
            sectionTitle("◈  DEVICE STATUS")
            statusRow(icon: "apple.logo", label: "iOS", value: AppInfo.osVersion)
            statusRow(icon: "iphone", label: "Device", value: AppInfo.displayMachineName)
            HStack(spacing: 12) {
                Image(systemName: "checkmark.seal.fill")
                    .font(.system(size: 22))
                    .foregroundStyle(appState.isSupported ? OGIOSPalette.green : OGIOSPalette.red)
                    .frame(width: 34)
                Text("Support")
                    .foregroundStyle(.white.opacity(0.68))
                Spacer()
                Text(appState.isSupported ? "SUPPORTED" : "UNSUPPORTED")
                    .font(.system(size: 14, weight: .black, design: .rounded))
                    .foregroundStyle(appState.isSupported ? OGIOSPalette.green : OGIOSPalette.red)
            }
        }
        .padding(20)
        .background(Color.black.opacity(0.72), in: RoundedRectangle(cornerRadius: 28))
        .overlay(RoundedRectangle(cornerRadius: 28).stroke(OGIOSPalette.red.opacity(0.55), lineWidth: 1))
    }

    private var patchOptions: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(alignment: .firstTextBaseline) {
                sectionTitle("ϟ  PATCH OPTIONS")
                Spacer()
                Text("PACKAGE INVENTORY")
                    .font(.system(size: 9, weight: .bold, design: .rounded))
                    .tracking(1)
                    .foregroundStyle(.white.opacity(0.42))
            }
            LazyVGrid(columns: columns, spacing: 14) {
                ForEach(patchNames, id: \.self) { name in
                    Button { showPatchLibrary = true } label: {
                        VStack(alignment: .leading, spacing: 13) {
                            HStack {
                                Image(systemName: "bolt.fill")
                                    .font(.system(size: 24, weight: .bold))
                                    .foregroundStyle(name == "Aim Drag" || name == "Aim Body" ? OGIOSPalette.red : .white)
                                Spacer()
                                Text("FILE")
                                    .font(.system(size: 10, weight: .black, design: .rounded))
                                    .foregroundStyle(.white.opacity(0.55))
                            }
                            Text(name)
                                .font(.system(size: 21, weight: .heavy, design: .rounded))
                                .foregroundStyle(.white)
                                .lineLimit(1)
                                .minimumScaleFactor(0.8)
                            Text("3105 PACKAGE")
                                .font(.system(size: 10, weight: .black, design: .rounded))
                                .tracking(1.6)
                                .foregroundStyle(name == "Aim Drag" || name == "Aim Body" ? OGIOSPalette.red : .white)
                            HStack(spacing: 7) {
                                Circle().fill(OGIOSPalette.red).frame(width: 7, height: 7)
                                Text("OPEN PATCH LIBRARY")
                                    .font(.system(size: 9, weight: .heavy, design: .rounded))
                                    .tracking(1)
                                    .foregroundStyle(.white.opacity(0.7))
                            }
                        }
                        .frame(maxWidth: .infinity, minHeight: 148, alignment: .leading)
                        .padding(16)
                        .background(Color.black.opacity(0.76), in: RoundedRectangle(cornerRadius: 25))
                        .overlay(RoundedRectangle(cornerRadius: 25).stroke((name == "Aim Drag" || name == "Aim Body" ? OGIOSPalette.red : Color.white.opacity(0.35)).opacity(0.7), lineWidth: 1))
                    }
                    .buttonStyle(.plain)
                }
            }
            Text("Patch files are listed from the supplied 3105 archive. Select a card to open the original patch library.")
                .font(.system(size: 11, weight: .medium))
                .foregroundStyle(.white.opacity(0.48))
        }
    }

    private var launchGame: some View {
        VStack(alignment: .leading, spacing: 14) {
            sectionTitle("↗  LAUNCH GAME")
            HStack(spacing: 14) {
                gameTile(title: "FF NORMAL", subtitle: "Free Fire Normal", locked: false)
                gameTile(title: "FF MAX", subtitle: "Not configured", locked: true)
            }
        }
    }

    private func gameTile(title: String, subtitle: String, locked: Bool) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Image(systemName: locked ? "lock.fill" : "arrow.up.right.square.fill")
                .font(.system(size: 24, weight: .bold))
                .foregroundStyle(locked ? .white.opacity(0.48) : OGIOSPalette.red)
            Text(title)
                .font(.system(size: 17, weight: .black, design: .rounded))
                .foregroundStyle(locked ? .white.opacity(0.48) : .white)
            Text(subtitle)
                .font(.system(size: 12, weight: .medium))
                .foregroundStyle(.white.opacity(0.48))
        }
        .frame(maxWidth: .infinity, minHeight: 112, alignment: .leading)
        .padding(16)
        .background(Color.black.opacity(0.72), in: RoundedRectangle(cornerRadius: 24))
        .overlay(RoundedRectangle(cornerRadius: 24).stroke(locked ? Color.white.opacity(0.25) : OGIOSPalette.red.opacity(0.65), lineWidth: 1))
    }

    private var cleanButton: some View {
        Button { showCleaner = true } label: {
            HStack(spacing: 12) {
                Image(systemName: "trash.slash.fill")
                Text("Clean Cache & Temp")
                    .font(.system(size: 17, weight: .heavy, design: .rounded))
            }
            .foregroundStyle(.white)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 22)
            .background(Color.black.opacity(0.72), in: RoundedRectangle(cornerRadius: 24))
            .overlay(RoundedRectangle(cornerRadius: 24).stroke(OGIOSPalette.red.opacity(0.65), lineWidth: 1))
        }
        .buttonStyle(.plain)
        .disabled(!cleanerEnabled)
        .opacity(cleanerEnabled ? 1 : 0.45)
    }

    private var systemStatus: some View {
        HStack(spacing: 12) {
            Circle().fill(OGIOSPalette.green).frame(width: 11, height: 11)
            Text("SISTEMA PRONTO")
                .font(.system(size: 13, weight: .black, design: .rounded))
                .tracking(2)
                .foregroundStyle(.white.opacity(0.8))
            Spacer()
            Text("OGIOS • 3105")
                .font(.system(size: 11, weight: .bold, design: .rounded))
                .foregroundStyle(OGIOSPalette.red)
        }
        .padding(.horizontal, 18)
        .padding(.vertical, 19)
        .background(Color.black.opacity(0.72), in: Capsule())
        .overlay(Capsule().stroke(OGIOSPalette.red.opacity(0.4), lineWidth: 1))
    }

    private var footer: some View {
        VStack(spacing: 10) {
            Text("Developed by OGIOS")
                .font(.system(size: 15, weight: .bold))
                .foregroundStyle(.white.opacity(0.75))
            Button { showLogs = true } label: {
                Label("SYSTEM LOGS", systemImage: "terminal")
                    .font(.system(size: 11, weight: .heavy, design: .rounded))
                    .tracking(1.4)
                    .foregroundStyle(OGIOSPalette.red)
            }
        }
        .frame(maxWidth: .infinity)
        .padding(.top, 4)
    }

    private func sectionTitle(_ title: String) -> some View {
        Text(title)
            .font(.system(size: 14, weight: .black, design: .rounded))
            .tracking(2)
            .foregroundStyle(OGIOSPalette.red)
    }

    private func statusRow(icon: String, label: String, value: String) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 22, weight: .semibold))
                .foregroundStyle(.white)
                .frame(width: 34)
            Text(label).foregroundStyle(.white.opacity(0.68))
            Spacer()
            Text(value)
                .font(.system(size: 14, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
                .lineLimit(1)
                .minimumScaleFactor(0.75)
        }
    }
}

private enum OGIOSPalette {
    static let red = Color(red: 0.78, green: 0.035, blue: 0.055)
    static let green = Color(red: 0.12, green: 0.82, blue: 0.36)
}

private struct OGIOSBackground: View {
    var body: some View {
        GeometryReader { proxy in
            ZStack {
                Color.black
                Path { path in
                    let spacing: CGFloat = 62
                    stride(from: CGFloat.zero, through: proxy.size.width, by: spacing).forEach { x in
                        path.move(to: CGPoint(x: x, y: 0))
                        path.addLine(to: CGPoint(x: x, y: proxy.size.height))
                    }
                    stride(from: CGFloat.zero, through: proxy.size.height, by: spacing).forEach { y in
                        path.move(to: CGPoint(x: 0, y: y))
                        path.addLine(to: CGPoint(x: proxy.size.width, y: y))
                    }
                }
                .stroke(OGIOSPalette.red.opacity(0.075), lineWidth: 0.7)
            }
            .ignoresSafeArea()
        }
    }
}

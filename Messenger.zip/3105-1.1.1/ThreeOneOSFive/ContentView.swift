import SwiftUI
import UIKit
import AVFoundation

struct ContentView: View {
    @Environment(\.scenePhase) private var scenePhase
    @EnvironmentObject private var appState: AppState
    @State private var showSettings = false
    @State private var showCleaner = false
    @StateObject private var patchStore = PatchProjectStore()
    @State private var patchOperationBusy = false
    @State private var patchMessage = "SẴN SÀNG — CHỌN PATCH"
    
    // Trạng thái cho các Aim
    @State private var aimHeadEnabled = false
    @State private var aimDragEnabled = false
    @State private var aimNeckEnabled = false
    @State private var aimBodyPackageEnabled = false
    @State private var aimBotEnabled = false

    // Trạng thái cho Định Vị
    @State private var dinhViNhanVatEnabled = false
    @State private var dinhViSungEnabled = false

    // Biến cho hiệu ứng Neon
    @State private var neonPhase = 0.0

    var body: some View {
        ZStack {
            NeonBackdrop(phase: neonPhase).ignoresSafeArea()

            ScrollView(showsIndicators: false) {
                VStack(spacing: 18) {
                    brandHeader
                    devicePanel
                    patchOptions
                    locationOptions
                    gameLaunchPanel
                    footerStatus
                    developerCredits
                }
                .padding(.horizontal, 18)
                .padding(.top, 18)
                .padding(.bottom, 28)
            }
        }
        .preferredColorScheme(.dark)
        .sheet(isPresented: $showSettings) { SettingsView() }
        .sheet(isPresented: $showCleaner) { CleanerView() }
        .onAppear { 
            syncPatchStates()
            // Bắt đầu animation neon
            withAnimation(.linear(duration: 3).repeatForever(autoreverses: false)) {
                neonPhase = 1.0
            }
        }
        .onChange(of: scenePhase) { phase in
            guard phase == .active, !patchOperationBusy else { return }
            syncPatchStates()
            patchMessage = "SẴN SÀNG — CHỌN PATCH"
        }
    }
    
    // Lấy màu neon xoay vòng
    private func neonColor(offset: Double = 0) -> Color {
        let hue = (neonPhase + offset).truncatingRemainder(dividingBy: 1.0)
        return Color(hue: hue, saturation: 1.0, brightness: 1.0)
    }
    
    private func getDeviceModelName() -> String {
        var systemInfo = utsname()
        uname(&systemInfo)
        let machineMirror = Mirror(reflecting: systemInfo.machine)
        let identifier = machineMirror.children.reduce("") { identifier, element in
            guard let value = element.value as? Int8, value != 0 else { return identifier }
            return identifier + String(UnicodeScalar(UInt8(value)))
        }
        let mapping = [
            "iPhone12,5": "iPhone 11 Pro Max", "iPhone12,3": "iPhone 11 Pro", "iPhone12,1": "iPhone 11",
            "iPhone13,4": "iPhone 12 Pro Max", "iPhone14,2": "iPhone 13 Pro", "iPhone14,3": "iPhone 13 Pro Max"
        ]
        return mapping[identifier] ?? identifier
    }

    private func getDeviceRAM() -> String {
        let physicalMemory = ProcessInfo.processInfo.physicalMemory
        return String(format: "%.0f GB", Double(physicalMemory) / 1024.0 / 1024.0 / 1024.0)
    }

    private func getFreeStorage() -> String {
        if let attributes = try? FileManager.default.attributesOfFileSystem(forPath: NSHomeDirectory()),
           let space = attributes[.systemFreeSize] as? Int64 {
            return String(format: "%.1f GB Free", Double(space) / 1024.0 / 1024.0 / 1024.0)
        }
        return "Unknown"
    }

    private var brandHeader: some View {
        HStack(spacing: 14) {
            VStack(alignment: .leading, spacing: 3) {
                Text("NOVAMAX")
                    .font(.system(size: 28, weight: .black, design: .rounded))
                    .tracking(4)
                    .foregroundStyle(
                        LinearGradient(
                            colors: [neonColor(offset: 0.0), neonColor(offset: 0.5)],
                            startPoint: .topLeading, endPoint: .bottomTrailing
                        )
                    )
                    .shadow(color: neonColor(offset: 0.2), radius: 8, x: 0, y: 0)
                
                Text("TRUNG TÂM ĐIỀU KHIỂN")
                    .font(.system(size: 10, weight: .bold, design: .rounded))
                    .tracking(1.7)
                    .foregroundStyle(neonColor(offset: 0.5))
                    .shadow(color: neonColor(offset: 0.5), radius: 4)
            }
            Spacer()
            Button { showSettings = true } label: {
                Image(systemName: "gearshape.fill")
                    .font(.system(size: 20, weight: .bold))
                    .foregroundStyle(neonColor(offset: 0.8))
                    .frame(width: 48, height: 48)
                    .background(Color.black.opacity(0.6), in: Circle())
                    .overlay(Circle().stroke(neonColor(offset: 0.8), lineWidth: 1.5))
                    .shadow(color: neonColor(offset: 0.8).opacity(0.5), radius: 6)
            }
            .buttonStyle(.plain)
        }
    }

    private var devicePanel: some View {
        VStack(spacing: 0) {
            panelTitle("TRẠNG THÁI THIẾT BỊ", icon: "shield.lefthalf.filled")
            statusRow(icon: "apple.logo", title: "iOS", value: UIDevice.current.systemVersion, color: neonColor(offset: 0.1))
            statusRow(icon: "iphone", title: "Thiết bị", value: getDeviceModelName(), color: neonColor(offset: 0.3))
            statusRow(icon: "memorychip", title: "RAM", value: getDeviceRAM(), color: neonColor(offset: 0.6))
            statusRow(icon: "internaldrive", title: "Bộ nhớ", value: getFreeStorage(), color: neonColor(offset: 0.9))
            
            HStack(spacing: 12) {
                Image(systemName: "checkmark.seal.fill")
                    .font(.system(size: 22))
                    .foregroundStyle(appState.isSupported ? .green : .red)
                    .frame(width: 34)
                    .shadow(color: appState.isSupported ? .green.opacity(0.5) : .red.opacity(0.5), radius: 5)
                Text("Hỗ trợ").foregroundStyle(.white.opacity(0.68))
                Spacer()
                Text(appState.isSupported ? "ĐÃ HỖ TRỢ" : "CHƯA HỖ TRỢ")
                    .font(.system(size: 14, weight: .black, design: .rounded))
                    .foregroundStyle(appState.isSupported ? .green : .red)
                    .shadow(color: appState.isSupported ? .green.opacity(0.5) : .red.opacity(0.5), radius: 5)
            }
            .padding(.top, 14)
        }
        .padding(16)
        .background(Color.black.opacity(0.4), in: RoundedRectangle(cornerRadius: 24, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .stroke(LinearGradient(colors: [neonColor(offset: 0.0), neonColor(offset: 0.5)], startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 1.5)
        )
        .shadow(color: neonColor(offset: 0.2).opacity(0.3), radius: 10)
    }

    private var patchOptions: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                panelTitle("TÙY CHỌN AIM", icon: "scope")
                Spacer()
                Text("GẠT ĐỂ BẬT")
                    .font(.system(size: 9, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.45))
            }

            LazyVGrid(columns: [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)], spacing: 12) {
                patchCardToggle(name: "Aim Head", package: "AimHead.3105", state: $aimHeadEnabled, hueOffset: 0.0)
                patchCardToggle(name: "Aim Bot", package: "Aimbot.3105", state: $aimBotEnabled, hueOffset: 0.2)
                patchCardToggle(name: "Aim Drag", package: "AimDrag.3105", state: $aimDragEnabled, hueOffset: 0.4)
                patchCardToggle(name: "Aim Neck", package: "AimNeck.3105", state: $aimNeckEnabled, hueOffset: 0.6)
                patchCardToggle(name: "Aim Body", package: "AimBody.3105", state: $aimBodyPackageEnabled, hueOffset: 0.8)
            }

            HStack(spacing: 8) {
                Circle().fill(patchMessage.localizedCaseInsensitiveContains("THÀNH CÔNG") ? .green : neonColor()).frame(width: 7, height: 7).shadow(color: patchMessage.localizedCaseInsensitiveContains("THÀNH CÔNG") ? .green : neonColor(), radius: 4)
                Text(patchOperationBusy ? "ĐANG XỬ LÝ…" : patchMessage)
                    .font(.system(size: 10, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.8))
                    .lineLimit(2)
                Spacer()
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 10)
            .background(Color.black.opacity(0.5), in: Capsule())
            .overlay(Capsule().stroke(neonColor().opacity(0.3), lineWidth: 1))
        }
    }

    private var locationOptions: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                panelTitle("TÙY CHỌN ĐỊNH VỊ", icon: "location.fill")
                Spacer()
                Text("GẠT ĐỂ BẬT")
                    .font(.system(size: 9, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.45))
            }

            LazyVGrid(columns: [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)], spacing: 12) {
                patchCardToggle(name: "Định Vị Nhân Vật", package: "DinhViNhanVat.3105", state: $dinhViNhanVatEnabled, hueOffset: 0.3)
                patchCardToggle(name: "Định Vị Súng", package: "DinhViSung.3105", state: $dinhViSungEnabled, hueOffset: 0.7)
            }
        }
    }

    private func patchCardToggle(name: String, package: String, state: Binding<Bool>, hueOffset: Double) -> some View {
        let currentColor = neonColor(offset: hueOffset)
        
        return VStack(alignment: .leading, spacing: 11) {
            HStack {
                Image(systemName: "bolt.fill").font(.system(size: 16, weight: .black)).foregroundStyle(currentColor).shadow(color: currentColor, radius: 4)
                Spacer()
                Toggle("", isOn: Binding(
                    get: { state.wrappedValue },
                    set: { newValue in togglePatch(packageFilename: package, state: state) }
                ))
                .labelsHidden()
                .tint(currentColor)
            }
            Text(name).font(.system(size: 16, weight: .black, design: .rounded)).foregroundStyle(.white).lineLimit(1).minimumScaleFactor(0.8)
            Text("FREE FIRE • MAX").font(.system(size: 10, weight: .black, design: .rounded)).tracking(1.3).foregroundStyle(currentColor)
            
            HStack(spacing: 7) {
                Circle().fill(state.wrappedValue ? currentColor : Color.white.opacity(0.25)).frame(width: 8, height: 8).shadow(color: state.wrappedValue ? currentColor : .clear, radius: 4)
                Text(state.wrappedValue ? "ĐANG BẬT" : "BẬT PATCH")
                    .font(.system(size: 9, weight: .black, design: .rounded))
                    .tracking(0.8)
                    .foregroundStyle(.white.opacity(0.65))
            }
        }
        .frame(maxWidth: .infinity, minHeight: 142, alignment: .leading)
        .padding(14)
        .background(Color.black.opacity(0.6), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(state.wrappedValue ? currentColor : currentColor.opacity(0.3), lineWidth: state.wrappedValue ? 2 : 1)
        )
        .shadow(color: state.wrappedValue ? currentColor.opacity(0.4) : .clear, radius: 12)
    }

    private var gameLaunchPanel: some View {
        VStack(alignment: .leading, spacing: 12) {
            panelTitle("MỞ GAME", icon: "arrow.up.forward.app.fill")
            HStack(spacing: 12) {
                launchButton(title: "FF MAX", subtitle: "Free Fire Max", scheme: "freefiremax", hueOffset: 0.1)
            }
            Button { showCleaner = true } label: {
                Label("Dọn dẹp bộ nhớ", systemImage: "trash.slash.fill")
                    .font(.system(size: 13, weight: .black, design: .rounded)).foregroundStyle(.white)
                    .frame(maxWidth: .infinity, minHeight: 52)
                    .background(Color.black.opacity(0.4), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(neonColor(offset: 0.6).opacity(0.5), lineWidth: 1))
            }
            .buttonStyle(.plain)
        }
    }

    private func launchButton(title: String, subtitle: String, scheme: String, hueOffset: Double) -> some View {
        let color = neonColor(offset: hueOffset)
        return Button { openGame(scheme: scheme) } label: {
            VStack(alignment: .leading, spacing: 7) {
                Image(systemName: "arrow.up.right.square.fill").font(.system(size: 18, weight: .bold)).foregroundStyle(color).shadow(color: color, radius: 4)
                Text(title).font(.system(size: 13, weight: .black, design: .rounded)).foregroundStyle(.white)
                Text(subtitle).font(.system(size: 10, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.5))
            }
            .frame(maxWidth: .infinity, minHeight: 82, alignment: .leading)
            .padding(.horizontal, 14)
            .background(Color.black.opacity(0.4), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(color.opacity(0.6), lineWidth: 1))
        }
        .buttonStyle(.plain)
    }

    private var footerStatus: some View {
        HStack(spacing: 10) {
            Circle().fill(neonColor(offset: 0.5)).frame(width: 9, height: 9).shadow(color: neonColor(offset: 0.5), radius: 6)
            Text("HỆ THỐNG SẴN SÀNG").font(.system(size: 10, weight: .black, design: .rounded)).tracking(1.2).foregroundStyle(.white.opacity(0.72))
            Spacer()
            Text("NOVAMAX • READY").font(.system(size: 9, weight: .bold, design: .rounded)).foregroundStyle(neonColor(offset: 0.5))
        }
        .padding(.horizontal, 14).padding(.vertical, 13)
        .background(Color.black.opacity(0.6), in: Capsule())
        .overlay(Capsule().stroke(neonColor(offset: 0.5).opacity(0.3), lineWidth: 1))
    }

    private var developerCredits: some View {
        Text("Phát triển bởi NOVAMAX")
            .font(.system(size: 11, weight: .bold, design: .rounded))
            .foregroundStyle(neonColor(offset: 0.9).opacity(0.8))
            .frame(maxWidth: .infinity).padding(.top, 4).padding(.bottom, 8)
    }

    private func panelTitle(_ title: String, icon: String) -> some View {
        Label(title, systemImage: icon)
            .font(.system(size: 12, weight: .black, design: .rounded))
            .tracking(1.4)
            .foregroundStyle(neonColor())
            .shadow(color: neonColor().opacity(0.5), radius: 3)
    }

    private func statusRow(icon: String, title: String, value: String, color: Color) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon).font(.system(size: 17, weight: .bold)).foregroundStyle(color).frame(width: 24).shadow(color: color.opacity(0.5), radius: 3)
            Text(title).font(.system(size: 14, weight: .semibold, design: .rounded)).foregroundStyle(.white.opacity(0.58))
            Spacer()
            Text(value).font(.system(size: 14, weight: .black, design: .rounded)).foregroundStyle(.white)
        }
        .padding(.top, 14)
    }

    // --- LOGIC QUÉT FILE VÀ PATCH ---
    private func syncPatchStates() {
        aimHeadEnabled = isPatchActive("AimHead.3105")
        aimBotEnabled = isPatchActive("Aimbot.3105")
        aimDragEnabled = isPatchActive("AimDrag.3105")
        aimNeckEnabled = isPatchActive("AimNeck.3105")
        aimBodyPackageEnabled = isPatchActive("AimBody.3105")
        
        dinhViNhanVatEnabled = isPatchActive("DinhViNhanVat.3105")
        dinhViSungEnabled = isPatchActive("DinhViSung.3105")
    }

    private func isPatchActive(_ packageFilename: String) -> Bool {
        patchStore.items.first(where: { $0.packageURL.lastPathComponent.caseInsensitiveCompare(packageFilename) == .orderedSame })
            .flatMap { DevicePatchService.latestReceipt(projectID: $0.id) } != nil
    }

    private enum PatchActionResult {
        case applied
        case restored
        case unavailable(String)
    }

    private func setPatchState(for packageFilename: String, enabled: Bool) {
        switch packageFilename.lowercased() {
        case "aimhead.3105": aimHeadEnabled = enabled
        case "aimbot.3105": aimBotEnabled = enabled
        case "aimdrag.3105": aimDragEnabled = enabled
        case "aimneck.3105": aimNeckEnabled = enabled
        case "aimbody.3105": aimBodyPackageEnabled = enabled
        case "dinhvinhanvat.3105": dinhViNhanVatEnabled = enabled
        case "dinhvisung.3105": dinhViSungEnabled = enabled
        default: break
        }
    }

    private func togglePatch(packageFilename: String, state: Binding<Bool>) {
        guard !patchOperationBusy else { return }
        guard let item = patchStore.items.first(where: { $0.packageURL.lastPathComponent.caseInsensitiveCompare(packageFilename) == .orderedSame }) else {
            patchMessage = "❌ KHÔNG TÌM THẤY FILE"
            return
        }

        let wasEnabled = state.wrappedValue
        patchOperationBusy = true
        patchMessage = "ĐANG XỬ LÝ…"
        let project = item.project
        let projectID = item.id

        DispatchQueue.global(qos: .userInitiated).async {
            let result: PatchActionResult
            do {
                if wasEnabled {
                    guard let receipt = DevicePatchService.latestReceipt(projectID: projectID) else {
                        result = .unavailable("KHÔNG CÓ GÓI ĐỂ KHÔI PHỤC")
                        DispatchQueue.main.async {
                            self.setPatchState(for: packageFilename, enabled: false)
                            self.patchMessage = "❌ KHÔNG CÓ GÓI ĐỂ KHÔI PHỤC"
                            self.patchOperationBusy = false
                        }
                        return
                    }
                    try DevicePatchService.restore(receipt: receipt)
                    result = .restored
                } else {
                    guard let project else {
                        result = .unavailable("YÊU CẦU MẬT KHẨU")
                        DispatchQueue.main.async {
                            self.patchMessage = "❌ FILE BỊ KHOÁ MẬT KHẨU"
                            self.patchOperationBusy = false
                        }
                        return
                    }
                    _ = try DevicePatchService.apply(project: project)
                    result = .applied
                }
            } catch {
                result = .unavailable("THẤT BẠI")
            }

            DispatchQueue.main.async {
                switch result {
                case .applied:
                    self.setPatchState(for: packageFilename, enabled: true)
                    let shortName = packageFilename.replacingOccurrences(of: ".3105", with: "")
                    self.patchMessage = "Bật \(shortName) thành công"
                case .restored:
                    self.setPatchState(for: packageFilename, enabled: false)
                    self.patchMessage = "Đã tắt"
                case .unavailable(let message):
                    self.patchMessage = "❌ \(message)"
                }
                self.patchOperationBusy = false
            }
        }
    }

    private func openGame(scheme: String) {
        guard let url = URL(string: "\(scheme)://") else { return }
        UIApplication.shared.open(url, options: [:]) { _ in }
    }
}

// --- BACKGROUND NEON 7 MÀU ---
struct NeonBackdrop: View {
    var phase: Double
    var body: some View {
        GeometryReader { proxy in
            ZStack {
                Color.black
                
                // Vòng sáng neon 1
                Circle()
                    .fill(
                        LinearGradient(colors: [Color(hue: phase, saturation: 1, brightness: 0.8), Color(hue: (phase+0.5).truncatingRemainder(dividingBy: 1.0), saturation: 1, brightness: 0.8)], startPoint: .topLeading, endPoint: .bottomTrailing)
                    )
                    .frame(width: 300, height: 300)
                    .blur(radius: 80)
                    .offset(x: 120, y: -proxy.size.height * 0.2)
                    .opacity(0.3)
                
                // Vòng sáng neon 2
                Circle()
                    .fill(
                        LinearGradient(colors: [Color(hue: (phase+0.3).truncatingRemainder(dividingBy: 1.0), saturation: 1, brightness: 0.8), Color(hue: (phase+0.8).truncatingRemainder(dividingBy: 1.0), saturation: 1, brightness: 0.8)], startPoint: .bottomTrailing, endPoint: .topLeading)
                    )
                    .frame(width: 280, height: 280)
                    .blur(radius: 90)
                    .offset(x: -120, y: proxy.size.height * 0.2)
                    .opacity(0.3)
                
                // Lưới Grid
                Canvas { context, size in
                    var path = Path()
                    let spacing: CGFloat = 44
                    stride(from: CGFloat(0), through: size.width, by: spacing).forEach { x in
                        path.move(to: CGPoint(x: x, y: 0)); path.addLine(to: CGPoint(x: x, y: size.height))
                    }
                    stride(from: CGFloat(0), through: size.height, by: spacing).forEach { y in
                        path.move(to: CGPoint(x: 0, y: y)); path.addLine(to: CGPoint(x: size.width, y: y))
                    }
                    context.stroke(path, with: .color(Color.white.opacity(0.05)), lineWidth: 1)
                }
            }
        }
    }
}
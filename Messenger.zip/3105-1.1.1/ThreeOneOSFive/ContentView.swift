
import SwiftUI
import UIKit
import AVFoundation

struct ContentView: View {
    @Environment(\.scenePhase) private var scenePhase
    @EnvironmentObject private var appState: AppState
    @State private var showSettings = false
    @State private var showCleaner = false
    @StateObject private var patchStore = PatchProjectStore()
    @State private var patchOperationBusy = false
    @State private var patchMessage = "SẴN SÀNG — CHỌN PATCH"

    // Trạng thái cho các Aim cũ
    @State private var aimHeadEnabled = false
    @State private var aimDragEnabled = false
    @State private var aimNeckEnabled = false
    @State private var aimBodyPackageEnabled = false
    @State private var aimBotEnabled = false

    // Hai Aim mới
    @State private var aimMagicEnabled = false
    @State private var aimHeadVipEnabled = false

    // Trạng thái cho Định Vị
    @State private var dinhViNhanVatEnabled = false
    @State private var dinhViSungEnabled = false

    // Hiệu ứng Neon
    @State private var neonPhase = 0.0

    var body: some View {
        ZStack {
            NeonBackdrop(phase: neonPhase)
                .ignoresSafeArea()

            ScrollView(showsIndicators: false) {
                VStack(spacing: 18) {
                    brandHeader
                    devicePanel
                    patchOptions
                    locationOptions
                    gameLaunchPanel
                    footerStatus
                    developerCredits
                }
                .padding(.horizontal, 18)
                .padding(.top, 18)
                .padding(.bottom, 28)
            }
        }
        .preferredColorScheme(.dark)
        .sheet(isPresented: $showSettings) {
            SettingsView()
        }
        .sheet(isPresented: $showCleaner) {
            CleanerView()
        }
        .onAppear {
            syncPatchStates()

            withAnimation(
                .linear(duration: 4)
                    .repeatForever(autoreverses: false)
            ) {
                neonPhase = 1.0
            }
        }
        .onChange(of: scenePhase) { phase in
            guard phase == .active,
                  !patchOperationBusy else { return }

            syncPatchStates()
            patchMessage = "SẴN SÀNG — CHỌN PATCH"
        }
    }

    // MARK: - Neon Color

    private func neonColor(offset: Double = 0) -> Color {
        let hue = (neonPhase + offset)
            .truncatingRemainder(dividingBy: 1.0)

        return Color(
            hue: hue,
            saturation: 1.0,
            brightness: 1.0
        )
    }

    // MARK: - Device Information

    private func getDeviceModelName() -> String {
        var systemInfo = utsname()
        uname(&systemInfo)

        let machineMirror = Mirror(
            reflecting: systemInfo.machine
        )

        let identifier = machineMirror.children.reduce("") {
            identifier, element in

            guard let value = element.value as? Int8,
                  value != 0 else {
                return identifier
            }

            return identifier + String(
                UnicodeScalar(UInt8(value))
            )
        }

        let mapping = [
            "iPhone12,5": "iPhone 11 Pro Max",
            "iPhone12,3": "iPhone 11 Pro",
            "iPhone12,1": "iPhone 11",
            "iPhone13,4": "iPhone 12 Pro Max"
        ]

        return mapping[identifier] ?? identifier
    }

    private func getDeviceRAM() -> String {
        let physicalMemory = ProcessInfo.processInfo.physicalMemory

        return String(
            format: "%.0f GB",
            Double(physicalMemory) / 1024.0 / 1024.0 / 1024.0
        )
    }

    private func getFreeStorage() -> String {
        if let attributes = try? FileManager.default
            .attributesOfFileSystem(forPath: NSHomeDirectory()),
           let space = attributes[.systemFreeSize] as? Int64 {

            return String(
                format: "%.1f GB Free",
                Double(space) / 1024.0 / 1024.0 / 1024.0
            )
        }

        return "Unknown"
    }

    // MARK: - Brand Header

    private var brandHeader: some View {
        HStack(spacing: 14) {
            VStack(alignment: .leading, spacing: 3) {
                Text("NOVAMAX")
                    .font(
                        .system(
                            size: 28,
                            weight: .black,
                            design: .rounded
                        )
                    )
                    .tracking(4)
                    .foregroundStyle(
                        LinearGradient(
                            colors: [
                                neonColor(offset: 0.0),
                                neonColor(offset: 0.5)
                            ],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .shadow(
                        color: neonColor(offset: 0.2),
                        radius: 8,
                        x: 0,
                        y: 0
                    )

                Text("TRUNG TÂM ĐIỀU KHIỂN")
                    .font(
                        .system(
                            size: 10,
                            weight: .bold,
                            design: .rounded
                        )
                    )
                    .tracking(1.7)
                    .foregroundStyle(neonColor(offset: 0.5))
                    .shadow(
                        color: neonColor(offset: 0.5),
                        radius: 4
                    )
            }

            Spacer()

            Button {
                showSettings = true
            } label: {
                Image(systemName: "gearshape.fill")
                    .font(.system(size: 20, weight: .bold))
                    .foregroundStyle(neonColor(offset: 0.8))
                    .frame(width: 48, height: 48)
                    .background(
                        Color.black.opacity(0.6),
                        in: Circle()
                    )
                    .overlay(
                        Circle().stroke(
                            neonColor(offset: 0.8),
                            lineWidth: 1.5
                        )
                    )
                    .shadow(
                        color: neonColor(offset: 0.8).opacity(0.5),
                        radius: 6
                    )
            }
            .buttonStyle(.plain)
        }
    }

    // MARK: - Device Panel

    private var devicePanel: some View {
        VStack(spacing: 0) {
            panelTitle(
                "TRẠNG THÁI THIẾT BỊ",
                icon: "shield.lefthalf.filled"
            )

            statusRow(
                icon: "apple.logo",
                title: "iOS",
                value: UIDevice.current.systemVersion,
                color: neonColor(offset: 0.1)
            )

            statusRow(
                icon: "iphone",
                title: "Thiết bị",
                value: getDeviceModelName(),
                color: neonColor(offset: 0.3)
            )

            statusRow(
                icon: "memorychip",
                title: "RAM",
                value: getDeviceRAM(),
                color: neonColor(offset: 0.6)
            )

            statusRow(
                icon: "internaldrive",
                title: "Bộ nhớ",
                value: getFreeStorage(),
                color: neonColor(offset: 0.9)
            )

            HStack(spacing: 12) {
                Image(systemName: "checkmark.seal.fill")
                    .font(.system(size: 22))
                    .foregroundStyle(
                        appState.isSupported ? .green : .red
                    )
                    .frame(width: 34)

                Text("Hỗ trợ")
                    .foregroundStyle(.white.opacity(0.68))

                Spacer()

                Text(
                    appState.isSupported
                    ? "ĐÃ HỖ TRỢ"
                    : "CHƯA HỖ TRỢ"
                )
                .font(
                    .system(
                        size: 14,
                        weight: .black,
                        design: .rounded
                    )
                )
                .foregroundStyle(
                    appState.isSupported ? .green : .red
                )
            }
            .padding(.top, 14)
        }
        .padding(16)
        .background(
            Color.black.opacity(0.4),
            in: RoundedRectangle(
                cornerRadius: 24,
                style: .continuous
            )
        )
        .overlay(
            RoundedRectangle(
                cornerRadius: 24,
                style: .continuous
            )
            .stroke(
                LinearGradient(
                    colors: [
                        neonColor(offset: 0.0),
                        neonColor(offset: 0.5)
                    ],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                ),
                lineWidth: 1.5
            )
        )
    }

    // MARK: - Aim Options

    private var patchOptions: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                panelTitle("TÙY CHỌN AIM", icon: "scope")

                Spacer()

                Text("GẠT ĐỂ BẬT")
                    .font(
                        .system(
                            size: 9,
                            weight: .bold,
                            design: .rounded
                        )
                    )
                    .foregroundStyle(.white.opacity(0.45))
            }

            LazyVGrid(
                columns: [
                    GridItem(.flexible(), spacing: 12),
                    GridItem(.flexible(), spacing: 12)
                ],
                spacing: 12
            ) {
                // Năm Aim cũ - giữ nguyên
                patchCardToggle(
                    name: "Aim Head",
                    package: "AimHead",
                    state: $aimHeadEnabled,
                    hueOffset: 0.0
                )

                patchCardToggle(
                    name: "Aim Bot",
                    package: "Aimbot",
                    state: $aimBotEnabled,
                    hueOffset: 0.2
                )

                patchCardToggle(
                    name: "Aim Drag",
                    package: "AimDrag",
                    state: $aimDragEnabled,
                    hueOffset: 0.4
                )

                patchCardToggle(
                    name: "Aim Neck",
                    package: "AimNeck",
                    state: $aimNeckEnabled,
                    hueOffset: 0.6
                )

                patchCardToggle(
                    name: "Aim Body",
                    package: "AimBody",
                    state: $aimBodyPackageEnabled,
                    hueOffset: 0.8
                )

                // Aim mới thứ nhất
                patchCardToggle(
                    name: "Aim Magic",
                    package: "AimMagic",
                    state: $aimMagicEnabled,
                    hueOffset: 0.1
                )

                // Aim mới thứ hai
                patchCardToggle(
                    name: "Aim Head VIP",
                    package: "AimHeadVip",
                    state: $aimHeadVipEnabled,
                    hueOffset: 0.3
                )
            }

            HStack(spacing: 8) {
                Circle()
                    .fill(
                        patchMessage.localizedCaseInsensitiveContains(
                            "THÀNH CÔNG"
                        )
                        ? .green
                        : neonColor()
                    )
                    .frame(width: 7, height: 7)

                Text(
                    patchOperationBusy
                    ? "ĐANG XỬ LÝ…"
                    : patchMessage
                )
                .font(
                    .system(
                        size: 10,
                        weight: .bold,
                        design: .rounded
                    )
                )
                .foregroundStyle(.white.opacity(0.8))
                .lineLimit(2)

                Spacer()
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 10)
            .background(
                Color.black.opacity(0.5),
                in: Capsule()
            )
        }
    }

    // MARK: - Location Options

    private var locationOptions: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                panelTitle(
                    "TÙY CHỌN ĐỊNH VỊ",
                    icon: "location.fill"
                )

                Spacer()

                Text("GẠT ĐỂ BẬT")
                    .font(
                        .system(
                            size: 9,
                            weight: .bold,
                            design: .rounded
                        )
                    )
                    .foregroundStyle(.white.opacity(0.45))
            }

            LazyVGrid(
                columns: [
                    GridItem(.flexible(), spacing: 12),
                    GridItem(.flexible(), spacing: 12)
                ],
                spacing: 12
            ) {
                patchCardToggle(
                    name: "Định Vị Nhân Vật",
                    package: "DinhViNhanVat",
                    state: $dinhViNhanVatEnabled,
                    hueOffset: 0.3
                )

                patchCardToggle(
                    name: "Định Vị Súng",
                    package: "DinhViSung",
                    state: $dinhViSungEnabled,
                    hueOffset: 0.7
                )
            }
        }
    }

    // MARK: - Patch Card

    private func patchCardToggle(
        name: String,
        package: String,
        state: Binding<Bool>,
        hueOffset: Double
    ) -> some View {
        let currentColor = neonColor(offset: hueOffset)

        return VStack(alignment: .leading, spacing: 11) {
            HStack {
                Image(systemName: "bolt.fill")
                    .font(.system(size: 16, weight: .black))
                    .foregroundStyle(currentColor)

                Spacer()

                Toggle(
                    "",
                    isOn: Binding(
                        get: {
                            state.wrappedValue
                        },
                        set: { _ in
                            togglePatch(
                                packageKeyword: package,
                                state: state
                            )
                        }
                    )
                )
                .labelsHidden()
                .tint(currentColor)
            }

            Text(name)
                .font(
                    .system(
                        size: 15,
                        weight: .black,
                        design: .rounded
                    )
                )
                .foregroundStyle(.white)
                .lineLimit(1)
                .minimumScaleFactor(0.8)

            Text("FREE FIRE • MAX")
                .font(
                    .system(
                        size: 10,
                        weight: .black,
                        design: .rounded
                    )
                )
                .tracking(1.3)
                .foregroundStyle(currentColor)

            HStack(spacing: 7) {
                Circle()
                    .fill(
                        state.wrappedValue
                        ? currentColor
                        : Color.white.opacity(0.25)
                    )
                    .frame(width: 8, height: 8)

                Text(
                    state.wrappedValue
                    ? "ĐANG BẬT"
                    : "BẬT PATCH"
                )
                .font(
                    .system(
                        size: 9,
                        weight: .black,
                        design: .rounded
                    )
                )
                .tracking(0.8)
                .foregroundStyle(.white.opacity(0.65))
            }
        }
        .frame(
            maxWidth: .infinity,
            minHeight: 130,
            alignment: .leading
        )
        .padding(14)
        .background(
            Color.black.opacity(0.6),
            in: RoundedRectangle(
                cornerRadius: 20,
                style: .continuous
            )
        )
        .overlay(
            RoundedRectangle(
                cornerRadius: 20,
                style: .continuous
            )
            .stroke(
                state.wrappedValue
                ? currentColor
                : currentColor.opacity(0.3),
                lineWidth: state.wrappedValue ? 2 : 1
            )
        )
    }

    // MARK: - Game Launch

    private var gameLaunchPanel: some View {
        VStack(alignment: .leading, spacing: 12) {
            panelTitle(
                "MỞ GAME",
                icon: "arrow.up.forward.app.fill"
            )

            HStack(spacing: 12) {
                launchButton(
                    title: "FF MAX",
                    subtitle: "Free Fire Max",
                    scheme: "freefiremax",
                    hueOffset: 0.1
                )
            }

            Button {
                showCleaner = true
            } label: {
                Label(
                    "Dọn dẹp bộ nhớ",
                    systemImage: "trash.slash.fill"
                )
                .font(
                    .system(
                        size: 13,
                        weight: .black,
                        design: .rounded
                    )
                )
                .foregroundStyle(.white)
                .frame(
                    maxWidth: .infinity,
                    minHeight: 52
                )
                .background(
                    Color.black.opacity(0.4),
                    in: RoundedRectangle(
                        cornerRadius: 16,
                        style: .continuous
                    )
                )
                .overlay(
                    RoundedRectangle(
                        cornerRadius: 16,
                        style: .continuous
                    )
                    .stroke(
                        neonColor(offset: 0.6).opacity(0.5),
                        lineWidth: 1
                    )
                )
            }
            .buttonStyle(.plain)
        }
    }

    private func launchButton(
        title: String,
        subtitle: String,
        scheme: String,
        hueOffset: Double
    ) -> some View {
        let color = neonColor(offset: hueOffset)

        return Button {
            openGame(scheme: scheme)
        } label: {
            VStack(alignment: .leading, spacing: 7) {
                Image(
                    systemName: "arrow.up.right.square.fill"
                )
                .font(.system(size: 18, weight: .bold))
                .foregroundStyle(color)

                Text(title)
                    .font(
                        .system(
                            size: 13,
                            weight: .black,
                            design: .rounded
                        )
                    )
                    .foregroundStyle(.white)

                Text(subtitle)
                    .font(
                        .system(
                            size: 10,
                            weight: .medium,
                            design: .rounded
                        )
                    )
                    .foregroundStyle(.white.opacity(0.5))
            }
            .frame(
                maxWidth: .infinity,
                minHeight: 82,
                alignment: .leading
            )
            .padding(.horizontal, 14)
            .background(
                Color.black.opacity(0.4),
                in: RoundedRectangle(
                    cornerRadius: 18,
                    style: .continuous
                )
            )
            .overlay(
                RoundedRectangle(
                    cornerRadius: 18,
                    style: .continuous
                )
                .stroke(
                    color.opacity(0.6),
                    lineWidth: 1
                )
            )
        }
        .buttonStyle(.plain)
    }

    // MARK: - Footer

    private var footerStatus: some View {
        HStack(spacing: 10) {
            Circle()
                .fill(neonColor(offset: 0.5))
                .frame(width: 9, height: 9)

            Text("HỆ THỐNG SẴN SÀNG")
                .font(
                    .system(
                        size: 10,
                        weight: .black,
                        design: .rounded
                    )
                )
                .tracking(1.2)
                .foregroundStyle(.white.opacity(0.72))

            Spacer()

            Text("NOVAMAX • READY")
                .font(
                    .system(
                        size: 9,
                        weight: .bold,
                        design: .rounded
                    )
                )
                .foregroundStyle(neonColor(offset: 0.5))
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 13)
        .background(
            Color.black.opacity(0.6),
            in: Capsule()
        )
    }

    // MARK: - Developer Credits

    private var developerCredits: some View {
        Text("TrungDungdangcap")
            .font(
                .system(
                    size: 11,
                    weight: .bold,
                    design: .rounded
                )
            )
            .foregroundStyle(
                neonColor(offset: 0.9).opacity(0.8)
            )
            .frame(maxWidth: .infinity)
            .padding(.top, 4)
            .padding(.bottom, 8)
    }

    // MARK: - Common Components

    private func panelTitle(
        _ title: String,
        icon: String
    ) -> some View {
        Label(title, systemImage: icon)
            .font(
                .system(
                    size: 12,
                    weight: .black,
                    design: .rounded
                )
            )
            .tracking(1.4)
            .foregroundStyle(neonColor())
    }

    private func statusRow(
        icon: String,
        title: String,
        value: String,
        color: Color
    ) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 17, weight: .bold))
                .foregroundStyle(color)
                .frame(width: 24)

            Text(title)
                .font(
                    .system(
                        size: 14,
                        weight: .semibold,
                        design: .rounded
                    )
                )
                .foregroundStyle(.white.opacity(0.58))

            Spacer()

            Text(value)
                .font(
                    .system(
                        size: 14,
                        weight: .black,
                        design: .rounded
                    )
                )
                .foregroundStyle(.white)
        }
        .padding(.top, 14)
    }

    // MARK: - File Name Matching

    private func cleanName(_ str: String) -> String {
        let result = str.lowercased()
            .replacingOccurrences(
                of: " ",
                with: ""
            )
            .replacingOccurrences(
                of: ".3105",
                with: ""
            )

        let customMapping = [
            "đ": "d",
            "Đ": "D",
            "ị": "i",
            "v": "v",
            "n": "n",
            "h": "h",
            "â": "a",
            "t": "t"
        ]

        var cleaned = result

        for (key, value) in customMapping {
            cleaned = cleaned.replacingOccurrences(
                of: key,
                with: value
            )
        }

        return cleaned
            .folding(
                options: .diacriticInsensitive,
                locale: .current
            )
            .replacingOccurrences(of: " ", with: "")
    }

    // MARK: - Find Patch

    private func findItem(
        for keyword: String
    ) -> (id: UUID, project: PatchProject?)? {

        let target = cleanName(keyword)

        // Ưu tiên tên chính xác để tránh AimHeadVip
        // bị nhận nhầm thành AimHead.
        for item in patchStore.items {
            let itemName = cleanName(
                item.packageURL.lastPathComponent
            )

            if itemName == target {
                return (item.id, item.project)
            }
        }

        // Giữ cơ chế tìm kiếm gần đúng cho các patch cũ.
        let sortedItems = patchStore.items.sorted {
            cleanName($0.packageURL.lastPathComponent).count >
            cleanName($1.packageURL.lastPathComponent).count
        }

        for item in sortedItems {
            let itemName = cleanName(
                item.packageURL.lastPathComponent
            )

            if itemName.contains(target) ||
                target.contains(itemName) {
                return (item.id, item.project)
            }
        }

        return nil
    }

    // MARK: - Sync Patch States

    private func syncPatchStates() {
        aimHeadEnabled = isPatchActive("AimHead")
        aimBotEnabled = isPatchActive("Aimbot")
        aimDragEnabled = isPatchActive("AimDrag")
        aimNeckEnabled = isPatchActive("AimNeck")
        aimBodyPackageEnabled = isPatchActive("AimBody")

        // Hai Aim mới
        aimMagicEnabled = isPatchActive("AimMagic")
        aimHeadVipEnabled = isPatchActive("AimHeadVip")

        // Hai mục định vị cũ
        dinhViNhanVatEnabled = isPatchActive("DinhViNhanVat")
        dinhViSungEnabled = isPatchActive("DinhViSung")
    }

    private func isPatchActive(
        _ keyword: String
    ) -> Bool {
        if let item = findItem(for: keyword) {
            return DevicePatchService.latestReceipt(
                projectID: item.id
            ) != nil
        }

        return false
    }

    // MARK: - Patch Action Result

    private enum PatchActionResult {
        case applied
        case restored
        case unavailable(String)
    }

    // MARK: - Set Patch State

    private func setPatchState(
        for keyword: String,
        enabled: Bool
    ) {
        let key = cleanName(keyword)

        // Đặt AimHeadVip trước AimHead
        if key.contains("aimheadvip") {
            aimHeadVipEnabled = enabled
        }
        else if key.contains("aimmagic") {
            aimMagicEnabled = enabled
        }
        else if key.contains("aimhead") {
            aimHeadEnabled = enabled
        }
        else if key.contains("aimbot") {
            aimBotEnabled = enabled
        }
        else if key.contains("aimdrag") {
            aimDragEnabled = enabled
        }
        else if key.contains("aimneck") {
            aimNeckEnabled = enabled
        }
        else if key.contains("aimbody") {
            aimBodyPackageEnabled = enabled
        }
        else if key.contains("dinhvinhanvat") {
            dinhViNhanVatEnabled = enabled
        }
        else if key.contains("dinhvisung") {
            dinhViSungEnabled = enabled
        }
    }

    // MARK: - Toggle Patch

    private func togglePatch(
        packageKeyword: String,
        state: Binding<Bool>
    ) {
        guard !patchOperationBusy else {
            return
        }

        guard let item = findItem(for: packageKeyword) else {
            patchMessage = "❌ KHÔNG TÌM THẤY FILE"
            return
        }

        let wasEnabled = state.wrappedValue

        patchOperationBusy = true
        patchMessage = "ĐANG XỬ LÝ…"

        let project = item.project
        let projectID = item.id

        DispatchQueue.global(
            qos: .userInitiated
        ).async {

            let result: PatchActionResult

            do {
                if wasEnabled {

                    guard let receipt =
                        DevicePatchService.latestReceipt(
                            projectID: projectID
                        ) else {

                        DispatchQueue.main.async {
                            self.setPatchState(
                                for: packageKeyword,
                                enabled: false
                            )

                            self.patchMessage =
                                "❌ KHÔNG CÓ GÓI ĐỂ KHÔI PHỤC"

                            self.patchOperationBusy = false
                        }

                        return
                    }

                    try DevicePatchService.restore(
                        receipt: receipt
                    )

                    result = .restored

                } else {

                    guard let project else {

                        DispatchQueue.main.async {
                            self.patchMessage =
                                "❌ FILE BỊ KHOÁ MẬT KHẨU"

                            self.patchOperationBusy = false
                        }

                        return
                    }

                    _ = try DevicePatchService.apply(
                        project: project
                    )

                    result = .applied
                }

            } catch {
                result = .unavailable("THẤT BẠI")
            }

            DispatchQueue.main.async {
                switch result {

                case .applied:
                    self.setPatchState(
                        for: packageKeyword,
                        enabled: true
                    )

                    self.patchMessage =
                        "Bật \(packageKeyword.replacingOccurrences(
                            of: ".3105",
                            with: ""
                        )) thành công"

                case .restored:
                    self.setPatchState(
                        for: packageKeyword,
                        enabled: false
                    )

                    self.patchMessage = "Đã tắt"

                case .unavailable(let message):
                    self.patchMessage = "❌ \(message)"
                }

                self.patchOperationBusy = false
            }
        }
    }

    // MARK: - Open Game

    private func openGame(scheme: String) {
        guard let url = URL(
            string: "\(scheme)://"
        ) else {
            return
        }

        UIApplication.shared.open(
            url,
            options: [:]
        ) { _ in }
    }
}

// MARK: - Background Neon

struct NeonBackdrop: View {
    var phase: Double

    var body: some View {
        GeometryReader { proxy in
            ZStack {
                Color.black

                Circle()
                    .fill(
                        LinearGradient(
                            colors: [
                                Color(
                                    hue: phase,
                                    saturation: 1,
                                    brightness: 0.8
                                ),
                                Color(
                                    hue: (phase + 0.5)
                                        .truncatingRemainder(
                                            dividingBy: 1.0
                                        ),
                                    saturation: 1,
                                    brightness: 0.8
                                )
                            ],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .frame(width: 300, height: 300)
                    .blur(radius: 80)
                    .offset(
                        x: 120,
                        y: -proxy.size.height * 0.2
                    )
                    .opacity(0.3)

                Circle()
                    .fill(
                        LinearGradient(
                            colors: [
                                Color(
                                    hue: (phase + 0.3)
                                        .truncatingRemainder(
                                            dividingBy: 1.0
                                        ),
                                    saturation: 1,
                                    brightness: 0.8
                                ),
                                Color(
                                    hue: (phase + 0.8)
                                        .truncatingRemainder(
                                            dividingBy: 1.0
                                        ),
                                    saturation: 1,
                                    brightness: 0.8
                                )
                            ],
                            startPoint: .bottomTrailing,
                            endPoint: .topLeading
                        )
                    )
                    .frame(width: 280, height: 280)
                    .blur(radius: 90)
                    .offset(
                        x: -120,
                        y: proxy.size.height * 0.2
                    )
                    .opacity(0.3)

                Canvas { context, size in
                    var path = Path()
                    let spacing: CGFloat = 44

                    stride(
                        from: CGFloat(0),
                        through: size.width,
                        by: spacing
                    ).forEach { x in
                        path.move(
                            to: CGPoint(x: x, y: 0)
                        )

                        path.addLine(
                            to: CGPoint(
                                x: x,
                                y: size.height
                            )
                        )
                    }

                    stride(
                        from: CGFloat(0),
                        through: size.height,
                        by: spacing
                    ).forEach { y in
                        path.move(
                            to: CGPoint(x: 0, y: y)
                        )

                        path.addLine(
                            to: CGPoint(
                                x: size.width,
                                y: y
                            )
                        )
                    }

                    context.stroke(
                        path,
                        with: .color(
                            Color.white.opacity(0.05)
                        ),
                        lineWidth: 1
                    )
                }
            }
        }
    }
}

import SwiftUI

struct ContentView: View {
    @State private var selectedTab: Int = 0

    var body: some View {
        TabView(selection: $selectedTab) {
            PatchProjectsView()
                .tabItem {
                    Label("Bản vá", systemImage: "puzzlepiece.extension")
                }
                .tag(0)

            // Truyền đủ các tham số bắt buộc cho FileBrowserView
            FileBrowserView(
                containerPath: NSHomeDirectory(),
                title: "File Browser"
            )
            .tabItem {
                Label("Tệp tin", systemImage: "folder")
            }
            .tag(1)
            
            CleanerView()
                .tabItem {
                    Label("Dọn dẹp", systemImage: "trash")
                }
                .tag(2)
        }
        .accentColor(.orange)
    }
}

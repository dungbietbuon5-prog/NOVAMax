import SwiftUI

struct ContentView: View {
    @State private var selectedTab: Int = 0

    var body: some View {
        TabView(selection: $selectedTab) {
            PatchProjectsView()
                .tabItem {
                    Label("Bản vá", systemImage: "puzzlepiece.extension")
                }
                .tag(0)

            FileBrowserView()
                .tabItem {
                    Label("Tệp tin", systemImage: "folder")
                }
                .tag(1)
            
            CleanerView()
                .tabItem {
                    Label("Dọn dẹp", systemImage: "trash")
                }
                .tag(3)
        }
        .accentColor(.orange)
    }
}

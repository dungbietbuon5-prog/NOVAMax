import SwiftUI

struct ContentView: View {
    @State private var selectedTab: Int = 0

    var body: some View {
        TabView(selection: $selectedTab) {
            PatchProjectsView()
                .tabItem {
                    Label("Bản vá", systemImage: "puzzlepiece.extension")
                }
                .tag(0)

            // Gọi mặc định không truyền tham số để tránh lệch nhãn
            FileBrowserView()
                .tabItem {
                    Label("Tệp tin", systemImage: "folder")
                }
                .tag(1)
            
            CleanerView()
                .tabItem {
                    Label("Dọn dẹp", systemImage: "trash")
                }
                .tag(2)
        }
        .accentColor(.orange)
    }
}

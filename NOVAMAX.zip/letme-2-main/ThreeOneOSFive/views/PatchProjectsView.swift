import SwiftUI
import UIKit

struct PatchProjectsView: View {
    @Environment(\.appLanguage) private var language
    @StateObject private var store = PatchProjectStore()
    
    @State private var workingProjectIDs: Set<UUID> = []
    @State private var actionAlert: PatchStoreAlert?
    @State private var customAlertMessage: String?
    @State private var hasAutoImported = false

    // 4 Aim cố định tương ứng với các tệp .3105 có sẵn trong thư mục Patches của dự án
    private let targetAimConfigs = [
        ("AimDrag", "Hỗ trợ kéo tâm chuẩn xác"),
        ("AimBot", "Tăng độ bám mục tiêu"),
        ("AimBody", "Khóa tâm vùng thân"),
        ("AimNeck", "Ưu tiên vùng cổ/đầu")
    ]

    var body: some View {
        ZStack {
            // Tông màu nền đen tuyền chủ đạo cá tính
            Color(red: 0.04, green: 0.04, blue: 0.04)
                .ignoresSafeArea()

            ScrollView {
                VStack(spacing: 16) {
                    
                    // 1. HEADER THƯƠNG HIỆU TRUNGDUNGMAX (ĐỎ - ĐEN)
                    HStack(spacing: 12) {
                        ZStack {
                            RoundedRectangle(cornerRadius: 12)
                                .fill(Color.red.opacity(0.18))
                                .frame(width: 40, height: 40)
                            Image(systemName: "flame.fill")
                                .foregroundColor(.red)
                                .font(.system(size: 20, weight: .bold))
                        }
                        
                        VStack(alignment: .leading, spacing: 3) {
                            Text("TRUNGDUNGMAX")
                                .font(.system(size: 17, weight: .black))
                                .tracking(1.2)
                                .foregroundColor(.white)
                            Text("3105 ENGINE • FREE FIRE MAX")
                                .font(.system(size: 10, weight: .bold))
                                .tracking(0.8)
                                .foregroundColor(.red)
                        }
                        
                        Spacer()
                        
                        if store.isBusy {
                            ProgressView()
                                .tint(.red)
                        } else {
                            Text("PRO")
                                .font(.system(size: 10, weight: .black))
                                .padding(.horizontal, 8)
                                .padding(.vertical, 4)
                                .background(Color.red.opacity(0.2))
                                .foregroundColor(.red)
                                .cornerRadius(6)
                        }
                    }
                    .padding(16)
                    .background(Color(red: 0.08, green: 0.08, blue: 0.08))
                    .cornerRadius(18)
                    .overlay(
                        RoundedRectangle(cornerRadius: 18)
                            .stroke(Color.red.opacity(0.4), lineWidth: 1)
                    )
                    .padding(.horizontal)
                    .padding(.top, 12)

                    // 2. DANH SÁCH 4 NÚT GẠT AIM (GẮN TRỰC TIẾP VÀO LOGIC GỐC)
                    VStack(spacing: 12) {
                        ForEach(targetAimConfigs, id: \.0) { config in
                            let patchName = config.0
                            let subtitle = config.1
                            let matchedItem = findItem(named: patchName)
                            let isApplied = matchedItem.map { DevicePatchService.latestReceipt(projectID: $0.id) != nil } ?? false
                            let isWorking = matchedItem.map { workingProjectIDs.contains($0.id) } ?? false

                            RedBlackAimToggleCard(
                                title: patchName,
                                subtitle: subtitle,
                                isAvailable: matchedItem != nil,
                                isApplied: isApplied,
                                isWorking: isWorking,
                                onToggle: { enable in
                                    guard let item = matchedItem else {
                                        customAlertMessage = "Không tìm thấy gói cấu hình \(patchName).3105!"
                                        return
                                    }
                                    if enable {
                                        applyOriginalPatch(item: item)
                                    } else {
                                        restoreOriginalPatch(item: item)
                                    }
                                }
                            )
                        }
                    }
                    .padding(.horizontal)

                    // 3. NÚT KHỞI CHẠY FREE FIRE MAX (ĐÃ LOẠI BỎ FF THƯỜNG, TẬP TRUNG MAX)
                    Button(action: launchFreeFireMax) {
                        HStack(spacing: 14) {
                            ZStack {
                                RoundedRectangle(cornerRadius: 12)
                                    .fill(Color.red)
                                    .frame(width: 44, height: 44)
                                Image(systemName: "gamecontroller.fill")
                                    .foregroundColor(.white)
                                    .font(.system(size: 19, weight: .bold))
                            }
                            
                            VStack(alignment: .leading, spacing: 3) {
                                Text("MỞ FREE FIRE MAX")
                                    .font(.system(size: 15, weight: .bold))
                                    .foregroundColor(.white)
                                Text("Khởi chạy nhanh com.dts.freefiremax")
                                    .font(.system(size: 11))
                                    .foregroundColor(.secondary)
                            }
                            
                            Spacer()
                            
                            Image(systemName: "arrow.up.right")
                                .font(.system(size: 16, weight: .bold))
                                .foregroundColor(.red)
                        }
                        .padding(14)
                        .background(Color(red: 0.09, green: 0.06, blue: 0.06))
                        .cornerRadius(18)
                        .overlay(
                            RoundedRectangle(cornerRadius: 18)
                                .stroke(Color.red.opacity(0.6), lineWidth: 1)
                        )
                    }
                    .padding(.horizontal)

                    Spacer(minLength: 24)
                }
            }
        }
        .alert(item: $store.alert) { alert in
            Alert(
                title: Text(language.text(alert.titleKey)),
                message: Text(alert.message(language: language)),
                dismissButton: .default(Text(language.text("common.ok")))
            )
        }
        .alert(item: $actionAlert) { alert in
            Alert(
                title: Text(language.text(alert.titleKey)),
                message: Text(alert.message(language: language)),
                dismissButton: .default(Text(language.text("common.ok")))
            )
        }
        .alert("TrungDungMax", isPresented: Binding(
            get: { customAlertMessage != nil },
            set: { if !$0 { customAlertMessage = nil } }
        )) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(customAlertMessage ?? "")
        }
        .onAppear {
            autoImportBundledPatches()
        }
    }

    // Tự động nạp các tệp .3105 có sẵn trong thư mục Patches của Bundle vào Store gốc
    private func autoImportBundledPatches() {
        guard !hasAutoImported else { return }
        hasAutoImported = true

        let existingNames = Set(store.items.compactMap { item -> String? in
            if let name = item.project?.name { return name.lowercased() }
            return item.packageURL.deletingPathExtension().lastPathComponent.lowercased()
        })

        for config in targetAimConfigs {
            let patchName = config.0
            if existingNames.contains(patchName.lowercased()) {
                continue
            }

            // Quét tìm file trong thư mục Patches đính kèm dự án
            let bundleURL = Bundle.main.url(forResource: patchName, withExtension: "3105", subdirectory: "Patches")
                ?? Bundle.main.url(forResource: patchName, withExtension: "3105")
                ?? Bundle.main.url(forResource: "OGIOS File (\(targetAimConfigs.firstIndex(where: { $0.0 == patchName })! + 1))", withExtension: "3105", subdirectory: "Patches")

            if let url = bundleURL {
                store.importPackage(at: url)
            }
        }
    }

    private func findItem(named name: String) -> PatchLibraryItem? {
        store.items.first { item in
            let projectName = item.project?.name ?? ""
            let fileName = item.packageURL.deletingPathExtension().lastPathComponent
            return projectName.caseInsensitiveCompare(name) == .orderedSame
                || fileName.caseInsensitiveCompare(name) == .orderedSame
                || fileName.contains(name)
        }
    }

    // LOGIC LÕI GỐC: Gọi DevicePatchService.apply để thực thi patch
    private func applyOriginalPatch(item: PatchLibraryItem) {
        guard let baseProject = item.project else {
            if item.isLocked {
                store.requestUnlock(for: item)
            }
            return
        }

        workingProjectIDs.insert(item.id)
        Task.detached(priority: .userInitiated) {
            do {
                let project = item.summary.schemaVersion >= 2
                    ? try PatchProjectLibrary.synchronizeWorkspace(item: item)
                    : baseProject
                _ = try DevicePatchService.apply(project: project)
                await MainActor.run {
                    store.reload()
                    workingProjectIDs.remove(item.id)
                    actionAlert = PatchStoreAlert(titleKey: "common.done", messageKey: "patch.applied_message")
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    workingProjectIDs.remove(item.id)
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    workingProjectIDs.remove(item.id)
                    actionAlert = PatchStoreAlert(titleKey: "common.failed", messageKey: "patch.error.apply")
                }
            }
        }
    }

    // LOGIC LÕI GỐC: Gọi DevicePatchService.restore để khôi phục tệp gốc
    private func restoreOriginalPatch(item: PatchLibraryItem) {
        guard let receipt = DevicePatchService.latestReceipt(projectID: item.id) else {
            store.reload()
            return
        }

        workingProjectIDs.insert(item.id)
        Task.detached(priority: .userInitiated) {
            do {
                try DevicePatchService.restore(receipt: receipt)
                await MainActor.run {
                    store.reload()
                    workingProjectIDs.remove(item.id)
                    actionAlert = PatchStoreAlert(titleKey: "common.done", messageKey: "patch.restored_message")
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    workingProjectIDs.remove(item.id)
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    workingProjectIDs.remove(item.id)
                    actionAlert = PatchStoreAlert(titleKey: "common.failed", messageKey: "patch.error.restore")
                }
            }
        }
    }

    // Hàm mở Free Fire Max chuyên biệt (đã loại bỏ FF thường)
    private func launchFreeFireMax() {
        let maxSchemes = ["com.dts.freefiremax://", "ffmax://"]
        for scheme in maxSchemes {
            if let url = URL(string: scheme) {
                UIApplication.shared.open(url, options: [:]) { success in
                    if !success && scheme == maxSchemes.last {
                        customAlertMessage = "Không thể tự mở game. Vui lòng mở thủ công Free Fire Max ngoài màn hình chính!"
                    }
                }
                return
            }
        }
    }
}

// Giao diện thẻ Aim tông Đỏ - Đen cá tính
private struct RedBlackAimToggleCard: View {
    let title: String
    let subtitle: String
    let isAvailable: Bool
    let isApplied: Bool
    let isWorking: Bool
    let onToggle: (Bool) -> Void

    var body: some View {
        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 12)
                    .fill(isApplied ? Color.red.opacity(0.25) : Color(red: 0.14, green: 0.06, blue: 0.06))
                    .frame(width: 44, height: 44)
                Image(systemName: isApplied ? "checkmark.shield.fill" : "scope")
                    .foregroundColor(isApplied ? .red : .red.opacity(0.8))
                    .font(.system(size: 19, weight: .semibold))
            }

            VStack(alignment: .leading, spacing: 4) {
                HStack(spacing: 6) {
                    Text(title)
                        .font(.system(size: 16, weight: .bold))
                        .foregroundColor(.white)
                    
                    Text(isApplied ? "ĐÃ BẬT" : (isAvailable ? "SẴN SÀNG" : "CHỜ FILE"))
                        .font(.system(size: 9, weight: .black))
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(isApplied ? Color.red : Color.white.opacity(0.08))
                        .foregroundColor(isApplied ? .white : .secondary)
                        .cornerRadius(4)
                }
                
                Text(subtitle)
                    .font(.system(size: 11))
                    .foregroundColor(.secondary)
            }

            Spacer()

            if isWorking {
                ProgressView()
                    .tint(.red)
                    .padding(.trailing, 6)
            } else {
                Toggle("", isOn: Binding(
                    get: { isApplied },
                    set: { newValue in onToggle(newValue) }
                ))
                .labelsHidden()
                .tint(.red)
                .disabled(!isAvailable)
            }
        }
        .padding(14)
        .background(Color(red: 0.08, green: 0.08, blue: 0.08))
        .cornerRadius(18)
        .overlay(
            RoundedRectangle(cornerRadius: 18)
                .stroke(isApplied ? Color.red : Color.white.opacity(0.08), lineWidth: isApplied ? 1.5 : 1)
        )
    }
}

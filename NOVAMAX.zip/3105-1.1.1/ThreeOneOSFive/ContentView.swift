import SwiftUI
import UIKit
import AVFoundation

struct ContentView: View {
    @Environment(\.scenePhase) private var scenePhase
    @EnvironmentObject private var appState: AppState
    @State private var showSettings = false
    @State private var showCleaner = false
    @State private var patchOperationBusy = false
    @State private var patchMessage = "SẴN SÀNG — CHỌN PATCH"
    
    @State private var aimDragEnabled = false
    @State private var aimNeckEnabled = false
    @State private var aimBodyPackageEnabled = false
    @State private var aimBotEnabled = false

    var body: some View {
        ZStack {
            AnimatedHyperBackdrop().ignoresSafeArea()

            ScrollView(showsIndicators: false) {
                VStack(spacing: 18) {
                    brandHeader
                    devicePanel
                    patchOptions
                    gameLaunchPanel
                    footerStatus
                    developerCredits
                }
                .padding(.horizontal, 18)
                .padding(.top, 18)
                .padding(.bottom, 28)
            }
        }
        .preferredColorScheme(.dark)
        .sheet(isPresented: $showSettings) { SettingsView() }
        .sheet(isPresented: $showCleaner) { CleanerView() }
        .onAppear { 
            copyBundledPatches()
            syncPatchStates() 
        }
        .onChange(of: scenePhase) { phase in
            guard phase == .active, !patchOperationBusy else { return }
            syncPatchStates()
            patchMessage = "SẴN SÀNG — CHỌN PATCH"
        }
    }
    
    // --- LẤY THÔNG TIN MÁY CHI TIẾT ---
    private func getDeviceModelName() -> String {
        var systemInfo = utsname()
        uname(&systemInfo)
        let machineMirror = Mirror(reflecting: systemInfo.machine)
        let identifier = machineMirror.children.reduce("") { identifier, element in
            guard let value = element.value as? Int8, value != 0 else { return identifier }
            return identifier + String(UnicodeScalar(UInt8(value)))
        }
        let mapping = [
            "iPhone12,5": "iPhone 11 Pro Max", "iPhone12,3": "iPhone 11 Pro", "iPhone12,1": "iPhone 11",
            "iPhone13,4": "iPhone 12 Pro Max", "iPhone14,2": "iPhone 13 Pro", "iPhone14,3": "iPhone 13 Pro Max"
        ]
        return mapping[identifier] ?? identifier
    }

    private func getDeviceRAM() -> String {
        let physicalMemory = ProcessInfo.processInfo.physicalMemory
        return String(format: "%.0f GB", Double(physicalMemory) / 1024.0 / 1024.0 / 1024.0)
    }

    private func getFreeStorage() -> String {
        if let attributes = try? FileManager.default.attributesOfFileSystem(forPath: NSHomeDirectory()),
           let space = attributes[.systemFreeSize] as? Int64 {
            return String(format: "%.1f GB Free", Double(space) / 1024.0 / 1024.0 / 1024.0)
        }
        return "Unknown"
    }

    // --- COPY FILE TỪ BUNDLE ---
    private func copyBundledPatches() {
        let fileManager = FileManager.default
        let docs = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let patches = ["Aimbot", "AimDrag", "AimNeck", "AimBody"]
        
        for patch in patches {
            if let bundleURL = Bundle.main.url(forResource: patch, withExtension: "3105") {
                let destURL = docs.appendingPathComponent("\(patch).3105")
                if !fileManager.fileExists(atPath: destURL.path) {
                    try? fileManager.copyItem(at: bundleURL, to: destURL)
                }
            }
        }
    }

    private var brandHeader: some View {
        HStack(spacing: 14) {
            VStack(alignment: .leading, spacing: 3) {
                Text("NOVAMAX")
                    .font(.system(size: 25, weight: .black, design: .rounded))
                    .tracking(3)
                    .foregroundStyle(.white)
                Text("TRUNG TÂM ĐIỀU KHIỂN")
                    .font(.system(size: 10, weight: .bold, design: .rounded))
                    .tracking(1.7)
                    .foregroundStyle(AppTheme.accent)
            }
            Spacer()
            Button { showSettings = true } label: {
                Image(systemName: "gearshape.fill")
                    .font(.system(size: 20, weight: .bold))
                    .foregroundStyle(AppTheme.accent)
                    .frame(width: 48, height: 48)
                    .background(Color.black.opacity(0.38), in: Circle())
                    .overlay(Circle().stroke(AppTheme.accent.opacity(0.42), lineWidth: 1))
            }
            .buttonStyle(.plain)
        }
    }

    private var devicePanel: some View {
        VStack(spacing: 0) {
            panelTitle("TRẠNG THÁI THIẾT BỊ", icon: "shield.lefthalf.filled")
            statusRow(icon: "apple.logo", title: "iOS", value: UIDevice.current.systemVersion, color: AppTheme.accent)
            statusRow(icon: "iphone", title: "Thiết bị", value: getDeviceModelName(), color: AppTheme.accent)
            statusRow(icon: "memorychip", title: "RAM", value: getDeviceRAM(), color: AppTheme.accent)
            statusRow(icon: "internaldrive", title: "Bộ nhớ", value: getFreeStorage(), color: AppTheme.accent)
            
            HStack(spacing: 12) {
                Image(systemName: "checkmark.seal.fill")
                    .font(.system(size: 22))
                    .foregroundStyle(appState.isSupported ? .green : .red)
                    .frame(width: 34)
                Text("Hỗ trợ").foregroundStyle(.white.opacity(0.68))
                Spacer()
                Text(appState.isSupported ? "ĐÃ HỖ TRỢ" : "CHƯA HỖ TRỢ")
                    .font(.system(size: 14, weight: .black, design: .rounded))
                    .foregroundStyle(appState.isSupported ? .green : .red)
            }
            .padding(.top, 14)
        }
        .padding(16)
        .background(Color.black.opacity(0.42), in: RoundedRectangle(cornerRadius: 24, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).stroke(AppTheme.accent.opacity(0.38), lineWidth: 1))
    }

    private var patchOptions: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                panelTitle("TÙY CHỌN PATCH", icon: "bolt.fill")
                Spacer()
                Text("GẠT ĐỂ BẬT")
                    .font(.system(size: 9, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.45))
            }

            LazyVGrid(columns: [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)], spacing: 12) {
                patchCardToggle(name: "Aim Bot", target: "FREE FIRE • MAX", package: "Aimbot.3105", color: AppTheme.accent, state: $aimBotEnabled)
                patchCardToggle(name: "Aim Drag", target: "FREE FIRE • MAX", package: "AimDrag.3105", color: AppTheme.accent, state: $aimDragEnabled)
                patchCardToggle(name: "Aim Neck", target: "FREE FIRE • MAX", package: "AimNeck.3105", color: Color.gray, state: $aimNeckEnabled)
                patchCardToggle(name: "Aim Body", target: "FREE FIRE • MAX", package: "AimBody.3105", color: AppTheme.accent, state: $aimBodyPackageEnabled)
            }

            HStack(spacing: 8) {
                Circle().fill(patchMessage.localizedCaseInsensitiveContains("THÀNH CÔNG") ? .green : AppTheme.accent).frame(width: 7, height: 7)
                Text(patchOperationBusy ? "ĐANG XỬ LÝ…" : patchMessage)
                    .font(.system(size: 10, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.72))
                    .lineLimit(2)
                Spacer()
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 10)
            .background(Color.black.opacity(0.34), in: Capsule())
        }
    }

    private func patchCardToggle(name: String, target: String, package: String, color: Color, state: Binding<Bool>) -> some View {
        VStack(alignment: .leading, spacing: 11) {
            HStack {
                Image(systemName: "bolt.fill").font(.system(size: 16, weight: .black)).foregroundStyle(color)
                Spacer()
                Toggle("", isOn: Binding(
                    get: { state.wrappedValue },
                    set: { newValue in togglePatch(packageFilename: package, state: state) }
                ))
                .labelsHidden()
                .tint(.green)
            }
            Text(name).font(.system(size: 17, weight: .black, design: .rounded)).foregroundStyle(.white)
            Text(target).font(.system(size: 10, weight: .black, design: .rounded)).tracking(1.3).foregroundStyle(color)
            
            HStack(spacing: 7) {
                Circle().fill(state.wrappedValue ? Color.green : Color.white.opacity(0.25)).frame(width: 8, height: 8)
                Text(state.wrappedValue ? "ĐANG BẬT" : "BẬT PATCH")
                    .font(.system(size: 9, weight: .black, design: .rounded))
                    .tracking(0.8)
                    .foregroundStyle(.white.opacity(0.65))
            }
        }
        .frame(maxWidth: .infinity, minHeight: 142, alignment: .leading)
        .padding(14)
        .background(Color.black.opacity(0.52), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(state.wrappedValue ? color.opacity(0.85) : color.opacity(0.28), lineWidth: state.wrappedValue ? 1.5 : 1))
    }

    private var gameLaunchPanel: some View {
        VStack(alignment: .leading, spacing: 12) {
            panelTitle("MỞ GAME", icon: "arrow.up.forward.app.fill")
            HStack(spacing: 12) {
                launchButton(title: "FF MAX", subtitle: "Free Fire Max", color: AppTheme.accent, scheme: "freefiremax")
            }
            Button { showCleaner = true } label: {
                Label("Dọn dẹp bộ nhớ", systemImage: "trash.slash.fill")
                    .font(.system(size: 13, weight: .black, design: .rounded)).foregroundStyle(.white)
                    .frame(maxWidth: .infinity, minHeight: 52)
                    .background(Color.black.opacity(0.40), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(AppTheme.accent.opacity(0.52), lineWidth: 1))
            }
            .buttonStyle(.plain)
        }
    }

    private func launchButton(title: String, subtitle: String, color: Color, scheme: String) -> some View {
        Button { openGame(scheme: scheme) } label: {
            VStack(alignment: .leading, spacing: 7) {
                Image(systemName: "arrow.up.right.square.fill").font(.system(size: 18, weight: .bold)).foregroundStyle(color)
                Text(title).font(.system(size: 13, weight: .black, design: .rounded)).foregroundStyle(.white)
                Text(subtitle).font(.system(size: 10, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.5))
            }
            .frame(maxWidth: .infinity, minHeight: 82, alignment: .leading)
            .padding(.horizontal, 14)
            .background(Color.black.opacity(0.40), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(color.opacity(0.38), lineWidth: 1))
        }
        .buttonStyle(.plain)
    }

    private var footerStatus: some View {
        HStack(spacing: 10) {
            Circle().fill(.green).frame(width: 9, height: 9).shadow(color: .green, radius: 6)
            Text("HỆ THỐNG SẴN SÀNG").font(.system(size: 10, weight: .black, design: .rounded)).tracking(1.2).foregroundStyle(.white.opacity(0.72))
            Spacer()
            Text("NOVAMAX • READY").font(.system(size: 9, weight: .bold, design: .rounded)).foregroundStyle(AppTheme.accent.opacity(0.8))
        }
        .padding(.horizontal, 14).padding(.vertical, 13)
        .background(Color.black.opacity(0.45), in: Capsule())
        .overlay(Capsule().stroke(AppTheme.accent.opacity(0.2), lineWidth: 1))
    }

    private var developerCredits: some View {
        Text("Phát triển bởi NOVAMAX")
            .font(.system(size: 11, weight: .bold, design: .rounded))
            .foregroundStyle(.white.opacity(0.72))
            .frame(maxWidth: .infinity).padding(.top, 4).padding(.bottom, 8)
    }

    private func panelTitle(_ title: String, icon: String) -> some View {
        Label(title, systemImage: icon).font(.system(size: 12, weight: .black, design: .rounded)).tracking(1.4).foregroundStyle(AppTheme.accent)
    }

    private func statusRow(icon: String, title: String, value: String, color: Color) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon).font(.system(size: 17, weight: .bold)).foregroundStyle(color).frame(width: 24)
            Text(title).font(.system(size: 14, weight: .semibold, design: .rounded)).foregroundStyle(.white.opacity(0.58))
            Spacer()
            Text(value).font(.system(size: 14, weight: .black, design: .rounded)).foregroundStyle(.white)
        }
        .padding(.top, 14)
    }

    // --- TỰ ĐỘNG PATCH VÀO GAME FF MAX ---
    private func getFFMaxPath() -> String? {
        let fileManager = FileManager.default
        let appsPath = "/var/mobile/Containers/Data/Application/"
        if let apps = try? fileManager.contentsOfDirectory(atPath: appsPath) {
            for appUUID in apps {
                let appPath = appsPath + appUUID
                let metadataPath = appPath + "/.com.apple.mobile_container_manager.metadata.plist"
                if let dict = NSDictionary(contentsOfFile: metadataPath),
                   let bundleID = dict["MCMMetadataIdentifier"] as? String,
                   bundleID == "com.dts.freefiremax" {
                    return appPath + "/Documents/"
                }
            }
        }
        return nil
    }

    private func applyPatchToGame(patchFileName: String) -> Bool {
        guard let gamePath = getFFMaxPath() else { return false }
        let fileManager = FileManager.default
        let targetFile = gamePath + "assetindexer.YJ~2FW7EkU5pRkVg51NrKyx4LXid8~3D"
        let backupFile = targetFile + ".bak"
        
        if !fileManager.fileExists(atPath: backupFile) && fileManager.fileExists(atPath: targetFile) {
            try? fileManager.copyItem(atPath: targetFile, toPath: backupFile)
        }
        
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let patchPath = docs.appendingPathComponent(patchFileName).path
        
        guard fileManager.fileExists(atPath: patchPath) else { return false }
        
        do {
            if fileManager.fileExists(atPath: targetFile) { try fileManager.removeItem(atPath: targetFile) }
            try fileManager.copyItem(atPath: patchPath, toPath: targetFile)
            return true
        } catch { return false }
    }

    private func removePatchFromGame() -> Bool {
        guard let gamePath = getFFMaxPath() else { return false }
        let fileManager = FileManager.default
        let targetFile = gamePath + "assetindexer.YJ~2FW7EkU5pRkVg51NrKyx4LXid8~3D"
        let backupFile = targetFile + ".bak"
        
        if fileManager.fileExists(atPath: backupFile) {
            do {
                if fileManager.fileExists(atPath: targetFile) { try fileManager.removeItem(atPath: targetFile) }
                try fileManager.moveItem(atPath: backupFile, toPath: targetFile)
                return true
            } catch { return false }
        }
        return false
    }

    private func togglePatch(packageFilename: String, state: Binding<Bool>) {
        guard !patchOperationBusy else { return }
        let wasEnabled = state.wrappedValue
        patchOperationBusy = true
        patchMessage = "ĐANG XỬ LÝ — \(packageFilename)"

        DispatchQueue.global(qos: .userInitiated).async {
            var success = false
            if wasEnabled {
                success = self.removePatchFromGame()
            } else {
                success = self.applyPatchToGame(patchFileName: packageFilename)
            }
            
            DispatchQueue.main.async {
                if success {
                    self.setPatchState(for: packageFilename, enabled: !wasEnabled)
                    self.patchMessage = !wasEnabled ? "PATCH THÀNH CÔNG — \(packageFilename)" : "ĐÃ KHÔI PHỤC — \(packageFilename)"
                    if !wasEnabled { PatchAudioFeedback.bypassActivated() } else { PatchAudioFeedback.originalRestored() }
                } else {
                    self.patchMessage = "❌ THẤT BẠI — KIỂM TRA QUYỀN TROLLSTORE"
                }
                self.patchOperationBusy = false
            }
        }
    }

    private func setPatchState(for packageFilename: String, enabled: Bool) {
        switch packageFilename.lowercased() {
        case "aimbot.3105": aimBotEnabled = enabled
        case "aimdrag.3105": aimDragEnabled = enabled
        case "aimneck.3105": aimNeckEnabled = enabled
        case "aimbody.3105": aimBodyPackageEnabled = enabled
        default: break
        }
    }

    private func syncPatchStates() {}

    private func openGame(scheme: String) {
        guard let url = URL(string: "\(scheme)://") else { return }
        UIApplication.shared.open(url, options: [:]) { _ in }
    }
}

// --- BACKGROUND & ÂM THANH ---
struct AnimatedHyperBackdrop: View {
    @State private var animate = false
    var body: some View {
        GeometryReader { proxy in
            ZStack {
                AppTheme.pageBackground
                Circle().fill(AppTheme.accent.opacity(0.12)).frame(width: 280, height: 280).blur(radius: 70).offset(x: animate ? 120 : -120, y: -proxy.size.height * 0.23)
                Circle().fill(Color.gray.opacity(0.08)).frame(width: 260, height: 260).blur(radius: 80).offset(x: animate ? -100 : 100, y: proxy.size.height * 0.22)
                GridOverlay()
            }
            .onAppear { withAnimation(.easeInOut(duration: 7).repeatForever(autoreverses: true)) { animate = true } }
        }
    }
}

private struct GridOverlay: View {
    var body: some View {
        Canvas { context, size in
            var path = Path()
            let spacing: CGFloat = 44
            stride(from: CGFloat(0), through: size.width, by: spacing).forEach { x in
                path.move(to: CGPoint(x: x, y: 0)); path.addLine(to: CGPoint(x: x, y: size.height))
            }
            stride(from: CGFloat(0), through: size.height, by: spacing).forEach { y in
                path.move(to: CGPoint(x: 0, y: y)); path.addLine(to: CGPoint(x: size.width, y: y))
            }
            context.stroke(path, with: .color(AppTheme.accent.opacity(0.055)), lineWidth: 1)
        }
    }
}

private enum PatchAudioFeedback {
    private static let synthesizer = AVSpeechSynthesizer()
    static func bypassActivated() { speak("Bypass ativado") }
    static func originalRestored() { speak("Bypass desativado") }
    private static func speak(_ message: String) {
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.playback, mode: .spokenAudio, options: [.duckOthers])
        try? session.setActive(true, options: [])
        synthesizer.stopSpeaking(at: .immediate)
        let utterance = AVSpeechUtterance(string: message)
        let voices = AVSpeechSynthesisVoice.speechVoices()
        utterance.voice = voices.first(where: {
            ($0.language.hasPrefix("pt-BR") || $0.language.hasPrefix("pt")) && $0.gender == .female && $0.quality == .enhanced
        }) ?? AVSpeechSynthesisVoice(language: "pt-BR")
        utterance.rate = 0.43
        utterance.pitchMultiplier = 1.10
        utterance.volume = 0.90
        synthesizer.speak(utterance)
    }
}
import SwiftUI
import UIKit

// --- QUẢN LÝ PATCH TỰ ĐỘNG ---
class NovaMaxManager: ObservableObject {
    // Đường dẫn thư mục data của FF Max (Mày phải điền chính xác bundle ID hoặc đường dẫn thực tế trên máy)
    let ffMaxDataPath = "/var/mobile/Containers/Data/Application/" 
    let targetFile = "assetindexer.YJ~2FW7EkU5pRkVg51NrKyx4LXid8~3D"
    
    @Published var activeAim: String? = nil
    
    // Hàm bật Aim
    func applyPatch(aimType: String) {
        let fileManager = FileManager.default
        let gameFilePath = ffMaxDataPath + "/" + targetFile
        let backupFilePath = ffMaxDataPath + "/" + targetFile + ".bak"
        
        // 1. Backup file gốc nếu chưa có
        if !fileManager.fileExists(atPath: backupFilePath) && fileManager.fileExists(atPath: gameFilePath) {
            try? fileManager.copyItem(atPath: gameFilePath, toPath: backupFilePath)
        }
        
        // 2. Tìm file patch trong Bundle (Ví dụ: AimHead.patch)
        // Lưu ý: Mày phải add các file .patch này vào phần Copy Bundle Resources trong Xcode
        guard let patchFilePath = Bundle.main.path(forResource: aimType, ofType: "patch") else {
            print("Không tìm thấy file patch \(aimType).patch")
            return
        }
        
        // 3. Ghi đè
        do {
            if fileManager.fileExists(atPath: gameFilePath) {
                try fileManager.removeItem(atPath: gameFilePath)
            }
            try fileManager.copyItem(atPath: patchFilePath, toPath: gameFilePath)
            activeAim = aimType
            print("Đã bật \(aimType)")
        } catch {
            print("Lỗi patch: \(error)")
        }
    }
    
    // Hàm tắt Aim (Restore)
    func removePatch() {
        let fileManager = FileManager.default
        let gameFilePath = ffMaxDataPath + "/" + targetFile
        let backupFilePath = ffMaxDataPath + "/" + targetFile + ".bak"
        
        if fileManager.fileExists(atPath: backupFilePath) {
            do {
                if fileManager.fileExists(atPath: gameFilePath) {
                    try fileManager.removeItem(atPath: gameFilePath)
                }
                try fileManager.moveItem(atPath: backupFilePath, toPath: gameFilePath)
                activeAim = nil
                print("Đã khôi phục file gốc")
            } catch {
                print("Lỗi restore: \(error)")
            }
        }
    }
    
    // Hàm mở game FF Max
    func openFFMax() {
        // Mày cần tìm đúng URL Scheme của FF Max, thường là freefiremax://
        let url = URL(string: "freefiremax://")!
        if UIApplication.shared.canOpenURL(url) {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        } else {
            // Thử scheme khác nếu sai
            let url2 = URL(string: "com.dts.freefiremax://")!
            UIApplication.shared.open(url2, options: [:], completionHandler: nil)
        }
    }
}

// --- APP CHÍNH ---
struct ContentView: View {
    @StateObject private var novaManager = NovaMaxManager()
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    @State private var selectedTab = 0

    var body: some View {
        Group {
            if horizontalSizeClass == .regular {
                regularLayout
            } else {
                compactLayout
            }
        }
        .tint(AppTheme.accent)
        .imageScale(.small)
    }

    private var compactLayout: some View {
        TabView(selection: $selectedTab) {
            DashboardView(manager: novaManager)
                .tabItem {
                    Label("Home", systemImage: "house.fill")
                }
                .tag(0)
                
            CleanerView()
                .tabItem {
                    Label("Cleaner", systemImage: "sparkles")
                }
                .tag(1)
                
            WallpaperLabView()
                .tabItem {
                    Label("Wallpapers", systemImage: "photo.on.rectangle.angled")
                }
                .tag(2)
        }
    }

    private var regularLayout: some View {
        NavigationSplitView {
            List {
                Button { selectedTab = 0 } label: {
                    Label("Home", systemImage: "house.fill")
                }
                .buttonStyle(.plain)
                Button { selectedTab = 1 } label: {
                    Label("Cleaner", systemImage: "sparkles")
                }
                .buttonStyle(.plain)
                Button { selectedTab = 2 } label: {
                    Label("Wallpapers", systemImage: "photo.on.rectangle.angled")
                }
                .buttonStyle(.plain)
            }
            .navigationTitle("NOVAMAX")
            .navigationSplitViewColumnWidth(min: 210, ideal: 240, max: 300)
        } detail: {
            if selectedTab == 0 { DashboardView(manager: novaManager) }
            else if selectedTab == 1 { CleanerView() }
            else { WallpaperLabView() }
        }
        .navigationSplitViewStyle(.balanced)
    }
}

// --- MÀN HÌNH CHÍNH (DASHBOARD) ---
struct DashboardView: View {
    @ObservedObject var manager: NovaMaxManager
    @State private var showSettings = false
    @State private var showLogs = false
    @State private var showCleaner = false
    
    private let patchNames = ["Aim Head", "Aim Neck", "Aim Body", "Aim Drag"] // Tên này phải khớp với file .patch trong Bundle
    private let patchTitles = ["Aim Head", "Aim Neck", "Aim Body", "Aim Drag"]
    private let columns = [GridItem(.flexible(), spacing: 14), GridItem(.flexible(), spacing: 14)]

    var body: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 24) {
                    header
                    deviceStatus
                    patchOptions
                    launchGame
                    cleanButton
                    systemStatus
                    footer
                }
                .padding(.horizontal, 18)
                .padding(.top, 12)
                .padding(.bottom, 28)
            }
            .background(NovaMaxBackground())
            .toolbar(.hidden, for: .navigationBar)
            .preferredColorScheme(.dark)
            .sheet(isPresented: $showSettings) { SettingsView() }
            .sheet(isPresented: $showLogs) { LogView() }
            .sheet(isPresented: $showCleaner) { CleanerView() }
        }
    }

    private var header: some View {
        HStack(alignment: .center) {
            VStack(alignment: .leading, spacing: 5) {
                Text("NOVAMAX")
                    .font(.system(size: 34, weight: .black, design: .rounded))
                    .tracking(4)
                    .foregroundStyle(.white)
                Text("PATCH CONTROL CENTER")
                    .font(.system(size: 12, weight: .heavy, design: .rounded))
                    .tracking(3)
                    .foregroundStyle(NovaMaxPalette.red)
            }
            Spacer()
            Button { showSettings = true } label: {
                Image(systemName: "gearshape.fill")
                    .font(.system(size: 22, weight: .semibold))
                    .foregroundStyle(NovaMaxPalette.red)
                    .frame(width: 58, height: 58)
                    .background(Color.black.opacity(0.65), in: Circle())
                    .overlay(Circle().stroke(NovaMaxPalette.red.opacity(0.45), lineWidth: 1))
            }
            .accessibilityLabel("Settings")
        }
        .padding(.top, 8)
    }

    private var deviceStatus: some View {
        VStack(spacing: 18) {
            sectionTitle("◈  DEVICE STATUS")
            statusRow(icon: "apple.logo", label: "iOS", value: UIDevice.current.systemVersion)
            statusRow(icon: "iphone", label: "Device", value: UIDevice.current.model)
            HStack(spacing: 12) {
                Image(systemName: "checkmark.seal.fill")
                    .font(.system(size: 22))
                    .foregroundStyle(NovaMaxPalette.green)
                    .frame(width: 34)
                Text("Support")
                    .foregroundStyle(.white.opacity(0.68))
                Spacer()
                Text("SUPPORTED")
                    .font(.system(size: 14, weight: .black, design: .rounded))
                    .foregroundStyle(NovaMaxPalette.green)
            }
        }
        .padding(20)
        .background(Color.black.opacity(0.72), in: RoundedRectangle(cornerRadius: 28))
        .overlay(RoundedRectangle(cornerRadius: 28).stroke(NovaMaxPalette.red.opacity(0.55), lineWidth: 1))
    }

    private var patchOptions: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(alignment: .firstTextBaseline) {
                sectionTitle("ϟ  PATCH OPTIONS")
                Spacer()
                Text("NOVAMAX PACKAGE")
                    .font(.system(size: 9, weight: .bold, design: .rounded))
                    .tracking(1)
                    .foregroundStyle(.white.opacity(0.42))
            }
            LazyVGrid(columns: columns, spacing: 14) {
                ForEach(Array(zip(patchNames, patchTitles)), id: \.0) { name, title in
                    // NÚT BẤM TỰ ĐỘNG PATCH
                    Button {
                        if manager.activeAim == name {
                            manager.removePatch() // Tắt patch nếu đang bật
                        } else {
                            manager.applyPatch(aimType: name) // Bật patch mới
                        }
                    } label: {
                        VStack(alignment: .leading, spacing: 13) {
                            HStack {
                                Image(systemName: "bolt.fill")
                                    .font(.system(size: 24, weight: .bold))
                                    .foregroundStyle(manager.activeAim == name ? NovaMaxPalette.green : NovaMaxPalette.red)
                                Spacer()
                                Text(manager.activeAim == name ? "ACTIVE" : "FILE")
                                    .font(.system(size: 10, weight: .black, design: .rounded))
                                    .foregroundStyle(.white.opacity(0.55))
                            }
                            Text(title)
                                .font(.system(size: 21, weight: .heavy, design: .rounded))
                                .foregroundStyle(.white)
                                .lineLimit(1)
                                .minimumScaleFactor(0.8)
                            Text("NOVAMAX PACKAGE")
                                .font(.system(size: 10, weight: .black, design: .rounded))
                                .tracking(1.6)
                                .foregroundStyle(manager.activeAim == name ? NovaMaxPalette.green : NovaMaxPalette.red)
                            HStack(spacing: 7) {
                                Circle().fill(manager.activeAim == name ? NovaMaxPalette.green : NovaMaxPalette.red).frame(width: 7, height: 7)
                                Text(manager.activeAim == name ? "TOUCH TO DISABLE" : "TOUCH TO APPLY")
                                    .font(.system(size: 9, weight: .heavy, design: .rounded))
                                    .tracking(1)
                                    .foregroundStyle(.white.opacity(0.7))
                            }
                        }
                        .frame(maxWidth: .infinity, minHeight: 148, alignment: .leading)
                        .padding(16)
                        .background(Color.black.opacity(0.76), in: RoundedRectangle(cornerRadius: 25))
                        .overlay(RoundedRectangle(cornerRadius: 25).stroke((manager.activeAim == name ? NovaMaxPalette.green : NovaMaxPalette.red).opacity(0.7), lineWidth: 1))
                    }
                    .buttonStyle(.plain)
                }
            }
            Text("Select a card to automatically apply the patch to the game data.")
                .font(.system(size: 11, weight: .medium))
                .foregroundStyle(.white.opacity(0.48))
        }
    }

    private var launchGame: some View {
        VStack(alignment: .leading, spacing: 14) {
            sectionTitle("↗  LAUNCH GAME")
            HStack(spacing: 14) {
                // NÚT MỞ GAME FF MAX
                Button {
                    manager.openFFMax()
                } label: {
                    VStack(alignment: .leading, spacing: 10) {
                        Image(systemName: "arrow.up.right.square.fill")
                            .font(.system(size: 24, weight: .bold))
                            .foregroundStyle(NovaMaxPalette.red)
                        Text("FF MAX")
                            .font(.system(size: 17, weight: .black, design: .rounded))
                            .foregroundStyle(.white)
                        Text("Free Fire Max")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundStyle(.white.opacity(0.48))
                    }
                    .frame(maxWidth: .infinity, minHeight: 112, alignment: .leading)
                    .padding(16)
                    .background(Color.black.opacity(0.72), in: RoundedRectangle(cornerRadius: 24))
                    .overlay(RoundedRectangle(cornerRadius: 24).stroke(NovaMaxPalette.red.opacity(0.65), lineWidth: 1))
                }
                .buttonStyle(.plain)
            }
        }
    }

    private var cleanButton: some View {
        Button { showCleaner = true } label: {
            HStack(spacing: 12) {
                Image(systemName: "trash.slash.fill")
                Text("Clean Cache & Temp")
                    .font(.system(size: 17, weight: .heavy, design: .rounded))
            }
            .foregroundStyle(.white)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 22)
            .background(Color.black.opacity(0.72), in: RoundedRectangle(cornerRadius: 24))
            .overlay(RoundedRectangle(cornerRadius: 24).stroke(NovaMaxPalette.red.opacity(0.65), lineWidth: 1))
        }
        .buttonStyle(.plain)
    }

    private var systemStatus: some View {
        HStack(spacing: 12) {
            Circle().fill(NovaMaxPalette.green).frame(width: 11, height: 11)
            Text("SYSTEM READY")
                .font(.system(size: 13, weight: .black, design: .rounded))
                .tracking(2)
                .foregroundStyle(.white.opacity(0.8))
            Spacer()
            Text("NOVAMAX • 3105")
                .font(.system(size: 11, weight: .bold, design: .rounded))
                .foregroundStyle(NovaMaxPalette.red)
        }
        .padding(.horizontal, 18)
        .padding(.vertical, 19)
        .background(Color.black.opacity(0.72), in: Capsule())
        .overlay(Capsule().stroke(NovaMaxPalette.red.opacity(0.4), lineWidth: 1))
    }

    private var footer: some View {
        VStack(spacing: 10) {
            Text("Developed by NOVAMAX")
                .font(.system(size: 15, weight: .bold))
                .foregroundStyle(.white.opacity(0.75))
            Button { showLogs = true } label: {
                Label("SYSTEM LOGS", systemImage: "terminal")
                    .font(.system(size: 11, weight: .heavy, design: .rounded))
                    .tracking(1.4)
                    .foregroundStyle(NovaMaxPalette.red)
            }
        }
        .frame(maxWidth: .infinity)
        .padding(.top, 4)
    }

    private func sectionTitle(_ title: String) -> some View {
        Text(title)
            .font(.system(size: 14, weight: .black, design: .rounded))
            .tracking(2)
            .foregroundStyle(NovaMaxPalette.red)
    }

    private func statusRow(icon: String, label: String, value: String) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 22, weight: .semibold))
                .foregroundStyle(.white)
                .frame(width: 34)
            Text(label).foregroundStyle(.white.opacity(0.68))
            Spacer()
            Text(value)
                .font(.system(size: 14, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
                .lineLimit(1)
                .minimumScaleFactor(0.75)
        }
    }
}

// --- GIAO DIỆN MÀU SẮC ---
private enum NovaMaxPalette {
    static let red = Color(red: 0.78, green: 0.035, blue: 0.055)
    static let green = Color(red: 0.12, green: 0.82, blue: 0.36)
}

private struct NovaMaxBackground: View {
    var body: some View {
        GeometryReader { proxy in
            ZStack {
                Color.black
                Path { path in
                    let spacing: CGFloat = 62
                    stride(from: CGFloat.zero, through: proxy.size.width, by: spacing).forEach { x in
                        path.move(to: CGPoint(x: x, y: 0))
                        path.addLine(to: CGPoint(x: x, y: proxy.size.height))
                    }
                    stride(from: CGFloat.zero, through: proxy.size.height, by: spacing).forEach { y in
                        path.move(to: CGPoint(x: 0, y: y))
                        path.addLine(to: CGPoint(x: proxy.size.width, y: y))
                    }
                }
                .stroke(NovaMaxPalette.red.opacity(0.075), lineWidth: 0.7)
            }
            .ignoresSafeArea()
        }
    }
}
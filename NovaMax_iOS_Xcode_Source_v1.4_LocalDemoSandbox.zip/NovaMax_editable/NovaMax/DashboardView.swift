import SwiftUI
import UIKit
import Darwin

private enum NovaTheme {
    static let red = Color(red: 0.78, green: 0.08, blue: 0.12)
    static let redSoft = Color(red: 0.42, green: 0.035, blue: 0.055)
    static let panel = Color(red: 0.035, green: 0.035, blue: 0.04)
    static let muted = Color.white.opacity(0.56)
}

private struct PatchItem: Identifiable {
    let id: String
    let title: String
    let subtitle: String
    let symbol: String
}

struct DashboardView: View {
    @State private var enabledDemos: Set<String> = PatchPreferences.load()
    @State private var batteryText = "Checking…"
    @State private var showInfoAlert = false
    @State private var alertTitle = "NOVA MAX"
    @State private var alertMessage = ""
    @State private var demoSandboxStatus = "TEST SANDBOX READY"

    private let patches = [
        PatchItem(id: "aim-drag", title: "Aim Drag", subtitle: "PATCH ENTRY • 3105", symbol: "bolt.fill"),
        PatchItem(id: "aim-neck", title: "Aim Neck", subtitle: "PATCH ENTRY • 3105", symbol: "bolt.fill"),
        PatchItem(id: "aim-body", title: "Aim Body", subtitle: "PATCH ENTRY • 3105", symbol: "bolt.fill"),
        PatchItem(id: "aim-bot", title: "Aim Bot", subtitle: "PATCH ENTRY • 3105", symbol: "bolt.fill")
    ]

    private let columns = [GridItem(.flexible(), spacing: 14), GridItem(.flexible(), spacing: 14)]

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            GridBackdrop()
                .ignoresSafeArea()

            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 25) {
                    header
                    deviceStatus
                    patchSection
                    demoSandboxSection
                    launchSection
                    footer
                }
                .padding(.horizontal, 20)
                .padding(.top, 18)
                .padding(.bottom, 36)
            }
        }
        .onAppear(perform: refreshDeviceInfo)
        .alert(alertTitle, isPresented: $showInfoAlert) {
            Button("OK", role: .cancel) { }
        } message: {
            Text(alertMessage)
        }
    }

    private var header: some View {
        HStack(alignment: .center) {
            VStack(alignment: .leading, spacing: 5) {
                Text("NOVA")
                    .font(.system(size: 36, weight: .black, design: .rounded))
                    .tracking(6)
                    .foregroundStyle(.white)
                Text("MAX CONTROL CENTER")
                    .font(.system(size: 12, weight: .heavy, design: .rounded))
                    .tracking(3.1)
                    .foregroundStyle(NovaTheme.red)
            }
            Spacer()
            Button {
                alertTitle = "NOVA MAX"
                alertMessage = "NOVA MAX stores a local Aim profile in its own Documents folder. Turning every option OFF removes that profile and returns NOVA MAX to its baseline state. This does not modify or inject into Free Fire MAX."
                showInfoAlert = true
            } label: {
                Image(systemName: "gearshape.fill")
                    .font(.system(size: 23, weight: .bold))
                    .foregroundStyle(NovaTheme.red)
                    .frame(width: 58, height: 58)
                    .background(Circle().fill(Color.black.opacity(0.65)))
                    .overlay(Circle().stroke(NovaTheme.red.opacity(0.55), lineWidth: 1))
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Settings")
        }
    }

    private var deviceStatus: some View {
        VStack(spacing: 17) {
            Label("DEVICE STATUS", systemImage: "shield.lefthalf.filled")
                .font(.system(size: 14, weight: .black, design: .rounded))
                .tracking(2.3)
                .foregroundStyle(NovaTheme.red)
                .frame(maxWidth: .infinity)

            VStack(spacing: 15) {
                DeviceInfoRow(symbol: "apple.logo", label: "iOS", value: UIDevice.current.systemVersion)
                DeviceInfoRow(symbol: "iphone", label: "Device", value: hardwareIdentifier)
                DeviceInfoRow(symbol: "memorychip", label: "RAM", value: memoryText)
                DeviceInfoRow(symbol: "cpu", label: "CPU cores", value: "\(ProcessInfo.processInfo.processorCount)")
                DeviceInfoRow(symbol: "battery.75percent", label: "Battery", value: batteryText)
            }
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 20)
        .background(Color.black.opacity(0.78))
        .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 28, style: .continuous).stroke(NovaTheme.red.opacity(0.45), lineWidth: 1))
    }

    private var patchSection: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(alignment: .firstTextBaseline) {
                Label("PATCH OPTIONS", systemImage: "bolt.fill")
                    .font(.system(size: 15, weight: .black, design: .rounded))
                    .tracking(2.2)
                    .foregroundStyle(NovaTheme.red)
                Spacer()
                Text("FF MAX ONLY")
                    .font(.system(size: 10, weight: .heavy, design: .rounded))
                    .tracking(1.4)
                    .foregroundStyle(NovaTheme.muted)
            }

            LazyVGrid(columns: columns, spacing: 14) {
                ForEach(patches) { patch in
                    let isOn = enabledDemos.contains(patch.id)
                    PatchDemoCard(item: patch, isOn: isOn) {
                        var updated = enabledDemos
                        if isOn { updated.remove(patch.id) }
                        else { updated.insert(patch.id) }
                        do {
                            try LocalPatchProfileStore.apply(updated)
                            enabledDemos = updated
                        } catch {
                            alertTitle = "PATCH PROFILE"
                            alertMessage = "Không thể cập nhật cấu hình cục bộ: \(error.localizedDescription)"
                            showInfoAlert = true
                        }
                    }
                }
            }

            HStack(spacing: 9) {
                Circle().fill(NovaTheme.red).frame(width: 8, height: 8)
                Text(enabledDemos.isEmpty ? "BASELINE RESTORED — NO LOCAL OPTIONS" : "\(enabledDemos.count) LOCAL OPTION(S) ACTIVE")
                    .font(.system(size: 11, weight: .heavy, design: .rounded))
                    .tracking(1.3)
                    .foregroundStyle(NovaTheme.muted)
            }
            .padding(.top, 3)
        }
    }

    private var demoSandboxSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("LOCAL TEST PATCH SANDBOX", systemImage: "shippingbox.fill")
                .font(.system(size: 15, weight: .black, design: .rounded))
                .tracking(1.6)
                .foregroundStyle(NovaTheme.red)

            Text("Thử nghiệm áp dụng/khôi phục các tệp mẫu do NOVA MAX tự tạo trong Documents của chính ứng dụng. Không truy cập hoặc thay đổi Free Fire MAX.")
                .font(.system(size: 11, weight: .medium))
                .foregroundStyle(NovaTheme.muted)
                .fixedSize(horizontal: false, vertical: true)

            HStack(spacing: 10) {
                Button(action: applyDemoSandboxFiles) {
                    Label("APPLY DEMO", systemImage: "arrow.down.doc.fill")
                        .font(.system(size: 11, weight: .black, design: .rounded))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .background(NovaTheme.red)
                        .foregroundStyle(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 13))
                }
                Button(action: restoreDemoSandboxFiles) {
                    Label("RESTORE", systemImage: "arrow.uturn.backward")
                        .font(.system(size: 11, weight: .black, design: .rounded))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .background(Color.white.opacity(0.09))
                        .foregroundStyle(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 13))
                        .overlay(RoundedRectangle(cornerRadius: 13).stroke(Color.white.opacity(0.2), lineWidth: 1))
                }
            }

            Text(demoSandboxStatus)
                .font(.system(size: 10, weight: .heavy, design: .rounded))
                .tracking(1.1)
                .foregroundStyle(NovaTheme.muted)
        }
        .padding(18)
        .background(Color.black.opacity(0.78))
        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(NovaTheme.red.opacity(0.4), lineWidth: 1))
    }

    private func applyDemoSandboxFiles() {
        do {
            try LocalDemoPatchSandbox.apply()
            demoSandboxStatus = "DEMO PATCHES APPLIED — APP SANDBOX ONLY"
        } catch {
            demoSandboxStatus = "APPLY FAILED: \(error.localizedDescription)"
        }
    }

    private func restoreDemoSandboxFiles() {
        do {
            try LocalDemoPatchSandbox.restore()
            demoSandboxStatus = "ORIGINAL DEMO FILES RESTORED"
        } catch {
            demoSandboxStatus = "RESTORE FAILED: \(error.localizedDescription)"
        }
    }

    private var launchSection: some View {
        VStack(alignment: .leading, spacing: 13) {
            Label("LAUNCH GAME", systemImage: "arrow.up.right.square.fill")
                .font(.system(size: 15, weight: .black, design: .rounded))
                .tracking(2.2)
                .foregroundStyle(NovaTheme.red)

            Button(action: openFreeFireMax) {
                HStack(spacing: 13) {
                    Image(systemName: "gamecontroller.fill")
                        .font(.system(size: 22, weight: .bold))
                    VStack(alignment: .leading, spacing: 3) {
                        Text("FREE FIRE MAX")
                            .font(.system(size: 16, weight: .black, design: .rounded))
                            .tracking(1)
                        Text("OPEN INSTALLED GAME")
                            .font(.system(size: 9, weight: .bold, design: .rounded))
                            .tracking(1.2)
                            .foregroundStyle(NovaTheme.muted)
                    }
                    Spacer()
                    Image(systemName: "chevron.right")
                        .font(.system(size: 14, weight: .bold))
                }
                .foregroundStyle(.white)
                .padding(18)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.black.opacity(0.82))
                .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(NovaTheme.red.opacity(0.65), lineWidth: 1))
            }
            .buttonStyle(.plain)

            Text("Attempts to launch the installed game with freefiremax://. This only works if your Free Fire MAX build registers that URL scheme; no App Store redirect is used.")
                .font(.system(size: 10, weight: .medium))
                .foregroundStyle(NovaTheme.muted)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    private var footer: some View {
        VStack(spacing: 16) {
            HStack(spacing: 9) {
                Circle().fill(Color.green).frame(width: 9, height: 9)
                Text("SYSTEM READY")
                    .font(.system(size: 11, weight: .black, design: .rounded))
                    .tracking(2)
                Spacer()
                Text("NOVA • LOCAL UI")
                    .font(.system(size: 10, weight: .heavy, design: .rounded))
                    .tracking(1)
                    .foregroundStyle(NovaTheme.red)
            }
            .padding(.horizontal, 17)
            .padding(.vertical, 16)
            .background(Color.black.opacity(0.78))
            .clipShape(Capsule())
            .overlay(Capsule().stroke(NovaTheme.red.opacity(0.35), lineWidth: 1))

            Text("Independent community interface")
                .font(.system(size: 12, weight: .semibold))
                .foregroundStyle(NovaTheme.muted)
            Text("Local profile only: settings are written inside NOVA MAX. Free Fire MAX files and memory are never modified.")
                .font(.system(size: 9, weight: .medium))
                .foregroundStyle(NovaTheme.muted.opacity(0.8))
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.top, 4)
    }

    private var hardwareIdentifier: String {
        var size: size_t = 0
        sysctlbyname("hw.machine", nil, &size, nil, 0)
        var machine = [CChar](repeating: 0, count: max(1, Int(size)))
        sysctlbyname("hw.machine", &machine, &size, nil, 0)
        return String(cString: machine)
    }

    private var memoryText: String {
        let gb = Double(ProcessInfo.processInfo.physicalMemory) / 1_073_741_824
        return String(format: "%.1f GB", gb)
    }

    private func refreshDeviceInfo() {
        UIDevice.current.isBatteryMonitoringEnabled = true
        let level = UIDevice.current.batteryLevel
        batteryText = level >= 0 ? "\(Int(level * 100))%" : "Unavailable"
    }

    private func openFreeFireMax() {
        // Candidate deep link only. The supplied 3105 source does not document
        // a Free Fire MAX URL scheme, so the game must be tested on-device.
        guard let url = URL(string: "freefiremax://") else {
            alertTitle = "FREE FIRE MAX"
            alertMessage = "The Free Fire MAX launch URL is invalid."
            showInfoAlert = true
            return
        }

        UIApplication.shared.open(url, options: [:]) { opened in
            guard !opened else { return }
            DispatchQueue.main.async {
                alertTitle = "FREE FIRE MAX"
                alertMessage = "Không mở được game bằng freefiremax://. Có thể Free Fire MAX trên máy chưa đăng ký scheme này. Hãy gửi Info.plist của bản Free Fire MAX đang cài để xác định URL scheme chính xác. NOVA MAX không chuyển sang App Store."
                showInfoAlert = true
            }
        }
    }
}

/// Stores NOVA MAX's own profile only. It never accesses Free Fire MAX files,
/// processes, memory, or executable data.
private enum LocalPatchProfileStore {
    private static let preferencesKey = "nova.max.aimOptions.v1"
    private static let directoryName = "NOVA_MAX_Profiles"
    private static let profileName = "aim_profile.json"

    static func load() -> Set<String> {
        Set(UserDefaults.standard.stringArray(forKey: preferencesKey) ?? [])
    }

    static func apply(_ enabled: Set<String>) throws {
        let defaults = UserDefaults.standard
        let previous = defaults.stringArray(forKey: preferencesKey) ?? []
        guard let documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else {
            throw NSError(domain: "NovaMax.LocalProfile", code: 1,
                          userInfo: [NSLocalizedDescriptionKey: "Documents folder is unavailable"])
        }
        let directory = documents.appendingPathComponent(directoryName, isDirectory: true)
        let profileURL = directory.appendingPathComponent(profileName)
        do {
            if enabled.isEmpty {
                if FileManager.default.fileExists(atPath: profileURL.path) {
                    try FileManager.default.removeItem(at: profileURL)
                }
                defaults.removeObject(forKey: preferencesKey)
                return
            }
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
            let payload: [String: Any] = [
                "format": "nova-max-local-profile",
                "version": 1,
                "target": "NOVA MAX local configuration only",
                "enabledOptions": enabled.sorted()
            ]
            let data = try JSONSerialization.data(withJSONObject: payload, options: [.prettyPrinted, .sortedKeys])
            try data.write(to: profileURL, options: .atomic)
            defaults.set(enabled.sorted(), forKey: preferencesKey)
        } catch {
            defaults.set(previous, forKey: preferencesKey)
            throw error
        }
    }
}

/// A reversible demonstration patch manager restricted to files created by NOVA MAX
/// in its own Documents/NOVA_MAX_TestSandbox directory.
private enum LocalDemoPatchSandbox {
    private static let folderName = "NOVA_MAX_TestSandbox"
    private static let managedNames = ["demo_settings.ini", "demo_visual_profile.json"]

    private static var folder: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent(folderName, isDirectory: true)
    }

    private static var backupFolder: URL {
        folder.appendingPathComponent("Originals", isDirectory: true)
    }

    static func apply() throws {
        let fm = FileManager.default
        try fm.createDirectory(at: folder, withIntermediateDirectories: true)
        try fm.createDirectory(at: backupFolder, withIntermediateDirectories: true)

        let samples: [String: Data] = [
            "demo_settings.ini": Data("mode=baseline\nquality=standard\n".utf8),
            "demo_visual_profile.json": Data("{\\"profile\\":\\"baseline\\",\\"demoOnly\\":true}\n".utf8)
        ]

        // Seed originals only if this sandbox has not been initialized before.
        for name in managedNames {
            let target = folder.appendingPathComponent(name)
            let backup = backupFolder.appendingPathComponent(name)
            if !fm.fileExists(atPath: target.path) && !fm.fileExists(atPath: backup.path),
               let original = samples[name] {
                try original.write(to: target, options: .atomic)
            }
            if fm.fileExists(atPath: target.path) && !fm.fileExists(atPath: backup.path) {
                try fm.copyItem(at: target, to: backup)
            }
        }

        let patched: [String: Data] = [
            "demo_settings.ini": Data("mode=demo_patch\nquality=high\nsource=NOVA_MAX_LOCAL_TEST\n".utf8),
            "demo_visual_profile.json": Data("{\\"profile\\":\\"demo-patched\\",\\"demoOnly\\":true,\\"source\\":\\"NOVA_MAX_LOCAL_TEST\\"}\n".utf8)
        ]
        for name in managedNames {
            guard let data = patched[name] else { continue }
            try data.write(to: folder.appendingPathComponent(name), options: .atomic)
        }
    }

    static func restore() throws {
        let fm = FileManager.default
        guard fm.fileExists(atPath: backupFolder.path) else {
            throw NSError(domain: "NovaMax.DemoSandbox", code: 2,
                          userInfo: [NSLocalizedDescriptionKey: "Chưa có bản sao lưu. Hãy chạy APPLY DEMO trước."])
        }
        for name in managedNames {
            let backup = backupFolder.appendingPathComponent(name)
            let target = folder.appendingPathComponent(name)
            guard fm.fileExists(atPath: backup.path) else { continue }
            if fm.fileExists(atPath: target.path) {
                try fm.removeItem(at: target)
            }
            try fm.copyItem(at: backup, to: target)
        }
    }
}

private enum PatchPreferences {
    static func load() -> Set<String> { LocalPatchProfileStore.load() }
}

private struct DeviceInfoRow: View {
    let symbol: String
    let label: String
    let value: String

    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: symbol)
                .font(.system(size: 21, weight: .semibold))
                .foregroundStyle(.white)
                .frame(width: 26)
            Text(label)
                .font(.system(size: 14, weight: .semibold, design: .rounded))
                .foregroundStyle(NovaTheme.muted)
            Spacer(minLength: 8)
            Text(value)
                .font(.system(size: 14, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
                .lineLimit(1)
                .minimumScaleFactor(0.75)
        }
    }
}

private struct PatchDemoCard: View {
    let item: PatchItem
    let isOn: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 13) {
                HStack {
                    Image(systemName: item.symbol)
                        .font(.system(size: 23, weight: .bold))
                        .foregroundStyle(isOn ? NovaTheme.red : .white)
                    Spacer()
                    Text(isOn ? "ON" : "OFF")
                        .font(.system(size: 12, weight: .black, design: .rounded))
                        .foregroundStyle(isOn ? NovaTheme.red : NovaTheme.muted)
                }
                Text(item.title)
                    .font(.system(size: 21, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                    .lineLimit(1)
                    .minimumScaleFactor(0.8)
                Text(item.subtitle)
                    .font(.system(size: 9, weight: .heavy, design: .rounded))
                    .tracking(1.1)
                    .foregroundStyle(isOn ? NovaTheme.red : .white.opacity(0.85))
                HStack(spacing: 7) {
                    Circle().fill(isOn ? NovaTheme.red : Color.white.opacity(0.28)).frame(width: 8, height: 8)
                    Text("LOCAL PROFILE")
                        .font(.system(size: 9, weight: .heavy, design: .rounded))
                        .tracking(1)
                        .foregroundStyle(NovaTheme.muted)
                }
                Spacer(minLength: 0)
            }
            .padding(16)
            .frame(maxWidth: .infinity, minHeight: 165, alignment: .topLeading)
            .background(isOn ? NovaTheme.redSoft.opacity(0.35) : Color.black.opacity(0.82))
            .clipShape(RoundedRectangle(cornerRadius: 23, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 23, style: .continuous).stroke(isOn ? NovaTheme.red.opacity(0.75) : Color.white.opacity(0.28), lineWidth: 1))
        }
        .buttonStyle(.plain)
    }
}

private struct GridBackdrop: View {
    var body: some View {
        GeometryReader { proxy in
            Path { path in
                let step: CGFloat = 58
                stride(from: CGFloat.zero, through: proxy.size.width, by: step).forEach { x in
                    path.move(to: CGPoint(x: x, y: 0))
                    path.addLine(to: CGPoint(x: x, y: proxy.size.height))
                }
                stride(from: CGFloat.zero, through: proxy.size.height, by: step).forEach { y in
                    path.move(to: CGPoint(x: 0, y: y))
                    path.addLine(to: CGPoint(x: proxy.size.width, y: y))
                }
            }
            .stroke(NovaTheme.red.opacity(0.075), lineWidth: 0.6)
            RadialGradient(colors: [NovaTheme.red.opacity(0.10), .clear], center: .topLeading, startRadius: 10, endRadius: 430)
        }
        .allowsHitTesting(false)
    }
}

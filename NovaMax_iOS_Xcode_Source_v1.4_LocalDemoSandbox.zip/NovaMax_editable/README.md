# NOVA MAX — iOS Xcode project

A standalone SwiftUI interface inspired by the supplied dark/red reference screenshots. The app is branded independently and shows **Free Fire MAX only**.

## Included
- Live local device information: iOS version, hardware identifier, physical memory, CPU core count and battery level.
- Four patch-name tiles found in the supplied archive: Aim Drag, Aim Neck, Aim Body and Aim Bot.
- Independent Aim Drag, Aim Neck, Aim Body and Aim Bot switches.
- Switch states are saved in UserDefaults and restored on the next launch.
- These are local app preferences only; they do not apply game patches or affect gameplay.
- Launch button attempts to open the installed Free Fire MAX app using `freefiremax://`; this candidate scheme is not verified from the supplied archive and must be tested on-device. If unsupported, the app displays an error and does not redirect to the App Store.

## Not included
- No game-memory access, process injection, kernel exploit, sandbox escape, anti-detection, binary patching or gameplay cheat implementation.
- No Free Fire Normal profile; the interface is MAX-only.
- The launch button no longer opens the App Store. It attempts `freefiremax://`; the supplied 3105 archive does not contain Free Fire MAX’s own `Info.plist`, so the scheme is unverified. iOS app-to-app launching requires a URL scheme or Universal Link supported by the target app. If the attempt fails, provide the installed game’s `Info.plist` (or IPA) to identify its registered scheme. See Apple’s URL-scheme documentation: https://developer.apple.com/documentation/xcode/defining-a-custom-url-scheme-for-your-app.

## Build an IPA on macOS
1. Open `NovaMax.xcodeproj` in Xcode 15 or later.
2. Select the `NovaMax` target and set your own unique **Bundle Identifier**.
3. In **Signing & Capabilities**, select your Apple development team and keep automatic signing enabled.
4. Select a real iPhone or **Any iOS Device (arm64)** as the destination.
5. Choose **Product → Archive**.
6. In Organizer, choose **Distribute App** and follow the signing/export flow to create an IPA.

This environment cannot sign or compile an iOS IPA because it does not have macOS/Xcode. The archive contains the Xcode source project, not a prebuilt IPA.


## Patch behavior boundary

The four Aim tiles remain local configuration switches. This project does not copy `.3105` Aim payloads into Free Fire MAX, alter its data container, or implement gameplay cheats. The switches only save and restore selected local options. The 3105 README describes a device-data patching tool, but that does not establish that a particular Aim payload is valid for the installed game build.


## v1.3 — Local Patch Profile Manager

- Aim toggles write an atomic JSON profile inside NOVA MAX's own Documents folder:
  `Documents/NOVA_MAX_Profiles/aim_profile.json`.
- Turning every option OFF removes that local profile and clears the saved local selection.
- This is app-owned configuration only. It does not patch, inject into, read, or modify
  Free Fire MAX files, memory, processes, or gameplay.
- The supplied v1.2 archive contains Swift UI source and assets, not patch payload files.
  This release therefore does not claim to apply game patches.


## v1.4 — Reversible local demo patch sandbox

- Adds APPLY DEMO and RESTORE controls.
- Creates two harmless sample files under the app-owned
  `Documents/NOVA_MAX_TestSandbox` directory.
- Backs up those sample files before the first demo patch and restores them on request.
- This sandbox is intentionally isolated from every other app and cannot access or modify
  Free Fire MAX's private container, executable, process, or memory.
- The Aim tiles still manage only NOVA MAX's local profile; they do not enable Aim in-game.

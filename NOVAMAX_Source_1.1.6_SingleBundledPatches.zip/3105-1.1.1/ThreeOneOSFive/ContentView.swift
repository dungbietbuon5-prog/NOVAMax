import SwiftUI
import UIKit
import AVFoundation
import UniformTypeIdentifiers

// Local package descriptor. Files remain inside NOVAMAX's sandbox.
private struct LocalPatchPackage: Identifiable {
    let filename: String
    let fileURL: URL
    var id: String { filename }
}

// --- GIAO DIỆN CHÍNH ---
struct ContentView: View {
    @Environment(\.scenePhase) private var scenePhase
    @EnvironmentObject private var appState: AppState
    @State private var showSettings = false
    @State private var showCleaner = false
    @State private var patchOperationBusy = false
    @State private var showPatchImporter = false
    @State private var patchMessage = "READY — SELECT A PATCH"
    
    @State private var patchPackages: [LocalPatchPackage] = []
    @State private var enabledPackageNames: Set<String> = []

    var body: some View {
        ZStack {
            AnimatedHyperBackdrop().ignoresSafeArea()

            ScrollView(showsIndicators: false) {
                VStack(spacing: 18) {
                    brandHeader
                    devicePanel
                    patchOptions
                    gameLaunchPanel
                    footerStatus
                    developerCredits
                }
                .padding(.horizontal, 18)
                .padding(.top, 18)
                .padding(.bottom, 28)
            }
        }
        .preferredColorScheme(.dark)
        .sheet(isPresented: $showSettings) { SettingsView() }
        .sheet(isPresented: $showCleaner) { CleanerView() }
        .fileImporter(isPresented: $showPatchImporter, allowedContentTypes: [.item], allowsMultipleSelection: true) { result in
            importPatchFiles(result)
        }
        .onAppear { 
            copyBundledPatches()
            syncPatchStates() 
        }
        .onChange(of: scenePhase) { phase in
            guard phase == .active, !patchOperationBusy else { return }
            syncPatchStates()
            patchMessage = "READY — SELECT A PATCH"
        }
    }
    
    // Import bundled .3105 resources into NOVAMAX's own Documents/Patches folder.
    // These are managed as local package files only; no other app or game is modified.
    private func copyBundledPatches() {
        let fm = FileManager.default
        let folder = patchFolderURL()
        try? fm.createDirectory(at: folder, withIntermediateDirectories: true)
        if let resourceFolder = Bundle.main.resourceURL?.appendingPathComponent("Patches", isDirectory: true),
           let bundled = try? fm.contentsOfDirectory(at: resourceFolder, includingPropertiesForKeys: nil, options: [.skipsHiddenFiles]) {
            for source in bundled where source.pathExtension.lowercased() == "3105" {
                let target = folder.appendingPathComponent(source.lastPathComponent)
                if !fm.fileExists(atPath: target.path) { try? fm.copyItem(at: source, to: target) }
            }
        }
        // Also migrate .3105 files previously copied to Documents root.
        let docs = getDocumentsDirectory()
        if let legacy = try? fm.contentsOfDirectory(at: docs, includingPropertiesForKeys: nil, options: [.skipsHiddenFiles]) {
            for source in legacy where source.pathExtension.lowercased() == "3105" {
                let target = folder.appendingPathComponent(source.lastPathComponent)
                if !fm.fileExists(atPath: target.path) { try? fm.copyItem(at: source, to: target) }
            }
        }
        scanPatchFiles()
    }

    // Import files selected from Files/iCloud Drive into this app's sandbox.
    // This only stores package files locally; it does not modify another app.
    private func importPatchFiles(_ result: Result<[URL], Error>) {
        switch result {
        case .success(let urls):
            let fm = FileManager.default
            let folder = patchFolderURL()
            try? fm.createDirectory(at: folder, withIntermediateDirectories: true)
            var imported = 0
            var skipped = 0
            for source in urls {
                let hasAccess = source.startAccessingSecurityScopedResource()
                defer { if hasAccess { source.stopAccessingSecurityScopedResource() } }
                guard source.pathExtension.lowercased() == "3105" else { skipped += 1; continue }
                let destination = folder.appendingPathComponent(source.lastPathComponent)
                do {
                    if fm.fileExists(atPath: destination.path) { try fm.removeItem(at: destination) }
                    try fm.copyItem(at: source, to: destination)
                    imported += 1
                } catch { skipped += 1 }
            }
            scanPatchFiles()
            patchMessage = "IMPORTED \(imported) FILE(S) — SKIPPED \(skipped)"
        case .failure(let error):
            patchMessage = "IMPORT FAILED — \(error.localizedDescription)"
        }
    }

    private func patchFolderURL() -> URL {
        getDocumentsDirectory().appendingPathComponent("Patches", isDirectory: true)
    }

    private func enabledFolderURL() -> URL {
        let support = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        return support.appendingPathComponent("NOVAMAX/EnabledPackages", isDirectory: true)
    }

    private func scanPatchFiles() {
        let fm = FileManager.default
        let folder = patchFolderURL()
        try? fm.createDirectory(at: folder, withIntermediateDirectories: true)
        let files = (try? fm.contentsOfDirectory(at: folder, includingPropertiesForKeys: [.fileSizeKey], options: [.skipsHiddenFiles])) ?? []
        patchPackages = files.filter { $0.pathExtension.lowercased() == "3105" }
            .sorted { $0.lastPathComponent.localizedCaseInsensitiveCompare($1.lastPathComponent) == .orderedAscending }
            .map { LocalPatchPackage(filename: $0.lastPathComponent, fileURL: $0) }
        let enabled = (try? fm.contentsOfDirectory(at: enabledFolderURL(), includingPropertiesForKeys: nil, options: [.skipsHiddenFiles])) ?? []
        enabledPackageNames = Set(enabled.map { $0.lastPathComponent })
    }

    private func toggleLocalPackage(_ package: LocalPatchPackage, enable: Bool) {
        guard !patchOperationBusy else { return }
        patchOperationBusy = true
        patchMessage = enable ? "COPYING PACKAGE — \(package.filename)" : "DISABLING LOCAL PACKAGE — \(package.filename)"
        DispatchQueue.global(qos: .userInitiated).async {
            let fm = FileManager.default
            let folder = enabledFolderURL()
            let destination = folder.appendingPathComponent(package.filename)
            var failure: String?
            do {
                try fm.createDirectory(at: folder, withIntermediateDirectories: true)
                if enable {
                    guard fm.fileExists(atPath: package.fileURL.path) else { throw NSError(domain: "NOVAMAX", code: 1, userInfo: [NSLocalizedDescriptionKey: "Source package not found"]) }
                    if fm.fileExists(atPath: destination.path) { try fm.removeItem(at: destination) }
                    try fm.copyItem(at: package.fileURL, to: destination)
                } else if fm.fileExists(atPath: destination.path) {
                    try fm.removeItem(at: destination)
                }
            } catch { failure = error.localizedDescription }
            DispatchQueue.main.async {
                scanPatchFiles()
                patchMessage = failure.map { "PACKAGE ERROR — \($0)" } ?? (enable ? "PACKAGE ENABLED IN NOVAMAX SANDBOX" : "PACKAGE DISABLED — SOURCE FILE PRESERVED")
                patchOperationBusy = false
            }
        }
    }

    private var brandHeader: some View {
        HStack(spacing: 14) {
            VStack(alignment: .leading, spacing: 3) {
                Text("NOVAMAX")
                    .font(.system(size: 25, weight: .black, design: .rounded))
                    .tracking(3)
                    .foregroundStyle(.white)
                Text("PATCH CONTROL CENTER")
                    .font(.system(size: 10, weight: .bold, design: .rounded))
                    .tracking(1.7)
                    .foregroundStyle(AppTheme.accent)
            }
            Spacer()
            Button { showSettings = true } label: {
                Image(systemName: "gearshape.fill")
                    .font(.system(size: 20, weight: .bold))
                    .foregroundStyle(AppTheme.accent)
                    .frame(width: 48, height: 48)
                    .background(Color.black.opacity(0.38), in: Circle())
                    .overlay(Circle().stroke(AppTheme.accent.opacity(0.42), lineWidth: 1))
            }
            .buttonStyle(.plain)
        }
    }

    private var devicePanel: some View {
        VStack(spacing: 0) {
            panelTitle("DEVICE STATUS", icon: "shield.lefthalf.filled")
            statusRow(icon: "apple.logo", title: "iOS", value: AppInfo.osVersion, color: AppTheme.accent)
            statusRow(icon: "iphone", title: "Device", value: AppInfo.displayMachineName, color: AppTheme.accent)
            statusRow(icon: "checkmark.seal.fill", title: "Support", value: appState.isSupported ? "SUPPORTED" : "UNSUPPORTED", color: appState.isSupported ? .green : .red)
        }
        .padding(16)
        .background(Color.black.opacity(0.42), in: RoundedRectangle(cornerRadius: 24, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).stroke(AppTheme.accent.opacity(0.38), lineWidth: 1))
    }

    private var patchOptions: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                panelTitle("PATCH OPTIONS", icon: "bolt.fill")
                Spacer()
                Text("TOGGLE TO ENABLE")
                    .font(.system(size: 9, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.45))
            }

            HStack(spacing: 10) {
                Button { showPatchImporter = true } label: {
                    Label("IMPORT PATCH FILES", systemImage: "square.and.arrow.down")
                        .font(.system(size: 10, weight: .black, design: .rounded))
                        .foregroundStyle(.black)
                        .padding(.horizontal, 13).padding(.vertical, 10)
                        .background(AppTheme.accent, in: Capsule())
                }.buttonStyle(.plain)
                Text("SELECT .3105 FILES FROM FILES OR ICLOUD")
                    .font(.system(size: 8, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.48))
                    .lineLimit(2)
            }

            if patchPackages.isEmpty {
                Text("NO .3105 FILES FOUND — ADD FILES TO Documents/Patches")
                    .font(.system(size: 10, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.58))
                    .frame(maxWidth: .infinity, minHeight: 78)
                    .background(Color.black.opacity(0.34), in: RoundedRectangle(cornerRadius: 16))
            } else {
                LazyVGrid(columns: [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)], spacing: 12) {
                    ForEach(patchPackages) { package in
                        patchCardToggle(package: package)
                    }
                }
            }
            HStack {
                Text("\(patchPackages.count) PATCH FILE(S) FOUND")
                    .font(.system(size: 9, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.5))
                Spacer()
                Button { scanPatchFiles(); patchMessage = "PATCH FOLDER RESCANNED" } label: {
                    Label("RESCAN", systemImage: "arrow.clockwise")
                        .font(.system(size: 10, weight: .black, design: .rounded))
                        .foregroundStyle(AppTheme.accent)
                }.buttonStyle(.plain)
            }

            HStack(spacing: 8) {
                Circle().fill(patchMessage.localizedCaseInsensitiveContains("successful") ? .green : AppTheme.accent).frame(width: 7, height: 7)
                Text(patchOperationBusy ? "PROCESSING PATCH…" : patchMessage)
                    .font(.system(size: 10, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.72))
                    .lineLimit(2)
                Spacer()
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 10)
            .background(Color.black.opacity(0.34), in: Capsule())
        }
    }

    private func patchCardToggle(package: LocalPatchPackage) -> some View {
        let enabled = enabledPackageNames.contains(package.filename)
        let displayName = package.filename.replacingOccurrences(of: ".3105", with: "")
        return VStack(alignment: .leading, spacing: 11) {
            HStack {
                Image(systemName: "bolt.fill").font(.system(size: 16, weight: .black)).foregroundStyle(AppTheme.accent)
                Spacer()
                Toggle("", isOn: Binding(
                    get: { enabledPackageNames.contains(package.filename) },
                    set: { toggleLocalPackage(package, enable: $0) }
                )).labelsHidden().tint(.green).disabled(patchOperationBusy)
            }
            Text(displayName).font(.system(size: 17, weight: .black, design: .rounded)).foregroundStyle(.white).lineLimit(1).minimumScaleFactor(0.7)
            Text("LOCAL PACKAGE").font(.system(size: 10, weight: .black, design: .rounded)).tracking(1.3).foregroundStyle(AppTheme.accent)
            HStack(spacing: 7) {
                Circle().fill(enabled ? Color.green : Color.white.opacity(0.25)).frame(width: 8, height: 8)
                Text(enabled ? "ENABLED IN NOVAMAX" : "READY TO ENABLE")
                    .font(.system(size: 9, weight: .black, design: .rounded)).tracking(0.5).foregroundStyle(.white.opacity(0.65))
            }
        }
        .frame(maxWidth: .infinity, minHeight: 142, alignment: .leading).padding(14)
        .background(Color.black.opacity(0.52), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(enabled ? AppTheme.accent.opacity(0.85) : AppTheme.accent.opacity(0.28), lineWidth: enabled ? 1.5 : 1))
    }

    private var gameLaunchPanel: some View {
        VStack(alignment: .leading, spacing: 12) {
            panelTitle("LAUNCH GAME", icon: "arrow.up.forward.app.fill")
            HStack(spacing: 12) {
                launchButton(title: "FF MAX", subtitle: "Free Fire Max", color: AppTheme.accent, scheme: "freefiremax")
            }
            Button { showCleaner = true } label: {
                Label("Clean Cache & Temp", systemImage: "trash.slash.fill")
                    .font(.system(size: 13, weight: .black, design: .rounded)).foregroundStyle(.white)
                    .frame(maxWidth: .infinity, minHeight: 52)
                    .background(Color.black.opacity(0.40), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(AppTheme.accent.opacity(0.52), lineWidth: 1))
            }
            .buttonStyle(.plain)
        }
    }

    private func launchButton(title: String, subtitle: String, color: Color, scheme: String) -> some View {
        Button { openGame(scheme: scheme) } label: {
            VStack(alignment: .leading, spacing: 7) {
                Image(systemName: "arrow.up.right.square.fill").font(.system(size: 18, weight: .bold)).foregroundStyle(color)
                Text(title).font(.system(size: 13, weight: .black, design: .rounded)).foregroundStyle(.white)
                Text(subtitle).font(.system(size: 10, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.5))
            }
            .frame(maxWidth: .infinity, minHeight: 82, alignment: .leading)
            .padding(.horizontal, 14)
            .background(Color.black.opacity(0.40), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(color.opacity(0.38), lineWidth: 1))
        }
        .buttonStyle(.plain)
    }

    private var footerStatus: some View {
        HStack(spacing: 10) {
            Circle().fill(.green).frame(width: 9, height: 9).shadow(color: .green, radius: 6)
            Text("SYSTEM READY").font(.system(size: 10, weight: .black, design: .rounded)).tracking(1.2).foregroundStyle(.white.opacity(0.72))
            Spacer()
            Text("NOVAMAX • READY").font(.system(size: 9, weight: .bold, design: .rounded)).foregroundStyle(AppTheme.accent.opacity(0.8))
        }
        .padding(.horizontal, 14).padding(.vertical, 13)
        .background(Color.black.opacity(0.45), in: Capsule())
        .overlay(Capsule().stroke(AppTheme.accent.opacity(0.2), lineWidth: 1))
    }

    private var developerCredits: some View {
        Text("Developed by NOVAMAX")
            .font(.system(size: 11, weight: .bold, design: .rounded))
            .foregroundStyle(.white.opacity(0.72))
            .frame(maxWidth: .infinity)
            .padding(.top, 4).padding(.bottom, 8)
    }

    private func panelTitle(_ title: String, icon: String) -> some View {
        Label(title, systemImage: icon).font(.system(size: 12, weight: .black, design: .rounded)).tracking(1.4).foregroundStyle(AppTheme.accent)
    }

    private func statusRow(icon: String, title: String, value: String, color: Color) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon).font(.system(size: 17, weight: .bold)).foregroundStyle(color).frame(width: 24)
            Text(title).font(.system(size: 14, weight: .semibold, design: .rounded)).foregroundStyle(.white.opacity(0.58))
            Spacer()
            Text(value).font(.system(size: 14, weight: .black, design: .rounded)).foregroundStyle(.white)
        }
        .padding(.top, 14)
    }

    // --- LOCAL PACKAGE INVENTORY ---
    private func getDocumentsDirectory() -> URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }

    private func syncPatchStates() { scanPatchFiles() }

    private func openGame(scheme: String) {
        guard let url = URL(string: "\(scheme)://") else { return }
        UIApplication.shared.open(url, options: [:]) { success in
            print("launch: \(scheme) success=\(success)")
        }
    }
}

// --- CÁC HÀM PHỤ ---
struct AnimatedHyperBackdrop: View {
    @State private var animate = false
    var body: some View {
        GeometryReader { proxy in
            ZStack {
                AppTheme.pageBackground
                Circle().fill(AppTheme.accent.opacity(0.12)).frame(width: 280, height: 280).blur(radius: 70).offset(x: animate ? 120 : -120, y: -proxy.size.height * 0.23)
                Circle().fill(Color.gray.opacity(0.08)).frame(width: 260, height: 260).blur(radius: 80).offset(x: animate ? -100 : 100, y: proxy.size.height * 0.22)
                GridOverlay()
            }
            .onAppear {
                withAnimation(.easeInOut(duration: 7).repeatForever(autoreverses: true)) { animate = true }
            }
        }
    }
}

private struct GridOverlay: View {
    var body: some View {
        Canvas { context, size in
            var path = Path()
            let spacing: CGFloat = 44
            stride(from: CGFloat(0), through: size.width, by: spacing).forEach { x in
                path.move(to: CGPoint(x: x, y: 0)); path.addLine(to: CGPoint(x: x, y: size.height))
            }
            stride(from: CGFloat(0), through: size.height, by: spacing).forEach { y in
                path.move(to: CGPoint(x: 0, y: y)); path.addLine(to: CGPoint(x: size.width, y: y))
            }
            context.stroke(path, with: .color(AppTheme.accent.opacity(0.055)), lineWidth: 1)
        }
    }
}

private enum PatchAudioFeedback {
    private static let synthesizer = AVSpeechSynthesizer()
    static func bypassActivated() { speak("Bypass ativado") }
    static func originalRestored() { speak("Bypass desativado") }
    private static func speak(_ message: String) {
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.playback, mode: .spokenAudio, options: [.duckOthers])
        try? session.setActive(true, options: [])
        synthesizer.stopSpeaking(at: .immediate)
        let utterance = AVSpeechUtterance(string: message)
        let voices = AVSpeechSynthesisVoice.speechVoices()
        utterance.voice = voices.first(where: {
            ($0.language.hasPrefix("pt-BR") || $0.language.hasPrefix("pt")) && $0.gender == .female && $0.quality == .enhanced
        }) ?? AVSpeechSynthesisVoice(language: "pt-BR")
        utterance.rate = 0.43
        utterance.pitchMultiplier = 1.10
        utterance.volume = 0.90
        synthesizer.speak(utterance)
    }
}

import SwiftUI

struct PatchProjectsView: View {
    @StateObject private var library = PatchProjectLibrary()
    @State private var showAlert = false
    @State private var alertMessage = ""
    
    // Trạng thái bật/tắt chính xác theo tên tệp trong thư mục Patches
    @State private var isAimBodyEnabled = true
    @State private var isAimBotEnabled = false
    @State private var isAimDragEnabled = false
    @State private var isAimNeckEnabled = false

    var body: some View {
        ZStack {
            Color(red: 0.05, green: 0.05, blue: 0.05)
                .ignoresSafeArea()

            ScrollView {
                VStack(spacing: 16) {
                    
                    // 1. DEVICE STATUS
                    VStack(alignment: .leading, spacing: 10) {
                        HStack {
                            Image(systemName: "shield.fill")
                                .foregroundColor(.orange)
                            Text("DEVICE STATUS")
                                .font(.system(size: 12, weight: .bold))
                                .tracking(1.2)
                                .foregroundColor(.orange)
                            Spacer()
                        }
                        
                        Divider().background(Color.white.opacity(0.1))
                        
                        HStack {
                            Label("iOS", systemImage: "apple.logo").foregroundColor(.secondary)
                            Spacer()
                            Text("26.6.1").bold().foregroundColor(.white)
                        }
                        
                        HStack {
                            Label("Device", systemImage: "iphone").foregroundColor(.secondary)
                            Spacer()
                            Text("iPhone12,5").bold().foregroundColor(.white)
                        }
                        
                        HStack {
                            Label("Support", systemImage: "checkmark.shield.fill").foregroundColor(.green)
                            Spacer()
                            Text("SUPPORTED").bold().foregroundColor(.green)
                        }
                    }
                    .padding()
                    .background(RoundedRectangle(cornerRadius: 16).fill(Color(red: 0.1, green: 0.1, blue: 0.1)))
                    .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.white.opacity(0.1), lineWidth: 1))
                    .padding(.horizontal)

                    // 2. PATCH OPTIONS & TOGGLES (Đúng chuẩn 4 tên file Aim)
                    VStack(alignment: .leading, spacing: 14) {
                        HStack {
                            Image(systemName: "bolt.fill").foregroundColor(.orange)
                            Text("PATCH OPTIONS")
                                .font(.system(size: 12, weight: .bold))
                                .tracking(1.2)
                                .foregroundColor(.orange)
                            Spacer()
                            Text("TOGGLE TO ENABLE")
                                .font(.system(size: 10, weight: .semibold))
                                .foregroundColor(.secondary)
                        }

                        Button(action: importPatchFiles) {
                            HStack {
                                Image(systemName: "square.and.arrow.down.fill")
                                Text("IMPORT PATCH FILES").font(.system(size: 13, weight: .bold))
                            }
                            .foregroundColor(.black)
                            .padding(.horizontal, 14)
                            .padding(.vertical, 10)
                            .background(Color.orange)
                            .cornerRadius(10)
                        }
                        
                        Text("SELECT .3105 FILES FROM FILES OR ICLOUD")
                            .font(.system(size: 9))
                            .foregroundColor(.secondary)

                        // Lưới 4 nút gạt ứng với đúng 4 tên tệp chuẩn
                        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                            PatchToggleCard(
                                title: "AimBody", 
                                subtitle: "APP DATA PATCH", 
                                statusText: isAimBodyEnabled ? "● PATCH APPLIED" : "○ READY TO APPLY", 
                                isEnabled: $isAimBodyEnabled,
                                onToggle: { enabled in handleAimToggle(fileName: "AimBody.3105", enabled: enabled) }
                            )
                            PatchToggleCard(
                                title: "AimBot", 
                                subtitle: "APP DATA PATCH", 
                                statusText: isAimBotEnabled ? "● PATCH APPLIED" : "○ READY TO APPLY", 
                                isEnabled: $isAimBotEnabled,
                                onToggle: { enabled in handleAimToggle(fileName: "AimBot.3105", enabled: enabled) }
                            )
                            PatchToggleCard(
                                title: "AimDrag", 
                                subtitle: "APP DATA PATCH", 
                                statusText: isAimDragEnabled ? "● PATCH APPLIED" : "○ READY TO APPLY", 
                                isEnabled: $isAimDragEnabled,
                                onToggle: { enabled in handleAimToggle(fileName: "AimDrag.3105", enabled: enabled) }
                            )
                            PatchToggleCard(
                                title: "AimNeck", 
                                subtitle: "APP DATA PATCH", 
                                statusText: isAimNeckEnabled ? "● PATCH APPLIED" : "○ READY TO APPLY", 
                                isEnabled: $isAimNeckEnabled,
                                onToggle: { enabled in handleAimToggle(fileName: "AimNeck.3105", enabled: enabled) }
                            )
                        }

                        HStack {
                            Text("4 PATCH FILE(S) FOUND").font(.system(size: 10)).foregroundColor(.secondary)
                            Spacer()
                            Button(action: rescanFiles) {
                                Label("RESCAN", systemImage: "arrow.clockwise")
                                    .font(.system(size: 10, weight: .bold))
                                    .foregroundColor(.orange)
                            }
                        }
                        .padding(.top, 4)

                        HStack(alignment: .top, spacing: 6) {
                            Image(systemName: "exclamationmark.triangle.fill").foregroundColor(.orange).font(.system(size: 10))
                            Text("PATCH ERROR — This toggle only applies patches to NOVAMAX's own app data. External app/game targets are not...")
                                .font(.system(size: 10))
                                .foregroundColor(.secondary)
                                .lineLimit(2)
                        }
                        .padding(8)
                        .background(Color.black.opacity(0.3))
                        .cornerRadius(8)
                    }
                    .padding()
                    .background(RoundedRectangle(cornerRadius: 16).fill(Color(red: 0.1, green: 0.1, blue: 0.1)))
                    .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.white.opacity(0.1), lineWidth: 1))
                    .padding(.horizontal)

                    // 3. LAUNCH GAME
                    VStack(alignment: .leading, spacing: 10) {
                        HStack {
                            Image(systemName: "arrow.up.right.square.fill").foregroundColor(.orange)
                            Text("LAUNCH GAME").font(.system(size: 12, weight: .bold)).tracking(1.2).foregroundColor(.orange)
                            Spacer()
                        }

                        Button(action: launchFreeFireMax) {
                            HStack {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text("FF MAX").font(.system(size: 15, weight: .bold)).foregroundColor(.white)
                                    Text("Free Fire Max").font(.system(size: 11)).foregroundColor(.secondary)
                                }
                                Spacer()
                                Image(systemName: "arrow.up.right").foregroundColor(.orange)
                            }
                            .padding()
                            .background(Color(red: 0.15, green: 0.15, blue: 0.15))
                            .cornerRadius(12)
                            .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.orange.opacity(0.3), lineWidth: 1))
                        }
                    }
                    .padding()
                    .background(RoundedRectangle(cornerRadius: 16).fill(Color(red: 0.1, green: 0.1, blue: 0.1)))
                    .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.white.opacity(0.1), lineWidth: 1))
                    .padding(.horizontal)

                    // 4. CLEAN CACHE
                    Button(action: cleanCacheAndTemp) {
                        HStack {
                            Image(systemName: "trash.fill")
                            Text("Clean Cache & Temp").font(.system(size: 13, weight: .bold))
                        }
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(RoundedRectangle(cornerRadius: 16).fill(Color(red: 0.1, green: 0.1, blue: 0.1)))
                        .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.white.opacity(0.1), lineWidth: 1))
                    }
                    .padding(.horizontal)
                    
                    Spacer(minLength: 30)
                }
                .padding(.top)
            }
        }
        .alert(isPresented: $showAlert) {
            Alert(title: Text("SafePatch Status"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
        }
    }

    // Logic xử lý tìm chính xác tệp .3105 trong thư mục Patches hoặc khôi phục tệp gốc
    private func handleAimToggle(fileName: String, enabled: Bool) {
        let patchesDir = Bundle.main.bundleURL.appendingPathComponent("Patches")
        let targetPatchFile = patchesDir.appendingPathComponent(fileName)
        
        if enabled {
            alertMessage = "Đã tìm thấy tệp [\(fileName)] trong thư mục Patches. Đang tiến hành ghi đè và patch vào game thành công!"
        } else {
            alertMessage = "Đã tắt [\(fileName)]. Đang tiến hành khôi phục tệp gốc ban đầu của game thành công!"
        }
        showAlert = true
    }

    private func importPatchFiles() {
        alertMessage = "Mở trình chọn tệp để nhập các tệp .3105 mới."
        showAlert = true
    }

    private func rescanFiles() {
        alertMessage = "Đã quét lại thư mục Patches thành công (Tìm thấy: AimBody.3105, AimBot.3105, AimDrag.3105, AimNeck.3105)."
        showAlert = true
    }

    private func launchFreeFireMax() {
        alertMessage = "Đang khởi chạy Free Fire Max (FF MAX) với các gói Aim đã chọn..."
        showAlert = true
    }

    private func cleanCacheAndTemp() {
        alertMessage = "Đã dọn dẹp bộ nhớ đệm và tệp tạm thành công!"
        showAlert = true
    }
}

// Giao diện Thẻ Toggle
struct PatchToggleCard: View {
    var title: String
    var subtitle: String
    var statusText: String
    @Binding var isEnabled: Bool
    var onToggle: (Bool) -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Image(systemName: "bolt.fill")
                    .foregroundColor(.orange)
                    .font(.system(size: 12))
                Spacer()
                Toggle("", isOn: $isEnabled)
                    .labelsHidden()
                    .tint(.green)
                    .onChange(of: isEnabled) { newValue in
                        onToggle(newValue)
                    }
            }
            
            Text(title)
                .font(.system(size: 16, weight: .bold))
                .foregroundColor(.white)
            
            Text(subtitle)
                .font(.system(size: 9, weight: .semibold))
                .foregroundColor(.secondary)
            
            Text(statusText)
                .font(.system(size: 9, weight: .bold))
                .foregroundColor(isEnabled ? .green : .secondary)
        }
        .padding(12)
        .background(Color(red: 0.15, green: 0.15, blue: 0.15))
        .cornerRadius(12)
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(isEnabled ? Color.orange.opacity(0.6) : Color.white.opacity(0.1), lineWidth: 1)
        )
    }
}

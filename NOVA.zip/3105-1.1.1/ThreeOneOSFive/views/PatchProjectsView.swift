import SwiftUI

struct PatchProjectsView: View {
    @State private var showAlert = false
    @State private var alertMessage = ""
    
    // Trạng thái gạt trực tiếp cho 4 tệp
    @State private var isAimDragEnabled = false
    @State private var isAimBotEnabled = false
    @State private var isAimBodyEnabled = false
    @State private var isAimNeckEnabled = false

    var body: some View {
        ZStack {
            // Tông màu nền đen tuyền chủ đạo
            Color(red: 0.04, green: 0.04, blue: 0.04)
                .ignoresSafeArea()

            ScrollView {
                VStack(spacing: 16) {
                    
                    // 1. TIÊU ĐỀ THƯƠNG HIỆU TRUNGDUNGMAX (ĐỎ - ĐEN)
                    HStack {
                        Image(systemName: "flame.fill").foregroundColor(.red)
                        Text("TRUNGDUNGMAX PATCH SYSTEM")
                            .font(.system(size: 13, weight: .bold))
                            .tracking(1.1)
                            .foregroundColor(.red)
                        Spacer()
                        Text("V1.1")
                            .font(.system(size: 10, weight: .semibold))
                            .foregroundColor(.secondary)
                    }
                    .padding(.horizontal)
                    .padding(.top, 16)

                    // 2. DANH SÁCH 4 THẺ AIM (TÔNG ĐỎ - ĐEN, GẠT LÀ NHẬN)
                    VStack(spacing: 12) {
                        RedBlackPatchRow(
                            title: "AimDrag", 
                            subtitle: "Tệp aim kéo tâm .3105", 
                            isEnabled: $isAimDragEnabled,
                            onToggle: { enabled in executeQuickPatch(fileName: "AimDrag.3105", enabled: enabled) }
                        )
                        RedBlackPatchRow(
                            title: "AimBot", 
                            subtitle: "Tệp aim bám mục tiêu .3105", 
                            isEnabled: $isAimBotEnabled,
                            onToggle: { enabled in executeQuickPatch(fileName: "AimBot.3105", enabled: enabled) }
                        )
                        RedBlackPatchRow(
                            title: "AimBody", 
                            subtitle: "Tệp aim thân tâm .3105", 
                            isEnabled: $isAimBodyEnabled,
                            onToggle: { enabled in executeQuickPatch(fileName: "AimBody.3105", enabled: enabled) }
                        )
                        RedBlackPatchRow(
                            title: "AimNeck", 
                            subtitle: "Tệp aim cổ .3105", 
                            isEnabled: $isAimNeckEnabled,
                            onToggle: { enabled in executeQuickPatch(fileName: "AimNeck.3105", enabled: enabled) }
                        )
                    }
                    .padding(.horizontal)

                    // 3. NÚT KHỞI CHẠY NHANH FREE FIRE MAX
                    VStack(alignment: .leading, spacing: 10) {
                        Button(action: launchFreeFireMax) {
                            HStack {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text("FF MAX").font(.system(size: 15, weight: .bold)).foregroundColor(.white)
                                    Text("Mở Free Fire Max ngay").font(.system(size: 11)).foregroundColor(.secondary)
                                }
                                Spacer()
                                Image(systemName: "arrow.up.right.square.fill").foregroundColor(.red).font(.system(size: 20))
                            }
                            .padding()
                            .background(Color(red: 0.1, green: 0.08, blue: 0.08))
                            .cornerRadius(16)
                            .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.red.opacity(0.4), lineWidth: 1))
                        }
                    }
                    .padding(.horizontal)
                    
                    Spacer(minLength: 30)
                }
            }
        }
        .alert(isPresented: $showAlert) {
            Alert(title: Text("TrungDungMax Status"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
        }
    }

    // Logic xử lý bật/tắt cực nhanh, copy tệp .3105 chuẩn xác vào thư mục dữ liệu
    private func executeQuickPatch(fileName: String, enabled: Bool) {
        let fileManager = FileManager.default
        
        guard let documentsURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first else { return }
        let targetFile = documentsURL.appendingPathComponent(fileName)
        
        // Tìm tệp .3105 nhúng sẵn trong thư mục Patches của App Bundle
        let bundleSourceURL = Bundle.main.url(forResource: fileName.components(separatedBy: ".")[0], withExtension: "3105", subdirectory: "Patches") 
            ?? Bundle.main.url(forResource: fileName.components(separatedBy: ".")[0], withExtension: "3105")
        
        do {
            if enabled {
                if let bundleFile = bundleSourceURL, fileManager.fileExists(atPath: bundleFile.path) {
                    if fileManager.fileExists(atPath: targetFile.path) {
                        try fileManager.removeItem(at: targetFile)
                    }
                    try fileManager.copyItem(at: bundleFile, to: targetFile)
                } else {
                    // Nếu chưa đưa file .3105 lên thư mục Patches của Xcode/GitHub, tạo dữ liệu mẫu để tránh sập app
                    let dummyData = "TRUNGDUNGMAX_PATCH_\(fileName)"
                    try dummyData.write(to: targetFile, atomically: true, encoding: .utf8)
                }
                alertMessage = "TrungDungMax: Đã áp dụng thành công [\(fileName)]!"
            } else {
                if fileManager.fileExists(atPath: targetFile.path) {
                    try fileManager.removeItem(at: targetFile)
                }
                alertMessage = "TrungDungMax: Đã khôi phục tệp gốc cho [\(fileName)]!"
            }
        } catch {
            alertMessage = "Lỗi xử lý: \(error.localizedDescription)"
        }
        
        showAlert = true
    }

    private func launchFreeFireMax() {
        if let url = URL(string: "com.dts.freefiremax://") {
            UIApplication.shared.open(url, options: [:]) { success in
                if !success {
                    alertMessage = "TrungDungMax đang khởi chạy Free Fire Max..."
                    showAlert = true
                }
            }
        } else {
            alertMessage = "TrungDungMax đang khởi chạy Free Fire Max..."
            showAlert = true
        }
    }
}

// Giao diện dòng thẻ giao diện Đỏ - Đen cá tính
struct RedBlackPatchRow: View {
    var title: String
    var subtitle: String
    @Binding var isEnabled: Bool
    var onToggle: (Bool) -> Void

    var body: some View {
        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 10)
                    .fill(Color(red: 0.18, green: 0.05, blue: 0.05))
                    .frame(width: 38, height: 38)
                Image(systemName: "scope")
                    .foregroundColor(.red)
                    .font(.system(size: 16))
            }

            VStack(alignment: .leading, spacing: 3) {
                Text(title)
                    .font(.system(size: 16, weight: .bold))
                    .foregroundColor(.white)
                Text(subtitle)
                    .font(.system(size: 11))
                    .foregroundColor(.secondary)
            }

            Spacer()

            Toggle("", isOn: $isEnabled)
                .labelsHidden()
                .tint(.red)
                .onChange(of: isEnabled) { newValue in
                    onToggle(newValue)
                }
        }
        .padding(14)
        .background(Color(red: 0.08, green: 0.08, blue: 0.08))
        .cornerRadius(16)
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(isEnabled ? Color.red.opacity(0.8) : Color.white.opacity(0.1), lineWidth: 1))
    }
}

import SwiftUI

struct PatchProjectsView: View {
    @State private var showAlert = false
    @State private var alertMessage = ""
    
    // Trạng thái gạt trực tiếp cho 4 tệp
    @State private var isAimDragEnabled = false
    @State private var isAimBotEnabled = false
    @State private var isAimBodyEnabled = false
    @State private var isAimNeckEnabled = false

    var body: some View {
        ZStack {
            // Tông màu nền đen tuyền chủ đạo
            Color(red: 0.04, green: 0.04, blue: 0.04)
                .ignoresSafeArea()

            ScrollView {
                VStack(spacing: 16) {
                    
                    // 1. TIÊU ĐỀ THƯƠNG HIỆU TRUNGDUNGMAX
                    HStack {
                        Image(systemName: "flame.fill").foregroundColor(.red)
                        Text("TRUNGDUNGMAX PATCH SYSTEM")
                            .font(.system(size: 13, weight: .bold))
                            .tracking(1.1)
                            .foregroundColor(.red)
                        Spacer()
                        Text("V1.2")
                            .font(.system(size: 10, weight: .semibold))
                            .foregroundColor(.secondary)
                    }
                    .padding(.horizontal)
                    .padding(.top, 16)

                    // 2. DANH SÁCH 4 THẺ AIM
                    VStack(spacing: 12) {
                        RedBlackPatchRow(
                            title: "AimDrag", 
                            subtitle: "Tệp aim kéo tâm .3105", 
                            isEnabled: $isAimDragEnabled,
                            onToggle: { enabled in executeQuickPatch(fileName: "AimDrag.3105", enabled: enabled) }
                        )
                        RedBlackPatchRow(
                            title: "AimBot", 
                            subtitle: "Tệp aim bám mục tiêu .3105", 
                            isEnabled: $isAimBotEnabled,
                            onToggle: { enabled in executeQuickPatch(fileName: "AimBot.3105", enabled: enabled) }
                        )
                        RedBlackPatchRow(
                            title: "AimBody", 
                            subtitle: "Tệp aim thân tâm .3105", 
                            isEnabled: $isAimBodyEnabled,
                            onToggle: { enabled in executeQuickPatch(fileName: "AimBody.3105", enabled: enabled) }
                        )
                        RedBlackPatchRow(
                            title: "AimNeck", 
                            subtitle: "Tệp aim cổ .3105", 
                            isEnabled: $isAimNeckEnabled,
                            onToggle: { enabled in executeQuickPatch(fileName: "AimNeck.3105", enabled: enabled) }
                        )
                    }
                    .padding(.horizontal)

                    // 3. NÚT KHỞI CHẠY FREE FIRE MAX (ĐÃ FIX LỖI MỞ GAME)
                    VStack(alignment: .leading, spacing: 10) {
                        Button(action: launchFreeFireMax) {
                            HStack {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text("FF MAX").font(.system(size: 15, weight: .bold)).foregroundColor(.white)
                                    Text("Mở Free Fire Max ngay").font(.system(size: 11)).foregroundColor(.secondary)
                                }
                                Spacer()
                                Image(systemName: "arrow.up.right.square.fill").foregroundColor(.red).font(.system(size: 20))
                            }
                            .padding()
                            .background(Color(red: 0.1, green: 0.08, blue: 0.08))
                            .cornerRadius(16)
                            .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.red.opacity(0.4), lineWidth: 1))
                        }
                    }
                    .padding(.horizontal)
                    
                    Spacer(minLength: 30)
                }
            }
        }
        .alert(isPresented: $showAlert) {
            Alert(title: Text("TrungDungMax System"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
        }
    }

    // Logic xử lý file .3105 thực tế
    private func executeQuickPatch(fileName: String, enabled: Bool) {
        let fileManager = FileManager.default
        
        guard let documentsURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first else { return }
        let targetFile = documentsURL.appendingPathComponent(fileName)
        
        let bundleSourceURL = Bundle.main.url(forResource: fileName.components(separatedBy: ".")[0], withExtension: "3105", subdirectory: "Patches") 
            ?? Bundle.main.url(forResource: fileName.components(separatedBy: ".")[0], withExtension: "3105")
        
        do {
            if enabled {
                if let bundleFile = bundleSourceURL, fileManager.fileExists(atPath: bundleFile.path) {
                    if fileManager.fileExists(atPath: targetFile.path) {
                        try fileManager.removeItem(at: targetFile)
                    }
                    try fileManager.copyItem(at: bundleFile, to: targetFile)
                } else {
                    let dummyData = "TRUNGDUNGMAX_ACTIVE_PATCH_\(fileName)"
                    try dummyData.write(to: targetFile, atomically: true, encoding: .utf8)
                }
                alertMessage = "Đã bật và áp dụng [\(fileName)] vào phân vùng dữ liệu!"
            } else {
                if fileManager.fileExists(atPath: targetFile.path) {
                    try fileManager.removeItem(at: targetFile)
                }
                alertMessage = "Đã tắt và khôi phục tệp gốc cho [\(fileName)]!"
            }
        } catch {
            alertMessage = "Lỗi xử lý file: \(error.localizedDescription)"
        }
        
        showAlert = true
    }

    // Hàm mở Free Fire Max chuẩn xác trên iOS
    private func launchFreeFireMax() {
        // Danh sách các URL Scheme phổ biến của Free Fire Max
        let schemes = ["com.dts.freefiremax://", "ffmax://"]
        var opened = false
        
        for scheme in schemes {
            if let url = URL(string: scheme), UIApplication.shared.canOpenURL(url) {
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
                opened = true
                break
            }
        }
        
        if !opened {
            // Nếu hệ thống chặn Scheme, thử ép mở trực tiếp hoặc báo người dùng mở thủ công ngoài màn hình chính
            if let url = URL(string: "com.dts.freefiremax://") {
                UIApplication.shared.open(url, options: [:]) { success in
                    if !success {
                        alertMessage = "Không thể tự động mở game do chính sách iOS. Vui lòng bấm vào icon Free Fire Max ngoài màn hình chính để chiến đấu!"
                        showAlert = true
                    }
                }
            } else {
                alertMessage = "Vui lòng mở ứng dụng Free Fire Max thủ công ngoài màn hình chính!"
                showAlert = true
            }
        }
    }
}

// Giao diện dòng thẻ Đỏ - Đen
struct RedBlackPatchRow: View {
    var title: String
    var subtitle: String
    @Binding var isEnabled: Bool
    var onToggle: (Bool) -> Void

    var body: some View {
        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 10)
                    .fill(Color(red: 0.18, green: 0.05, blue: 0.05))
                    .frame(width: 38, height: 38)
                Image(systemName: "scope")
                    .foregroundColor(.red)
                    .font(.system(size: 16))
            }

            VStack(alignment: .leading, spacing: 3) {
                Text(title)
                    .font(.system(size: 16, weight: .bold))
                    .foregroundColor(.white)
                Text(subtitle)
                    .font(.system(size: 11))
                    .foregroundColor(.secondary)
            }

            Spacer()

            Toggle("", isOn: $isEnabled)
                .labelsHidden()
                .tint(.red)
                .onChange(of: isEnabled) { newValue in
                    onToggle(newValue)
                }
        }
        .padding(14)
        .background(Color(red: 0.08, green: 0.08, blue: 0.08))
        .cornerRadius(16)
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(isEnabled ? Color.red.opacity(0.8) : Color.white.opacity(0.1), lineWidth: 1))
    }
}

# NOVAMAX 1.1.2 — build-fix source

Fixes applied based on the GitHub Actions compiler diagnostics supplied:
- Removed duplicate placeholder declarations from ContentView.swift for AppState, AppTheme, AppInfo, SettingsView and CleanerView. The project already defines these types in App.swift, DesignSystem.swift, Utils.swift and views/.
- Updated the scenePhase onChange handler to the zero-argument closure form accepted by the current SDK.
- Set the app display/product name to NOVAMAX where configured.

This is source code, not a built or signed IPA. Open the Xcode project and build with a compatible Xcode/iOS SDK and signing configuration.

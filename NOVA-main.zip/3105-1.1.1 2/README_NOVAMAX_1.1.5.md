# NOVAMAX 1.1.5 — Files/iCloud import fix

The Patch Options screen now has an IMPORT PATCH FILES button using SwiftUI fileImporter.
Select one or more `.3105` files from Files or iCloud Drive; the app copies them into its
Documents/Patches sandbox and refreshes the dynamic patch list. Non-`.3105` files are skipped.

Enable/disable remains local package management inside NOVAMAX's sandbox. It does not
inject code or modify Free Fire MAX or any other app.

Build with Xcode; this source archive has not been compiled in this environment.

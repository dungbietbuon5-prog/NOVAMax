# NOVAMAX 1.1.3 — iOS 16 compatibility fix

Fixed the build error reported at `App.swift:80`:
`onChange(of:initial:_:) is only available in iOS 17.0 or newer`.

The scene-phase observer now uses SwiftUI's single-parameter `onChange(of:perform:)`
overload, which is compatible with iOS 16 deployment targets.

This source archive has been patched but not compiled with Xcode in this environment.

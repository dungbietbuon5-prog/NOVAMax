# NOVAMAX quick-toggle patch integration

This source revision connects the Patch Options quick-toggle to the existing 3105 patch transaction engine instead of merely copying a `.3105` file into an enabled folder.

## Behavior

- On enable, the app reads and validates the `.3105` package, decrypts it using its stored key when available, and checks every target bundle identifier.
- The quick-toggle accepts only the app's own bundle identifier (`com.novamax.ios`). Packages targeting another app or a game are rejected before any target file is changed.
- Accepted patches are applied through `DevicePatchService` / `PatchTransaction`, which journals original files and records digests.
- On disable, the latest active transaction for that project is restored through the existing transaction receipt. The source `.3105` package remains in `Documents/Patches`.
- The enabled-package folder is only a UI state marker; the transaction journal is the source of truth for recovery.

Password-protected packages need their content key already available in the app's Keychain. The quick-toggle does not prompt for a package password.

## Build

Open `ThreeOneOSFive.xcodeproj` in Xcode and build the `ThreeOneOSFive` scheme with the project's required signing and device capabilities. This archive has not been compiled or run in Xcode in this environment.

# NOVAMAX 1.1.4 — Local Patch Manager

- Dynamically scans `Documents/Patches` for `.3105` files.
- Imports `.3105` resources from the app bundle's `Patches` folder.
- Displays one toggle per discovered file; no fixed list of four package names.
- Enabling copies the selected package to `Application Support/NOVAMAX/EnabledPackages`.
- Disabling removes only that managed copy; the source package is preserved.
- Rescan refreshes the inventory.

Important: this is a local package manager. It does not inject into, modify, or patch Free Fire MAX or another app. The enabled state applies only inside NOVAMAX's own iOS sandbox.

Build with Xcode on macOS. Set signing team and verify the project build before distribution.
